# 미래에셋 카이로스 브릿지 (Mirae Kairos Bridge)

미래에셋증권은 **개인용 REST Open API 를 제공하지 않으므로**, HTS(카이로스) 화면을
자동으로 조작하고 화면을 실시간 캡쳐해 아이폰/웹에서 원격으로 보고 주문하는 도구입니다.

> ⚠️ **원칙 · 위험 고지**
> - **완전 자동(무인) 매매는 하지 않습니다.** 모든 주문은 사람이 UI에서 확인(개입)해야 나갑니다.
>   (자동 발주 루프·스케줄러는 제공하지 않음.)
> - 실거래 화면 자동화는 **깨지기 쉽고 위험**합니다(오주문 = 실제 손실). 안전장치를 유지하세요.
> - HTS 매크로/자동화는 **미래에셋 약관** 확인이 필요합니다. 본인 책임하에 사용하세요.
> - 이 도구는 **거래 가능한 PC를 원격 노출**합니다. 인증·긴급정지 없이 공개 금지.

---

## 지금 동작하는 것 (안전 · 실거래 X)
- **실시간 호가(DDE)**: 카이로스 DDE로 **실제 숫자 값** 수신(OCR 불필요). 웹UI에서 종목(트리거)을 바꿔 폴링
- **실시간 화면 스트림 + 토글**: 캡쳐 대상을 **호가창 영역 ↔ 카이로스 창 전체**로 전환
- **긴급 정지(🛑)**: 자동화를 즉시 중단(`safety.guard()`가 다음 동작에서 중단) + 미체결 취소 시도
  + **수동 원격조작 모드로 자동 전환**
- **수동 원격조작(크롬 리모트 데스크탑식)**: 긴급정지/수동모드에서 스트림 화면을 **클릭/더블클릭/우클릭**
  하면 실제 PC에 전달, 키보드 텍스트·Enter/Esc/Tab/Backspace 전송
- **KILL-SWITCH**: 주문 차단 + 미체결 취소
- 보안키 로그인(세션 쿠키) / iOS 는 Bearer 토큰, 주문 안전장치(가격밴드·최대수량·최대금액), 감사로그
- 주문은 **기본 DRY-RUN**(실제 주문 안 나감). 실거래는 카이로스 드라이버 구현 후에만.

## 아직 안 된 것 (다음 단계)
- `server/driver.py` **KairosDriver**: pywinauto 로 카이로스 주문창 실제 조작 (각 단계에 `safety.guard()`)
- 이메일 **OTP** 검증(`server/app.py`의 `/login` TODO)
- 호가 **숫자 OCR**(PaddleOCR) — 사람이 볼 땐 스트림으로 충분, 로직이 값을 알아야 할 때만
- **iOS 네이티브 앱**(SwiftUI + Keychain + Face ID). 초기엔 이 웹UI를 WKWebView로 감싸도 됨.

---

## 호가 확인(DDE)과 주문 방식

**호가 읽기 = DDE (권장).** 카이로스는 DDE를 지원하므로 화면 OCR 없이 실제 숫자를 받습니다.
1. 카이로스: **도구 > 시세 엑셀 연동(DDE)** 실행. '실시간 데이터 연결' 화면에서 종목/항목 등록.
2. 그 화면의 **DDE 서비스명 / 토픽 / 항목(아이템) 포맷**을 확인해 `config.toml [dde]`·`[dde.items]`에 입력.
   - 아이템은 `{symbol}` 이 종목코드로 치환됩니다(예: `"{symbol};현재가"`).
   - 종목 변경(트리거)은 웹UI의 **종목 적용** → `/quotes/symbol` 로 처리됩니다.
3. `enabled = true` 로 켜고 서버 재시작 → 웹UI **호가 폴링 켜기**로 값 확인.
   - 연결이 안 되면 `/status`·`/quotes`의 `error` 메시지를 보세요(서비스명/토픽 불일치가 대부분).

**주문 넣기 = 자동 클릭 (KairosDriver, 후속 구현).** 두 방식:
- **파이썬 자동클릭**(권장, 24/7 서버용): `pywinauto`(컨트롤 기반, 견고) 또는 고정 좌표 클릭(간단하나
  창 위치/해상도/DPI가 고정돼야 함). `server/driver.py` 의 `KairosDriver` 에 구현.
- **Claude 컴퓨터 유즈**: 대화형으로 제가 화면을 봐가며 조작하는 기능. **항상 켜둔 서버가 스스로
  호출할 수는 없습니다**(무인 자동화 부적합). 좌표 매핑·일회성 보조엔 유용.
- 어느 방식이든 **주문은 사람이 UI 버튼+확인**을 거쳐야 나갑니다(완전 자동 아님).

## 매매 안전장치 (절대 규칙)
코드에 고정 — 설정으로도 못 풉니다:
- **미수/융자/신용 매수 금지**: 매수는 '주문가능현금(신용 제외)' 한도 내에서만. 초과 시 **거부 + 알림**.
- **공매도/대주 금지, 초과매도 금지**: 매도는 '매도가능수량' 한도 내에서만. 미보유 종목 매도 불가.
- 현금이 부족하면 미수/융자로 넘어가지 않고 **알림**만 띄웁니다.
- 웹UI에 **매수가능/매도가능 수량** 표시.
- (실거래 드라이버 주의) `KairosDriver`는 주문 시 반드시 **현금(보통) 계좌유형**을 선택하고,
  **신용/미수/대주/공매도** 주문유형은 절대 쓰지 않도록 구현해야 합니다.

## 계좌 정보(예수금·보유) 읽는 방법 — 추천 순서
안전장치의 '진실 소스'는 정확해야 하므로:
1. **DDE(권장)** — 카이로스 DDE에 예수금/잔고 항목이 있으면 시세와 같은 파이프라인으로 정확 수신.
2. **엑셀 연동** — 카이로스 잔고를 엑셀 내보내기/DDE 연동 후 파이썬이 `.xlsx` 읽기(openpyxl/xlwings).
3. **UI 자동화(pywinauto/UIA)** — '내 자산' 그리드 셀 직접 읽기(그리드가 UIA 접근 가능할 때).
4. **화면 캡처 + OCR/비전 (비권장, 안전용 아님)** — 표시·모니터링엔 OK. 단 **초과매도 차단 같은
   안전 판단의 근거로는 금지**(오인식 1건이 사고). 캡처는 '보기'용으로만.

지금은 **수동 입력(positions.json)**이 구현돼 안전장치를 바로 쓸 수 있고, 위 1~3 중 하나로
자동화하면 그대로 대체됩니다. 카이로스 DDE 화면에 잔고 항목이 있는지 확인해 알려주시면 DDE로 붙여드립니다.

## 이메일 OTP 로그인 (Apps Script)
로그인 시 보안키 + 이메일 인증코드를 요구합니다. **서버가 코드 생성·해시저장·검증**하고,
**발송만 Apps Script(MailApp)** 에 맡깁니다(거래 보안키는 Apps Script 에 두지 않음).

수동 세팅:
1. [script.google.com](https://script.google.com) → 새 프로젝트 → 아래 붙여넣기
   ```javascript
   const SHARED_SECRET = 'PASTE_LONG_RANDOM';      // config [otp].shared_secret 과 동일
   const TO_EMAIL = 'you@example.com'; // 본인 수신 주소
   function doPost(e) {
     const b = JSON.parse(e.postData.contents);
     if (b.secret !== SHARED_SECRET)
       return ContentService.createTextOutput('{"ok":false}').setMimeType(ContentService.MimeType.JSON);
     MailApp.sendEmail(TO_EMAIL, '[Kairos Bridge] 인증코드',
       '인증코드: ' + String(b.code) + '\n(3분 내 입력, 타인 공유 금지)');
     return ContentService.createTextOutput('{"ok":true}').setMimeType(ContentService.MimeType.JSON);
   }
   ```
2. 배포 → 새 배포 → 웹 앱, **실행: 나 / 액세스: 모든 사용자**(서버가 익명 호출 → `SHARED_SECRET`으로 보호). Gmail 발송 권한 승인.
3. 배포 URL(끝 `/exec`)과 `SHARED_SECRET` 을 `config.toml [otp]` 에 넣고 `enabled = true`.
4. 웹 로그인에서 **인증코드 받기** → 메일 확인 → 코드 입력 → 로그인.

특성: 1회용·TTL(기본 180초)·시도 5회·재발송 쿨다운. 한계: 같은 Gmail 이 뚫리면 코드도 노출 →
진짜 2FA 가 아니라 '확인 단계 + 감사기록'. `enabled=false` 면 보안키만으로 로그인(OTP 생략).

## 설치 & 실행 (Windows)
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

copy config.example.toml config.toml
# config.toml 편집: access_token(긴 무작위), capture 영역 좌표, window_title(카이로스 창 제목)
python tools/pick_region.py     # 호가창 좌표 찾기

uvicorn server.app:app --host 0.0.0.0 --port 8443
```
로컬 테스트 시엔 `cookie_secure = false` + `http://127.0.0.1:8443`.
(Tailscale HTTPS 로 쓸 땐 다시 `true`.)

## Tailscale 로 노출
- **사설(권장 · 영상 스트리밍에 유리)**: 아이폰에도 Tailscale 설치 후 테일넷에서 접속 → `tailscale serve 8443`
- **공개(정말 필요할 때만)**: `tailscale funnel 8443`
  포트 443/8443/10000·HTTPS만·**대역폭 고정 제한**·**ACL 우회로 완전 공개** → 보안키+OTP가 유일한 방어선.

## 사용 흐름
1. 로그인 → **화면 켜기**. `카이로스 전체창`으로 바꾸면 창 전체가 보입니다(창 제목이 `window_title` 과 일치해야 함).
2. 이상하면 **🛑 긴급 정지** → 자동화 중단 + 수동모드. 화면을 직접 클릭/타이핑해 카이로스를 조작.
3. 정상 복귀하려면 **▶ 재개**. 주문은 폼 입력 후 **주문 전송**(확인창 뜸).

## 주의 / 한계
- 수동 원격조작 좌표 매핑은 **주 모니터** 기준이 안전합니다(보조 모니터의 음수 좌표는 부정확할 수 있음).
- `pyautogui` FAILSAFE: 실제 마우스를 화면 **좌상단 모서리**로 밀면 즉시 중단됩니다(물리적 비상장치).
- 실거래 전 **소액 계좌**로 검증. `live_enabled` 는 검증 전 `false`.
- 카이로스는 **직접 로그인**해두고 자동화는 '주문'만(공동인증서 자동화 지양).
- `config.toml`·`logs/`는 비밀 — 공유/커밋 금지.


<!-- ────────────────────────────────────────────────────────────
  ★이 파일은 공개 배포용으로 값이 지워져 있습니다.
    REPLACE_WITH_... / you@example.com / 100.64.0.1 자리에
    본인 값을 채워야 동작합니다.
──────────────────────────────────────────────────────────── -->
