# 카이로스 자동 로그인 — 새벽 5시 코워크 지시서 (v4, 재부팅 기반 · 터미널 캡쳐)

전제: **PC가 새벽 재부팅으로 깨끗한 상태(카이로스 꺼짐, Windows 자동로그인됨)**. 할 일은
**실행 → 로그인 → (팝업) → 확인**뿐. 강제종료는 불가(보안모듈 차단)라 시도하지 않는다.

## 너의 도구 (중요)
- **명령 실행 = 반드시 Terminal MCP** (터미널 실행 도구, run_command)로. 아래 모든 명령을 이걸로 실행한다. (직접 키/마우스로 터미널에 타이핑 금지)
- **화면 확인 = `capture.cmd`** 로 PNG 저장 후 **그 PNG 파일을 읽어서** 본다. **컴퓨터유즈(수동 승인) 불필요.**
- 클릭/키 = **피코**(`pico.cmd`). 마우스/키보드를 직접 조작하지 말 것.
- **터미널(MCP)이 바로 안 되거나 로그인이 안 되면: 무조건 최대 5회까지 재시도**(각 시도 사이 5초 대기). 5회까지 안 되면 그대로 중단(다음 실행 때 재시도됨).

작업 폴더: `C:\Users\USER\Desktop\mirae asset securities auto`

## 🔒 보안·안전 절대 규칙
1. 비밀번호를 보거나 출력·로그·저장하지 말 것. keyring 조회·setup·--dry-run 금지.
2. 로그인은 `login` 한 명령으로만. 쓰는 명령은 아래 래퍼뿐.
3. **거래비밀번호 입력·매수/매도 주문 절대 금지.** 로그인·팝업정리까지만.
4. **강제종료(taskkill/kill/restart) 시도 금지** — 어차피 막히고, 재부팅이 종료를 담당.
5. 캡차·2차인증·인증서 만료·보안설치요구·점검안내 등 예상 못 한 화면 → 자동으로 뚫지 말고 **오류처리(메일+중단)**.

## 쓰는 명령 (Terminal MCP로 실행)
셸이 **PowerShell**이면 `&` 로, **cmd.exe**면 `&` 없이 호출. (이 PC: PowerShell)
```
& "C:\Users\USER\Desktop\mirae asset securities auto\cowork\kairos.cmd" status
& "C:\Users\USER\Desktop\mirae asset securities auto\cowork\kairos.cmd" launch
& "C:\Users\USER\Desktop\mirae asset securities auto\cowork\kairos.cmd" login
& "C:\Users\USER\Desktop\mirae asset securities auto\cowork\capture.cmd"                     # 전체화면 캡쳐
& "C:\Users\USER\Desktop\mirae asset securities auto\cowork\capture.cmd" --region L T W H     # 특정영역 캡쳐(확대확인)
& "C:\Users\USER\Desktop\mirae asset securities auto\cowork\pico.cmd" click X Y               # 피코 클릭
& "C:\Users\USER\Desktop\mirae asset securities auto\cowork\notify.cmd" "제목" "본문"
Start-Sleep -Seconds 60
```
- `&` 형이 안 먹으면 `cmd /c "전체경로\kairos.cmd" status`.
- **출력 한글이 깨져 보여도 무시.** `status` 마지막 줄 **`RESULT: NO_WINDOW | LOGIN_OR_STARTING | LOGGED_IN`** 는 ASCII라 항상 정확 → **이 줄로 판정**.
- **캡쳐 사용법**: `capture.cmd` 실행 → 출력의 **`SAVED: <경로>`** 에 나온 PNG 파일을 **파일 읽기로 열어** 화면을 본다.
  캡쳐는 **실제 화면 픽셀(1920×1080)** 이라, 캡쳐에서 찾은 (x,y) 를 **그대로 `pico.cmd click X Y`** 에 쓰면 된다(좌표 변환 불필요).

## STEP 0 — 터미널 준비 확인
`kairos.cmd status` 를 Terminal MCP로 실행. 명령 자체가 실행 안 되면(MCP 미준비) **5초 대기 후 재시도(최대 5회)**. 정상 출력되면 그 RESULT로 STEP 1 판정.

## STEP 1 — 상태 확인
`kairos.cmd status` → RESULT:
- **NO_WINDOW** (정상: 재부팅 직후) → STEP 2.
- **LOGIN_OR_STARTING** (이미 로그인창) → STEP 3.
- **LOGGED_IN** (재부팅 안 됐거나 이미 실행 중) → **강제종료 불가.** 오류처리(메일: "카이로스가 이미 실행 중 — 재부팅 확인 필요") 후 **중단**.

## STEP 2 — 실행
`kairos.cmd launch` → **60초 대기** → `kairos.cmd status`.
- `LOGIN_OR_STARTING` → STEP 3.
- 아직 `NO_WINDOW` → 60초 더 대기 후 다시 status. 그래도 안 뜨면 오류처리 후 중단.

## STEP 3 — 로그인
`kairos.cmd login` 실행. 이 명령은 **내부에서 스스로 재시도**한다:
- 로그인폼을 맨앞으로 올리고 비번칸을 정확히 클릭(포커스 검증) → 붙여넣기 → 엔터
- **'공동인증비밀번호를 입력하여 주시기바랍니다' 경고팝업이 뜨면 자동으로 Enter로 닫고 다시 입력** (이 팝업 때문에 멈추지 않음)
- 비번·포커스·클립보드가 모두 확인돼야 엔터(빈 엔터 안 침)
→ 너는 `login` 을 실행한 뒤 STEP 4로 **결과만 확인**하면 된다.

## STEP 4 — 로그인 확인
**60초 대기** → `kairos.cmd status` → RESULT:
- `LOGGED_IN` → **핵심 성공.** STEP 5.
- 아니면 → `capture.cmd` 로 화면을 찍어 읽어('비밀번호 오류'·경고팝업·인증서 만료 등 확인) → `login` **재시도(무조건 최대 5회, 매번 60초 대기 후 status 확인)**. 5회까지 `LOGGED_IN` 안 되면 오류처리(화면 메시지 포함) 후 중단.

## STEP 5 — 팝업 닫기 (반복, 최대 8회)
※ **로그인창의 '공동인증비밀번호 입력' 경고팝업은 STEP 3의 `login`이 이미 자동 처리한다.** 여기는 **로그인 이후** 뜨는 공지/알림 팝업만 정리한다.
1. `capture.cmd` (전체화면) → **저장된 PNG를 읽어** 공지/알림 팝업이 있는지 본다.
2. 팝업이 있으면 그 **닫기(X)/확인 버튼의 (x,y)** 를 캡쳐에서 읽는다. (작아서 안 보이면 `capture.cmd --region L T W H` 로 그 부분만 확대 캡쳐해 정확히 확인.)
3. `pico.cmd click X Y` 로 누른다. (캡쳐 좌표 = 실제 픽셀이라 그대로 사용)
4. 2~3초 후 다시 `capture.cmd` → 읽어서 닫혔는지 확인.
5. 팝업이 더 있으면 1번부터 반복. 없으면 STEP 6. (같은 팝업 3번 실패 시 남기고 기록)

## STEP 6 — 최종 확인 & 보고
`kairos.cmd status` → `LOGGED_IN` 확인. (원하면 `capture.cmd` 로 최종 화면 1장 남김) → 1개 메시지 보고:
```
[카이로스 자동로그인 05:00]
- 실행: 완료 / 로그인: 성공 / 팝업: N개닫음 / 상태: LOGGED_IN
```

## ❗ 오류처리 (어느 STEP에서든 실패 시)
1. `capture.cmd` 로 화면을 찍어(진단용) 저장하고, PNG를 읽어 상황 파악.
2. `& "...\cowork\notify.cmd" "[Kairos 오류] STEP N" "상황 한두 줄 + status RESULT + 화면 메시지"` (비번 내용 절대 금지).
3. 중단하고 실패 내용 보고(캡쳐 경로 포함).

---
**핵심 반복 규칙:** ①모든 명령은 Terminal MCP로 실행 ②MCP 미준비 or 로그인 실패 시 **무조건 최대 5회 재시도**.