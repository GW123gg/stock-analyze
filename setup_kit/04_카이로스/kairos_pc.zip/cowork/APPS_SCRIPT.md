# 이메일 알림용 Apps Script (오류 발생 시 메일)

코워크가 오류를 만나면 `tools/notify.py` 가 이 Apps Script 로 POST → 메일 발송.
**수신자는 PC의 `cowork/alert_email.txt` 에서 읽어 `to` 로 넘깁니다** (Apps Script 수정 없이 메모만 바꾸면 됨).

## 세팅 (최초 1회)
1. [script.google.com](https://script.google.com) → 새 프로젝트 → 아래 코드 붙여넣기
   ```javascript
   const SHARED_SECRET = 'PASTE_LONG_RANDOM';        // notify.json 의 shared_secret 과 동일
   const DEFAULT_TO = 'you@example.com'; // to 가 없을 때 기본 수신자

   function doPost(e) {
     var b = JSON.parse(e.postData.contents);
     if (b.secret !== SHARED_SECRET) return json_({ok:false, error:'auth'});
     var to = b.to || DEFAULT_TO;
     if (b.code) {                                   // (기존 OTP 호환)
       MailApp.sendEmail(to, '[Kairos Bridge] 인증코드',
         '인증코드: ' + String(b.code) + '\n(3분 내 입력, 타인 공유 금지)');
     } else {                                        // 알림 메일
       MailApp.sendEmail(to, String(b.subject || '[Kairos] 알림'), String(b.body || ''));
     }
     return json_({ok:true});
   }
   function json_(o){ return ContentService.createTextOutput(JSON.stringify(o))
       .setMimeType(ContentService.MimeType.JSON); }
   ```
2. `SHARED_SECRET` 을 길고 무작위로 바꾸기 (예: `python -c "import secrets;print(secrets.token_urlsafe(24))"`).
3. **배포 → 새 배포 → 웹 앱**, 실행: **나**, 액세스: **모든 사용자**. Gmail 발송 권한 승인.
4. 배포 URL(끝 `/exec`)과 `SHARED_SECRET` 을 `cowork/notify.json` 에 넣기.
5. 테스트: `python tools/notify.py --test` → 메일 오면 성공.

## 보안
- 시크릿으로만 보호되므로 URL/시크릿을 공유하지 마세요.
- 수신자를 body 로 넘길 수 있으니(`to`), 시크릿이 새면 임의 주소로 발송 가능 → 시크릿을 안전히 보관.


<!-- ────────────────────────────────────────────────────────────
  ★이 파일은 공개 배포용으로 값이 지워져 있습니다.
    REPLACE_WITH_... / you@example.com / 100.64.0.1 자리에
    본인 값을 채워야 동작합니다.
──────────────────────────────────────────────────────────── -->
