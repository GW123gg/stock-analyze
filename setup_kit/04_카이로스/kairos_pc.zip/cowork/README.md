# cowork — 새벽 5시 자동 로그인 작업 공간

**★핵심 = 로컬 작업 스케줄러 (MCP·클라우드 에이전트 불필요):**
`KairosAutoLogin` 작업이 매일 05:00 에 **`kairos_iscorrect.py run`** 을 직접 실행 →
상태확인 → (필요시)실행 → **자가복구 로그인**(경고팝업 자동처리) → 검증 → **실패 시 이메일**.
클라우드 코워크가 시작 시 MCP를 못 불러 실패하던 문제를 원천 회피(로컬 스크립트라 MCP가 아예 필요 없음).

**운영 방식(재부팅 기반):** 하루 1회 **새벽 재부팅**(05:00 이전)으로 카이로스 자동 종료 →
KairosAutoLogin(05:00)이 깨끗한 상태에서 실행→로그인. (강제종료는 보안모듈이 막아 taskkill 불가 → 재부팅이 종료 담당.)

**클라우드 코워크(AGENT_PROMPT.md)는 이제 선택적** — 로그인 후 공지팝업 정리·감시·보고용. 로그인 자체는 로컬 작업이 담당.

## 구성 — ★자기완결형(필요한 코드가 모두 이 폴더 안에)
| 파일/폴더 | 내용 |
|---|---|
| `AGENT_PROMPT.md` | **예약 작업에 붙여넣을 지시서 (v3, 재부팅 기반)** |
| `kairos.cmd`/`pico.cmd`/`notify.cmd`/`capture.cmd` | 래퍼(python 풀경로로 아래 .py 실행, 별칭 문제 우회) |
| `kairos_iscorrect.py` | status/launch/login (핵심) |
| `pico_cli.py` | 피코 클릭/키(팝업 닫기 등) |
| `hid_serial.py` | **라즈베리 파이 피코 HID 드라이버** (피코 조작 코드) |
| `capture.py` | **화면 캡쳐(전체/영역/창)→PNG** — 컴퓨터유즈 대신 터미널로 캡쳐→그 PNG를 읽어 분석 |
| `notify.py` | 오류 알림 메일 발송 |
| `captures/` | 캡쳐 PNG 저장 위치 |
| `kairos_login_coords.json` | 로그인 좌표/스텝(운영용 사본) |
| `setup_task.ps1` | 관리자 1회: KairosLaunch(관리자 실행) 작업 생성 |
| `code.gs` / `APPS_SCRIPT.md` | 오류 알림 메일용 Apps Script |
| `notify.json` / `alert_email.txt` | 알림 설정 / 받을 주소 |
| `logs/` | 실행 로그 |

**피코 조작 코드(hid_serial.py 등)가 cowork/ 안에 있어** 코워크가 tools/ 밖을 참조하지 않고 동작한다.
(상위 `tools/`·`server/` 에도 같은 코드가 있지만 개발용 — 운영은 cowork/ 사본이 캐노니컬.
로그인 좌표 재보정 시 **cowork/kairos_login_coords.json** 을 수정.)

## 새벽 흐름 (요약)
1. (새벽 재부팅으로 카이로스 꺼짐 + Windows 자동로그인)
2. `status` → `NO_WINDOW` 확인
3. `launch` (KairosLaunch 작업으로 관리자 실행, UAC 없음) → 60초 → `status`=`LOGIN_OR_STARTING`
4. `login` (붙여넣기+엔터) → 60초 → `status`=`LOGGED_IN`
5. 팝업 정리(`capture.cmd`로 화면 캡쳐 → PNG를 읽어 X버튼 좌표 파악 → `pico.cmd click`) → 최종 보고
- 오류 시 어느 단계서든 메일 발송 후 중단
- **화면 확인은 전부 `capture.cmd`(터미널)** — 컴퓨터유즈 수동 승인 불필요. 캡쳐 좌표=실제 픽셀이라 피코 클릭에 그대로 사용.

## ✅ 최초 1회 체크리스트
- [x] 비번 저장: `python ..\tools\kairos_iscorrect.py setup`
- [x] 로그인 좌표: `..\kairos_login_coords.json` (붙여넣기+엔터, 검증됨)
- [ ] **작업 3개 생성**: 관리자 PowerShell에서 `setup_task.ps1` 실행 → KairosLaunch(관리자실행)·KairosKill·**KairosAutoLogin(매일05:00 run)** 생성
- [ ] **KairosAutoLogin 시간**을 재부팅 이후로 맞추기(기본 05:00). 즉시 테스트: `schtasks /Run /TN KairosAutoLogin`
- [ ] **새벽 재부팅 예약**: 5시 코워크 **이전에** 재부팅 완료되게(예: 4:45 재부팅). ※ 이미 만들어 둔 재부팅 사용
- [ ] **재부팅 후 Windows 자동 로그인**(잠금화면이면 피코·스크린샷·실행 전부 불가) — 반드시 설정
- [ ] **카이로스를 Windows 시작프로그램에 두지 않기**(루틴이 KairosLaunch로 실행) — 부팅 시 UAC 방지
- [ ] 피코 USB 연결(재부팅 후에도 유지됨) · 화면 배율 100%
- [ ] **클립보드 기록 OFF**(붙여넣기 로그인 — 비번이 잠깐 클립보드에 오름)
- [ ] 오류 알림 메일: `code.gs` 배포 → `notify.json` 채우기 → `python ..\tools\notify.py --test`

## 예약 작업(코워크) 등록
1. **컴퓨터유즈 가능한 Claude 환경**에서 매일 **05:00** 예약(재부팅 완료 후 시각).
2. 프롬프트 = `AGENT_PROMPT.md` 통째로 붙여넣기.
3. (컴퓨터유즈 팝업까지 자동화하려면) 라우틴에 **카이로스 앱 미리 승인** — 없으면 로그인까지만 무인, 팝업은 미처리로 보고.

## 참고 (지난 검증에서 확정)
- **강제종료 불가**: kairos.exe 는 관리자 taskkill 로도 안 죽음(AhnLab/nProtect 보호). → 재부팅으로 종료.
- 로그인은 **공동인증서 로그인**(붙여넣는 값=인증서 비밀번호). 매수/매도·거래비밀번호는 자동 안 함.
- 상태 판정: 로그인창 `'Kairos' 420x530` vs 로그인후 `'미래에셋증권…' 1920x1031` → status RESULT 로 구분.
- `restart`/`close`/`kill`/KairosKill 은 강제종료가 막혀 실질적으로 안 쓰임(재부팅 방식). 남겨는 둠.

## 수동 테스트
```
python ..\tools\kairos_iscorrect.py status     # 상태(RESULT) 확인
python ..\tools\kairos_iscorrect.py launch      # (꺼짐일 때) 실행
python ..\tools\kairos_iscorrect.py login       # 로그인창에서 로그인
python ..\tools\notify.py --test                # 알림 메일 테스트
```
