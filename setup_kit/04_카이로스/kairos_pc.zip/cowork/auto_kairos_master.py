"""카이로스 자동 로그인 마스터 오케스트레이터 (v2).

실행: python auto_kairos_master.py
결과: logs/auto_kairos_result.txt 에 저장됨.
보안: 비밀번호를 출력/로그/저장하지 않음. login 명령만 사용.
"""
from __future__ import annotations
import subprocess
import sys
import time
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).resolve().parent
LOGS = BASE / "logs"
LOGS.mkdir(exist_ok=True)

LOG_FILE = LOGS / "auto_kairos_result.txt"
_log_fh = None


def log(msg: str) -> None:
    global _log_fh
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    if _log_fh:
        _log_fh.write(line + "\n")
        _log_fh.flush()


def run_cmd(cmd_arg: str, timeout: int = 180) -> tuple[str, str]:
    """kairos.cmd <cmd_arg> 실행 → (stdout, stderr)."""
    script = str(BASE / "kairos.cmd")
    r = subprocess.run(
        ["cmd.exe", "/c", script, cmd_arg],
        capture_output=True, text=True, errors="replace", timeout=timeout
    )
    return r.stdout, r.stderr


def get_result(stdout: str) -> str:
    for line in stdout.splitlines():
        s = line.strip()
        if s.startswith("RESULT:"):
            return s.split("RESULT:", 1)[1].strip()
    return "UNKNOWN"


def run_notify(subject: str, body: str) -> None:
    try:
        script = str(BASE / "notify.cmd")
        subprocess.run(
            ["cmd.exe", "/c", script, subject, body],
            capture_output=True, errors="replace", timeout=30
        )
        log(f"알림 발송: {subject}")
    except Exception as e:
        log(f"알림 발송 실패: {e}")


def run_capture() -> str | None:
    """capture.cmd 실행 → 저장된 PNG 경로 반환 (SAVED: <path> 파싱)."""
    try:
        script = str(BASE / "capture.cmd")
        r = subprocess.run(
            ["cmd.exe", "/c", script],
            capture_output=True, text=True, errors="replace", timeout=30
        )
        for line in r.stdout.splitlines():
            if line.strip().startswith("SAVED:"):
                return line.strip().split("SAVED:", 1)[1].strip()
    except Exception as e:
        log(f"capture 실패: {e}")
    return None


def close_popup_with_enter(hwnd_or_window) -> bool:
    """팝업 창에 포커스 후 Enter 전송 (win32api 또는 pygetwindow)."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        # WM_KEYDOWN + WM_KEYUP VK_RETURN
        if hasattr(hwnd_or_window, "_hWnd"):
            hwnd = hwnd_or_window._hWnd
        else:
            hwnd = int(hwnd_or_window)
        user32.SetForegroundWindow(hwnd)
        time.sleep(0.3)
        user32.PostMessageW(hwnd, 0x0100, 0x0D, 0)   # WM_KEYDOWN VK_RETURN
        time.sleep(0.1)
        user32.PostMessageW(hwnd, 0x0101, 0x0D, 0)   # WM_KEYUP
        return True
    except Exception as e:
        log(f"  Enter 전송 실패: {e}")
        return False


def find_kairos_popups() -> list:
    """로그인 후 뜨는 작은 카이로스 팝업 창 목록 반환."""
    try:
        import pygetwindow as gw
        keywords = ("미래에셋", "카이로스", "Kairos", "KAIROS")
        all_wins = [w for w in gw.getAllWindows()
                    if any(k in (w.title or "") for k in keywords)
                    and getattr(w, "visible", True)
                    and w.width > 0 and w.height > 0]
        # 메인 HTS(큰 창) 제외 → 작은 팝업만
        popups = [w for w in all_wins if w.width < 1000 or w.height < 700]
        return popups
    except Exception as e:
        log(f"창 목록 조회 실패: {e}")
        return []


def main() -> None:
    log("=" * 52)
    log("카이로스 자동 로그인 마스터 시작")

    # ── STEP 0/1 상태 확인 (최대 5회) ──────────────────
    status_result = None
    for attempt in range(1, 6):
        try:
            stdout, _ = run_cmd("status", timeout=30)
            status_result = get_result(stdout)
            log(f"[STEP 0] status 시도 {attempt}: {status_result}")
            for line in stdout.strip().splitlines():
                log(f"  {line}")
            break
        except Exception as e:
            log(f"[STEP 0] status 시도 {attempt} 오류: {e}")
            if attempt < 5:
                time.sleep(5)

    if not status_result or status_result == "UNKNOWN":
        msg = "status 명령 5회 연속 실패"
        log(f"오류: {msg}")
        run_notify("[Kairos 오류] STEP 0", msg)
        return

    # ── STEP 1 판정 ─────────────────────────────────────
    if status_result == "LOGGED_IN":
        msg = "카이로스가 이미 실행(LOGGED_IN) — 재부팅 확인 필요"
        log(f"오류: {msg}")
        run_notify("[Kairos 오류] 이미 실행 중", msg)
        return

    # ── STEP 2 — NO_WINDOW → launch ─────────────────────
    if status_result == "NO_WINDOW":
        log("[STEP 2] kairos.cmd launch 실행")
        try:
            stdout, stderr = run_cmd("launch", timeout=60)
            log(stdout.strip() or "(출력 없음)")
            if stderr.strip():
                log(f"  STDERR: {stderr.strip()[:200]}")
        except Exception as e:
            msg = f"launch 실패: {e}"
            log(f"오류: {msg}")
            run_notify("[Kairos 오류] STEP 2 launch", msg)
            return

        log("60초 대기 (카이로스 기동)...")
        time.sleep(60)

        for attempt in range(1, 3):
            try:
                stdout, _ = run_cmd("status", timeout=30)
                status_result = get_result(stdout)
                log(f"launch 후 STATUS (시도 {attempt}): {status_result}")
                break
            except Exception as e:
                log(f"STATUS 확인 실패: {e}")
                time.sleep(5)

        if status_result == "NO_WINDOW":
            log("추가 60초 대기 후 재확인...")
            time.sleep(60)
            try:
                stdout, _ = run_cmd("status", timeout=30)
                status_result = get_result(stdout)
                log(f"재확인 STATUS: {status_result}")
            except Exception as e:
                log(f"재확인 실패: {e}")

        if status_result not in ("LOGIN_OR_STARTING", "LOGGED_IN"):
            msg = f"launch 후 창 없음 (RESULT: {status_result})"
            log(f"오류: {msg}")
            run_notify("[Kairos 오류] STEP 2", msg)
            return

    # ── STEP 3 — login (최대 5회) ────────────────────────
    login_success = False
    if status_result == "LOGGED_IN":
        login_success = True
    else:
        for attempt in range(1, 6):
            log(f"[STEP 3] login 시도 {attempt}/5")
            try:
                stdout, stderr = run_cmd("login", timeout=180)
                for line in (stdout.strip() or "(출력 없음)").splitlines():
                    log(f"  {line}")
                if stderr.strip():
                    log(f"  STDERR: {stderr.strip()[:300]}")
            except Exception as e:
                log(f"  login 오류: {e}")
                time.sleep(5)
                continue

            log("60초 대기 후 status 확인...")
            time.sleep(60)

            try:
                stdout, _ = run_cmd("status", timeout=30)
                status_result = get_result(stdout)
                log(f"  login 후 STATUS: {status_result}")
            except Exception as e:
                log(f"  STATUS 확인 실패: {e}")
                continue

            if status_result == "LOGGED_IN":
                login_success = True
                break
            log(f"  미완료 (RESULT: {status_result}) → 재시도")
            time.sleep(5)

    if not login_success:
        cap = run_capture()
        msg = f"login 5회 실패 (마지막 RESULT: {status_result})"
        log(f"오류: {msg}" + (f" | 캡쳐: {cap}" if cap else ""))
        run_notify("[Kairos 오류] STEP 3 login", msg)
        return

    log("[STEP 4] LOGGED_IN 확인 ✅")

    # ── STEP 5 — 로그인 후 팝업 닫기 (최대 8회) ─────────
    popups_closed = 0
    log("[STEP 5] 로그인 후 팝업 정리 시작")
    for iteration in range(8):
        time.sleep(2)
        popups = find_kairos_popups()
        if not popups:
            log(f"  팝업 없음 (반복 {iteration + 1}) → 완료")
            break
        log(f"  팝업 {len(popups)}개 발견")
        closed_this_round = 0
        for pw in popups:
            title = getattr(pw, "title", "?")
            w = getattr(pw, "width", 0)
            h = getattr(pw, "height", 0)
            left = getattr(pw, "left", 0)
            top = getattr(pw, "top", 0)
            log(f"    '{title}' {w}x{h} @({left},{top})")
            if close_popup_with_enter(pw):
                popups_closed += 1
                closed_this_round += 1
                log(f"    → Enter 전송 완료")
            time.sleep(1)
        if closed_this_round == 0:
            log("  팝업 닫기 실패 — 남은 팝업 기록 후 진행")
            break

    # ── STEP 6 — 최종 확인 ──────────────────────────────
    try:
        stdout, _ = run_cmd("status", timeout=30)
        final_result = get_result(stdout)
    except Exception:
        final_result = "UNKNOWN"
    log(f"[STEP 6] 최종 STATUS: {final_result}")

    cap = run_capture()
    if cap:
        log(f"최종 캡쳐: {cap}")

    summary = (
        f"실행: 완료 / 로그인: 성공 / "
        f"팝업: {popups_closed}개 닫음 / 상태: {final_result}"
    )
    log(f"[카이로스 자동로그인 완료] {summary}")
    run_notify("[Kairos] 자동로그인 완료", summary)


if __name__ == "__main__":
    with open(LOG_FILE, "w", encoding="utf-8") as fh:
        _log_fh = fh
        try:
            main()
        except Exception as e:
            import traceback
            log(f"치명 오류: {e}")
            log(traceback.format_exc())
        finally:
            log("=" * 52)
