@echo off
rem Wrapper: run capture.py with full python path (PATH alias 'python' fails in non-interactive shell)
rem Usage: capture.cmd  |  capture.cmd --region L T W H  |  capture.cmd --window "title"  |  capture.cmd --list
setlocal
set "PY="
for /d %%D in ("C:\Users\USER\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.*") do set "PY=%%D\python.exe"
if not defined PY for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do set "PY=%%D\python.exe"
if not defined PY set "PY=python"
"%PY%" "C:\Users\USER\Desktop\mirae asset securities auto\cowork\capture.py" %*
