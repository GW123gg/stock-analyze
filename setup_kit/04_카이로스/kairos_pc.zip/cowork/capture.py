"""화면 캡쳐 — 코워크가 터미널(Terminal MCP)로 실행해 화면을 PNG로 저장(컴퓨터유즈 불필요).

전체/영역/창 을 캡쳐하고 저장 경로를 'SAVED: <경로>' 로 출력한다.
에이전트는 그 PNG 파일을 '읽어서' 화면을 분석한다(팝업 위치 파악 등).

사용:
  python cowork/capture.py                              # 주 모니터 전체
  python cowork/capture.py --out C:\\path\\a.png          # 전체 → 지정 경로
  python cowork/capture.py --region 700 400 500 300      # 영역(왼쪽 위쪽 너비 높이)
  python cowork/capture.py --window "미래에셋"             # 창 제목(부분일치)의 영역만
  python cowork/capture.py --list                        # 보이는 창 목록(제목/좌표) 출력

좌표계 = 실제 화면 픽셀(배율 100% 기준). 피코 클릭 좌표와 동일 기준이라,
캡쳐에서 찾은 (x,y) 를 그대로 `pico.cmd click X Y` 에 쓸 수 있다.
저장 위치 기본값: cowork/captures/cap_<날짜시각>.png
"""
from __future__ import annotations

import argparse
import ctypes
import sys
import time
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")   # mss DeprecationWarning 등 출력 정리

try:
    sys.stdout.reconfigure(errors="replace")
    sys.stderr.reconfigure(errors="replace")
except Exception:
    pass

# 배율과 무관하게 '물리 픽셀'로 캡쳐 (per-monitor DPI aware).
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

HERE = Path(__file__).resolve().parent
CAP_DIR = HERE / "captures"


def _default_out() -> Path:
    CAP_DIR.mkdir(exist_ok=True)
    return CAP_DIR / (time.strftime("cap_%Y%m%d_%H%M%S") + ".png")


def _windows():
    import pygetwindow as gw
    out = []
    for w in gw.getAllWindows():
        t = (w.title or "").strip()
        if t and w.width > 0 and w.height > 0 and bool(getattr(w, "visible", True)):
            out.append((t, w.left, w.top, w.width, w.height))
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="screen capture for cowork")
    ap.add_argument("--out", help="저장 경로(.png). 없으면 captures/ 에 자동 파일명")
    ap.add_argument("--region", nargs=4, type=int, metavar=("L", "T", "W", "H"),
                    help="영역: 왼쪽 위쪽 너비 높이")
    ap.add_argument("--window", help="창 제목(부분일치)의 영역만 캡쳐")
    ap.add_argument("--list", action="store_true", help="보이는 창 목록만 출력하고 종료")
    args = ap.parse_args()

    if args.list:
        for t, l, tp, w, h in _windows():
            print(f"  '{t}' @({l},{tp}) {w}x{h}")
        return 0

    region = None
    if args.window:
        hit = next((r for r in _windows() if args.window in r[0]), None)
        if not hit:
            print(f"⛔ 창을 못 찾음: '{args.window}'  (--list 로 제목 확인)")
            return 1
        t, l, tp, w, h = hit
        region = (l, tp, w, h)
        print(f"WINDOW: '{t}' @({l},{tp}) {w}x{h}")
    elif args.region:
        region = tuple(args.region)

    try:
        import mss
        import mss.tools
    except Exception as e:  # noqa: BLE001
        print(f"⛔ mss 미설치: {e}  (pip install mss)")
        return 1

    out = Path(args.out) if args.out else _default_out()
    out.parent.mkdir(parents=True, exist_ok=True)
    with mss.mss() as sct:
        if region:
            l, t, w, h = region
            mon = {"left": int(l), "top": int(t), "width": int(w), "height": int(h)}
        else:
            mon = sct.monitors[1]   # 주 모니터 전체
        img = sct.grab(mon)
        mss.tools.to_png(img.rgb, img.size, output=str(out))

    print(f"SIZE: {img.size[0]}x{img.size[1]}")
    print(f"SAVED: {out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
