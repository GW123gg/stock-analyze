/**
 * 카이로스 코워크 알림 메일 + (기존 OTP 호환) Apps Script
 *
 * 배포:
 *   1) script.google.com → 새 프로젝트 → 이 파일 내용 붙여넣기
 *   2) SHARED_SECRET 을 길고 무작위로 바꾸고, cowork/notify.json 의 shared_secret 과 동일하게
 *   3) 배포 → 새 배포 → 웹 앱 (실행: 나 / 액세스: 모든 사용자) → Gmail 권한 승인
 *   4) 배포 URL(끝 /exec)을 cowork/notify.json 의 apps_script_url 에 입력
 *   5) 테스트: python tools/notify.py --test
 *
 * 요청 형식(POST JSON):
 *   알림 메일 : {"secret": "...", "to": "받는주소", "subject": "제목", "body": "본문"}
 *   OTP(호환) : {"secret": "...", "code": "123456"}
 * to 가 없으면 DEFAULT_TO 로 보냄.
 */

const SHARED_SECRET = 'mn6icLVXnm5xGOp-M_ucCyCCDdlZ4Ka_DXtjH9f0hvA';        // ★ notify.json 의 shared_secret 과 동일하게 바꾸기
const DEFAULT_TO = 'you@example.com';       // to 가 없을 때 기본 수신자

function doPost(e) {
  var b;
  try {
    b = JSON.parse(e.postData.contents);
  } catch (err) {
    return json_({ ok: false, error: 'bad_json' });
  }
  if (b.secret !== SHARED_SECRET) {
    return json_({ ok: false, error: 'auth' });
  }
  var to = b.to || DEFAULT_TO;

  if (b.code) {                                   // 기존 OTP 호환
    MailApp.sendEmail(
      to,
      '[Kairos Bridge] 인증코드',
      '인증코드: ' + String(b.code) + '\n(3분 내 입력, 타인 공유 금지)'
    );
  } else {                                        // 알림 메일
    MailApp.sendEmail(
      to,
      String(b.subject || '[Kairos] 알림'),
      String(b.body || '')
    );
  }
  return json_({ ok: true });
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
