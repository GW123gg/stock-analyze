"""파이썬 ↔ Pico(HID 키보드) USB 시리얼 브리지.

서버가 이 모듈로 Pico 에 "이 텍스트 타이핑해" 명령을 보내면, Pico 가 실물 USB 키보드로 입력한다.
마우스는 pyautogui, 키보드(숫자 입력)는 이 Pico 가 담당 → 안랩 키보드보안을 우회하지 않고 통과.
"""
from __future__ import annotations

import random
import threading
import time

try:
    import serial
    from serial.tools import list_ports

    AVAILABLE = True
    IMPORT_ERROR = ""
except Exception as exc:  # pragma: no cover
    AVAILABLE = False
    IMPORT_ERROR = str(exc)


def find_pico_port() -> str | None:
    """Pico(RP2040, VID 2E8A)로 보이는 COM 포트를 자동 탐색."""
    if not AVAILABLE:
        return None
    for p in list_ports.comports():
        blob = f"{p.description} {p.manufacturer} {p.hwid}".lower()
        if any(k in blob for k in ("pico", "circuitpython", "board cdc", "2e8a", "239a")):
            return p.device
    return None


class PicoHID:
    def __init__(self, port: str | None = None, baud: int = 115200):
        self.port = port
        self.baud = baud
        self._ser = None
        self._lock = threading.Lock()

    def connect(self) -> None:
        if not AVAILABLE:
            raise RuntimeError(f"pyserial 미설치: {IMPORT_ERROR}  (pip install pyserial)")
        port = self.port or find_pico_port()
        if not port:
            raise RuntimeError("Pico COM 포트를 못 찾음 — 장치관리자에서 확인 후 config 에 직접 지정")
        self.port = port
        self._ser = serial.Serial(port, self.baud, timeout=2)
        time.sleep(1.5)  # 보드 준비 대기

    def close(self) -> None:
        if self._ser:
            self._ser.close()
            self._ser = None

    def _send(self, line: str) -> None:
        if not self._ser:
            raise RuntimeError("connect() 를 먼저 호출하세요.")
        with self._lock:
            self._ser.write((line + "\n").encode())
            self._ser.flush()
            time.sleep(0.03)

    # ---- 고수준 API ----
    def type_text(self, text: str) -> None:
        self._send("T:" + str(text))

    def key(self, name: str) -> None:
        """ENTER / TAB / ESC / CLEAR / SELALL / PASTE"""
        self._send(str(name).upper())

    def select_all(self) -> None:
        self._send("SELALL")

    def paste(self) -> None:
        """클립보드 값을 Ctrl+V 로 붙여넣기(실물 HID)."""
        self._send("PASTE")

    def clear_and_type(self, text: str) -> None:
        self._send("CLEAR")
        time.sleep(0.08)
        self._send("T:" + str(text))

    def type_slow(self, text: str, char_min: float = 0.3,
                  char_max: float = 0.5) -> None:
        """한 글자씩 랜덤 딜레이로 입력 — 보안 키보드필드가 빠른 입력을 흘릴 때 사용.

        공백/탭은 한 글자 전송 시 펌웨어 strip 에 걸려 유실되므로 지원하지 않는다
        (로그인 비번엔 공백이 거의 없음). 있으면 예외를 던져 안전하게 중단.
        """
        text = str(text)
        if any(c.isspace() for c in text):
            raise ValueError("공백/탭 포함 문자열은 type_slow 로 입력 불가 "
                             "(한 글자씩 경로 제약). 펌웨어 업데이트 필요.")
        for ch in text:
            self._send("T:" + ch)
            time.sleep(random.uniform(char_min, char_max))

    # ---- 마우스 ----
    def move(self, dx: int, dy: int) -> None:
        """상대 이동(nudge)."""
        self._send(f"M:{int(dx)},{int(dy)}")

    def move_abs(self, x: int, y: int) -> None:
        """절대 위치(화면 픽셀)로 이동 — 피코가 홈 후 이동. 마우스가속 OFF 필요."""
        self._send(f"A:{int(x)},{int(y)}")

    def click(self) -> None:
        self._send("CLICK")

    def right_click(self) -> None:
        self._send("RCLICK")

    def double_click(self) -> None:
        self._send("DCLICK")
