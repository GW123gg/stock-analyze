@echo off
rem Wrapper: run kairos_iscorrect.py with full python path (PATH alias 'python' fails in non-interactive shell)
rem Usage: kairos.cmd restart | status | login | kill | launch
setlocal
set "PY="
for /d %%D in ("C:\Users\USER\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.*") do set "PY=%%D\python.exe"
if not defined PY for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do set "PY=%%D\python.exe"
if not defined PY set "PY=python"
"%PY%" "C:\Users\USER\Desktop\mirae asset securities auto\cowork\kairos_iscorrect.py" %*
