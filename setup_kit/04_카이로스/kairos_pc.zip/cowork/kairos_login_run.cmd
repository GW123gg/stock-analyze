@echo off
set "PY=C:\Users\USER\AppData\Local\Microsoft\WindowsApps\python3.12.exe"
"%PY%" "C:\Users\USER\Desktop\mirae asset securities auto\cowork\kairos_iscorrect.py" login >> "C:\Users\USER\Desktop\mirae asset securities auto\cowork\logs\login_run.log" 2>&1
