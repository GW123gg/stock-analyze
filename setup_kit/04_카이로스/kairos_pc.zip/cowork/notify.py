"""오류/상태 이메일 알림 — Google Apps Script(MailApp) 로 발송.

수신자는 '메모파일'에서 읽는다: cowork/alert_email.txt (사용자가 메일주소만 한 줄 적음).
Apps Script URL/시크릿은 cowork/notify.json 에서 읽는다(비밀 — 공유 금지).

사용:
  python cowork/notify.py "제목" "본문 내용"
  python cowork/notify.py --test              # 테스트 메일 발송
  python cowork/notify.py --to you@example.com "제목" "본문"   # 수신자 직접 지정(메모파일 무시)

종료코드 0=발송 성공. 메일 자체가 실패하면 1(그땐 메일로 알릴 수 없으니 화면에만 출력).
"""
from __future__ import annotations

import json
import sys
import urllib.request
from pathlib import Path

# 콘솔 인코딩(cp949 등)에서 표현 불가한 문자가 있어도 크래시하지 않도록.
try:
    sys.stdout.reconfigure(errors="replace")
    sys.stderr.reconfigure(errors="replace")
except Exception:
    pass

COWORK = Path(__file__).resolve().parent   # cowork/ (자기완결형)
EMAIL_MEMO = COWORK / "alert_email.txt"
NOTIFY_CFG = COWORK / "notify.json"


def _read_recipient() -> str:
    if not EMAIL_MEMO.exists():
        raise SystemExit(f"⛔ 수신 메일 메모 없음: {EMAIL_MEMO}\n"
                         f"   메모장으로 이 파일에 받을 메일주소 한 줄만 적으세요.")
    for line in EMAIL_MEMO.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if s and not s.startswith("#") and "@" in s:
            return s
    raise SystemExit(f"⛔ {EMAIL_MEMO} 에 유효한 메일주소가 없습니다.")


def _read_cfg() -> dict:
    if not NOTIFY_CFG.exists():
        raise SystemExit(f"⛔ 알림 설정 없음: {NOTIFY_CFG}\n"
                         f"   apps_script_url / shared_secret 를 채우세요.")
    cfg = json.loads(NOTIFY_CFG.read_text(encoding="utf-8"))
    if not cfg.get("apps_script_url") or not cfg.get("shared_secret"):
        raise SystemExit("⛔ notify.json 의 apps_script_url/shared_secret 이 비어 있음.")
    return cfg


def send(subject: str, body: str, to: str | None = None) -> bool:
    cfg = _read_cfg()
    recipient = to or _read_recipient()
    payload = json.dumps({
        "secret": cfg["shared_secret"],
        "to": recipient,
        "subject": subject,
        "body": body,
    }).encode()
    req = urllib.request.Request(
        cfg["apps_script_url"], data=payload,
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            resp.read()
        print(f"메일 발송됨 → {recipient} / 제목: {subject}")
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"⛔ 메일 발송 실패: {exc}")
        return False


def main() -> int:
    args = sys.argv[1:]
    to = None
    if args and args[0] == "--to":
        to = args[1]
        args = args[2:]
    if args and args[0] == "--test":
        ok = send("[Kairos] 테스트 알림", "notify.py 테스트 메일입니다.", to)
        return 0 if ok else 1
    if len(args) < 2:
        print(__doc__)
        return 2
    ok = send(args[0], args[1], to)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
