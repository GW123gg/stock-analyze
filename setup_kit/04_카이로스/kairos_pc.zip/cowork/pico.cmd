@echo off
rem Wrapper: run pico_cli.py with full python path
rem Usage: pico.cmd click X Y
setlocal
set "PY="
for /d %%D in ("C:\Users\USER\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.*") do set "PY=%%D\python.exe"
if not defined PY for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do set "PY=%%D\python.exe"
if not defined PY set "PY=python"
"%PY%" "C:\Users\USER\Desktop\mirae asset securities auto\cowork\pico_cli.py" %*
