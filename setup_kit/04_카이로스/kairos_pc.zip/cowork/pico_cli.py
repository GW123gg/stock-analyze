"""피코 HID CLI — 예약 에이전트(코워크)가 터미널로 클릭/입력 신호를 보낼 때 사용.

⚠ 비밀번호 등 민감정보는 이 CLI 로 넘기지 말 것(인자로 남음).
   로그인 비번 입력은 반드시 kairos_iscorrect.py login 사용.

사용:
  python cowork/pico_cli.py click X Y       # (X,Y)로 절대이동 후 좌클릭  ← 팝업 닫기 등
  python cowork/pico_cli.py move X Y        # 이동만(좌표 확인용)
  python cowork/pico_cli.py dclick X Y      # 더블클릭
  python cowork/pico_cli.py type "텍스트"    # 현재 포커스에 타이핑(비밀 아님)
  python cowork/pico_cli.py cleartype "텍스트"
  python cowork/pico_cli.py key ENTER|TAB|ESC|CLEAR

종료코드 0=성공. 좌표는 화면 배율 100% 기준.
"""
import ctypes
import sys
import time
from pathlib import Path

# 콘솔 인코딩(cp949 등)에서 표현 불가한 문자가 있어도 크래시하지 않도록.
try:
    sys.stdout.reconfigure(errors="replace")
    sys.stderr.reconfigure(errors="replace")
except Exception:
    pass

BASE = Path(__file__).resolve().parent   # cowork/ (자기완결형)
sys.path.insert(0, str(BASE))

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

from hid_serial import PicoHID, find_pico_port  # noqa: E402  (cowork/hid_serial.py)

_u = ctypes.windll.user32
SPI_GETMOUSE, SPI_SETMOUSE = 0x0003, 0x0004
SPI_GETMOUSESPEED, SPI_SETMOUSESPEED = 0x0070, 0x0071


def _accel_off_save():
    a = (ctypes.c_int * 3)()
    _u.SystemParametersInfoW(SPI_GETMOUSE, 0, a, 0)
    s = ctypes.c_int()
    _u.SystemParametersInfoW(SPI_GETMOUSESPEED, 0, ctypes.byref(s), 0)
    _u.SystemParametersInfoW(SPI_SETMOUSE, 0, (ctypes.c_int * 3)(0, 0, 0), 0)
    _u.SystemParametersInfoW(SPI_SETMOUSESPEED, 0, ctypes.c_void_p(10), 0)
    return a, s


def _accel_restore(saved):
    a, s = saved
    _u.SystemParametersInfoW(SPI_SETMOUSE, 0, a, 0)
    _u.SystemParametersInfoW(SPI_SETMOUSESPEED, 0, ctypes.c_void_p(s.value), 0)


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 2
    cmd = args[0]
    p = PicoHID(find_pico_port())
    p.connect()
    try:
        if cmd in ("click", "move", "dclick"):
            if len(args) < 3:
                print("usage: %s X Y" % cmd); return 2
            x, y = int(args[1]), int(args[2])
            saved = _accel_off_save()
            try:
                p.move_abs(x, y)
                time.sleep(0.35)
                if cmd == "click":
                    p.click()
                    time.sleep(0.3)
                elif cmd == "dclick":
                    p.double_click()
                    time.sleep(0.3)
            finally:
                _accel_restore(saved)
            print(f"{cmd} {x},{y} 완료")
        elif cmd == "type":
            p.type_text(args[1])
            print("type 완료")
        elif cmd == "cleartype":
            p.clear_and_type(args[1])
            print("cleartype 완료")
        elif cmd == "key":
            p.key(args[1])
            print(f"key {args[1]} 완료")
        else:
            print(f"알 수 없는 명령: {cmd}")
            print(__doc__)
            return 2
    finally:
        p.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
