
' run_master.vbs — auto_kairos_master.py 를 숨긴 cmd 창으로 실행하고 완료까지 대기.
' Win+R 에서: wscript "C:\Users\USER\Desktop\mirae asset securities auto\cowork\run_master.vbs"

Option Explicit

Dim objShell, objFSO, strBase, strPy, strCmd

Set objShell = CreateObject("WScript.Shell")
Set objFSO   = CreateObject("Scripting.FileSystemObject")

strBase = "C:\Users\USER\Desktop\mirae asset securities auto\cowork"

' Python 경로 자동 탐색
strPy = ""
Dim sPaths(5)
sPaths(0) = objShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\Python\Python312\python.exe")
sPaths(1) = objShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\Python\Python311\python.exe")
sPaths(2) = objShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\Python\Python310\python.exe")
sPaths(3) = objShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe")
sPaths(4) = "python.exe"
sPaths(5) = "python"

Dim i
For i = 0 To 4
    If objFSO.FileExists(sPaths(i)) Then
        strPy = sPaths(i)
        Exit For
    End If
Next
If strPy = "" Then strPy = "python"

' 명령 구성: python auto_kairos_master.py >> log 2>&1
strCmd = "cmd.exe /c """ & strPy & """ """ & strBase & "\auto_kairos_master.py"" >> """ _
       & strBase & "\logs\auto_kairos_vbs.log"" 2>&1"

' 0 = 숨김 창, bWaitOnReturn = True
objShell.Run strCmd, 0, True

WScript.Echo "카이로스 자동 로그인 완료. logs\auto_kairos_result.txt 확인."
