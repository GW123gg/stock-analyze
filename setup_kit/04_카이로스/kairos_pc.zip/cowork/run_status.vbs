Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")
Dim strBase
strBase = "C:\Users\USER\Desktop\mirae asset securities auto\cowork"

' Run kairos.cmd status and capture output
Dim objExec
Set objExec = objShell.Exec("cmd.exe /c """ & strBase & "\kairos.cmd"" status")
Dim strOutput
strOutput = objExec.StdOut.ReadAll()
Dim strErr
strErr = objExec.StdErr.ReadAll()

' Save to output file
Dim objFile
Set objFile = objFSO.CreateTextFile(strBase & "\logs\vbs_status_out.txt", True)
objFile.Write strOutput
objFile.Close

Set objFile = objFSO.CreateTextFile(strBase & "\logs\vbs_status_err.txt", True)
objFile.Write strErr
objFile.Close

WScript.Echo "Done"
