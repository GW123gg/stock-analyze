# Create scheduled tasks that run kairos elevated WITHOUT a UAC prompt.
#   KairosLaunch : starts kairos.exe (requireAdministrator) elevated
#   KairosKill   : force-kills all kairos processes (also needs elevation to kill elevated procs)
#
# >> Run this ONCE in an ADMINISTRATOR PowerShell.
#    (Start -> PowerShell -> right-click -> Run as administrator)
#
# After creation, both tasks can be triggered with normal rights via /Run,
# so cowork (non-elevated) only calls them. Korean install path is read from the
# JSON as UTF-8, so this script stays ASCII-only (no encoding issues).

$ErrorActionPreference = 'Stop'

$cfgPath = "C:\Users\USER\Desktop\mirae asset securities auto\kairos_login_coords.json"
if (-not (Test-Path $cfgPath)) { Write-Host "Config not found: $cfgPath" -ForegroundColor Red; exit 1 }

$cfg = Get-Content -Raw -Encoding UTF8 $cfgPath | ConvertFrom-Json
$exe = $cfg.launch_path
$dir = Split-Path $exe -Parent

if ([string]::IsNullOrWhiteSpace($exe) -or -not (Test-Path $exe)) {
  Write-Host "kairos.exe not found at: $exe" -ForegroundColor Red
  Write-Host "  Fix 'launch_path' in kairos_login_coords.json" -ForegroundColor Yellow
  exit 1
}

$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)

# --- KairosLaunch ---
$launchAction = New-ScheduledTaskAction -Execute $exe -WorkingDirectory $dir
Register-ScheduledTask -TaskName "KairosLaunch" -Action $launchAction -Principal $principal -Settings $settings -Force | Out-Null
Write-Host "OK: 'KairosLaunch' created." -ForegroundColor Green

# --- KairosKill ---  (image names observed: kairos.exe / kairosrun.exe / kairosga4.exe / chromekairos.exe)
$killArgs   = "/F /T /IM kairos.exe /IM kairosrun.exe /IM kairosga4.exe /IM chromekairos.exe"
$killAction = New-ScheduledTaskAction -Execute "taskkill.exe" -Argument $killArgs
Register-ScheduledTask -TaskName "KairosKill" -Action $killAction -Principal $principal -Settings $settings -Force | Out-Null
Write-Host "OK: 'KairosKill' created." -ForegroundColor Green

# --- KairosAutoLogin : run the unattended auto-login (run) daily at 05:00 (normal rights, needs logon session) ---
#   run = status -> (if needed) launch -> login(self-recovering) -> verify -> email on failure. No MCP/agent needed.
$runCmd       = "C:\Users\USER\Desktop\mirae asset securities auto\cowork\kairos.cmd"
$coworkDir    = "C:\Users\USER\Desktop\mirae asset securities auto\cowork"
$runAction    = New-ScheduledTaskAction -Execute $runCmd -Argument "run" -WorkingDirectory $coworkDir
$runPrincipal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$runSettings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit ([TimeSpan]::FromMinutes(15))
$runTrigger   = New-ScheduledTaskTrigger -Daily -At '5:00AM'
Register-ScheduledTask -TaskName "KairosAutoLogin" -Action $runAction -Principal $runPrincipal -Settings $runSettings -Trigger $runTrigger -Force | Out-Null
Write-Host "OK: 'KairosAutoLogin' created (daily 05:00, normal rights)." -ForegroundColor Green
Write-Host "   * Make sure the reboot finishes before 05:00. To change time: edit KairosAutoLogin trigger in Task Scheduler." -ForegroundColor Yellow

# --- KairosServer : Tailscale Funnel + bridge server (uvicorn 8443), daily 05:00 ---
#   start_server.cmd (no args) = funnel public 443 -> local 8443, then run the server.
#   Runs all day until the next reboot. Survives crashes (RestartCount). Normal rights, interactive session.
#   Capture tolerates Kairos not being up yet, so 05:00 alongside KairosAutoLogin is fine.
#   If Funnel needs elevation on this machine, change -RunLevel Limited to Highest below.
$srvCmd       = "C:\Users\USER\Desktop\mirae asset securities auto\start_server.cmd"
$projDir      = "C:\Users\USER\Desktop\mirae asset securities auto"
$srvAction    = New-ScheduledTaskAction -Execute $srvCmd -WorkingDirectory $projDir
$srvPrincipal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$srvSettings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
                  -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
$srvTrigger   = New-ScheduledTaskTrigger -Daily -At '5:00AM'
Register-ScheduledTask -TaskName "KairosServer" -Action $srvAction -Principal $srvPrincipal -Settings $srvSettings -Trigger $srvTrigger -Force | Out-Null
Write-Host "OK: 'KairosServer' created (daily 05:00, port 8443, runs until reboot)." -ForegroundColor Green

Write-Host ""
Write-Host "Done. Test with normal rights:" -ForegroundColor Cyan
Write-Host "   python cowork/kairos_iscorrect.py run      (manual test of the full unattended sequence)"
Write-Host "   schtasks /Run /TN KairosAutoLogin          (trigger the auto-login task now)"
Write-Host "   schtasks /Run /TN KairosServer             (start the server now)"
Write-Host "   start_server.cmd                           (run the server in this window instead)"
Get-ScheduledTask -TaskName "KairosLaunch","KairosKill","KairosAutoLogin","KairosServer" | Select-Object TaskName, State
