# 원격 호가·주문 — 서버 상시 호스팅 + Tailscale Funnel (1단계: 기반)

전용 노트북에서 **FastAPI 서버를 상시** 띄우고, **Tailscale Funnel**로 안전하게 노출해
아이폰/웹에서 **호가창을 실시간으로 보고**(1단계), 나중에 주문까지(2단계) 하기 위한 설정.

서버 코드: `server/app.py` (이미 인증·MJPEG스트림·주문엔드포인트·안전장치·긴급정지 골격 있음)
웹 UI: `web/index.html` (반응형 → 아이폰 사파리에서 그대로 = "아이폰 앱" 역할)

---

## 0. 준비
- 전용 노트북에 이 프로젝트 + Python 패키지 설치(`pip install -r requirements.txt`).
- 자동로그인(cowork/)이 먼저 동작해 카이로스가 로그인돼 있어야 호가창이 보인다.
- Tailscale 설치 + 로그인(두 기기 같은 tailnet).

## 1. config.toml 만들기
`config.example.toml` 을 복사해 `config.toml` 로 만들고 채운다:
```toml
[server]
host = "0.0.0.0"     # Funnel/타 기기 접속 위해
port = 8443          # Funnel 허용 포트(443/8443/10000) 중 하나

[auth]
access_token = "<python -c \"import secrets;print(secrets.token_urlsafe(32))\" 로 생성한 긴 무작위>"
session_ttl_seconds = 3600
cookie_secure = true

[capture]
mode = "region"      # 호가창 영역만
window_title = "미래에셋"
# 호가창 영역(실제 화면 픽셀). tools/pick_region.py 로 좌상단/우하단을 찍어 채운다.
left = 0
top = 100
width = 700
height = 620
fps = 4
jpeg_quality = 70

[trading]
live_enabled = false   # ★2단계 검증 전까지 반드시 false (DRY-RUN)
max_order_qty = 10
max_notional_krw = 2000000
price_band_pct = 5.0

[account]
source = "manual"
cash_only = true       # 현금계좌만(미수/신용/공매도 금지) — 변경 금지 권장
positions_file = "positions.json"

[otp]
enabled = false        # (선택) 이메일 2차인증. 켜면 로그인에 보안키+이메일코드 둘 다 필요
```
> `config.toml`·`positions.json` 은 **비밀** — 공유/커밋 금지.

## 2. 호가창 캡쳐 영역 잡기
```
python tools/pick_region.py     # 호가창 좌상단→우하단 드래그 → 좌표를 config [capture] 에 기입
```
(카이로스 [0611] 주식주문 창의 왼쪽 호가 부분만 잡으면 스트림이 가벼움. mode 를 실행 중 "window"(전체창)로 토글도 가능.)

## 3. 서버 실행 (수동 테스트)
```
uvicorn server.app:app --host 0.0.0.0 --port 8443
```
같은 노트북 브라우저에서 `http://127.0.0.1:8443` → 보안키 입력 → 호가창 스트림이 보이면 OK.

## 4. Tailscale Funnel 로 노출
Funnel = tailnet 밖(인터넷)에서도 HTTPS로 접속. (VPN 없이 아이폰 사파리에서 바로)
```
tailscale funnel 8443
```
- 처음이면 Funnel 권한 활성화 필요: Tailscale admin 콘솔 → 이 기기 → Funnel 허용, 또는 `tailscale funnel` 안내대로.
- 출력된 **`https://<기기>.<tailnet>.ts.net/`** 주소가 공개 접속 URL.
- ⚠️ Funnel은 인터넷에 공개되므로 **반드시 강한 access_token**(+선택 OTP)로 보호. 포트는 443/8443/10000만 허용.
- 더 안전하게: Funnel 대신 **tailscale serve**(tailnet 내부만) 를 쓰면 내 기기들만 접속(공개 안 됨). 외부에서 꼭 필요할 때만 Funnel.

## 5. 아이폰/웹에서 접속
- 아이폰 사파리로 위 `https://….ts.net/` 접속 → 보안키 입력 → 호가창 실시간 보기.
- **홈 화면에 추가**하면 앱처럼 전체화면(PWA) 으로 쓸 수 있음(= "아이폰 앱").
- (2단계 후) 주문 폼도 이 화면에서.

## 6. 상시 호스팅 (부팅/로그온 시 자동 실행)
로그온 시 서버를 자동으로 띄우는 예약작업(일반권한, 인터랙티브):
```powershell
# 관리자 아님 - 일반 PowerShell. 경로는 실제 위치로.
$py  = (Get-Command python).Source   # 또는 python 풀경로
$args = "-m uvicorn server.app:app --host 0.0.0.0 --port 8443"
$act = New-ScheduledTaskAction -Execute $py -Argument $args -WorkingDirectory "C:\경로\mirae asset securities auto"
$pr  = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$tr  = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$st  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName "KairosServer" -Action $act -Principal $pr -Trigger $tr -Settings $st -Force
```
- 새벽 재부팅 → 자동로그인 → KairosServer 자동 실행 → 항상 접속 가능.
- Funnel 도 부팅 시 유지되게: `tailscale funnel --bg 8443` (백그라운드) 또는 Tailscale 서비스 설정.

---

# 2단계: 실제 주문 (LIVE) — 충분히 검증한 뒤에만

주문 실행은 **`server/pico_kairos_driver.py`** 가 피코로 [0611] 주문창을 구동한다.
웹/앱의 주문폼(매수매도·종목·수량·단가) → `/order` → 서버가 폼을 채우고(→검증→주문버튼).
**기본 DRY-RUN**: 폼만 채우고 주문버튼을 누르지 않는다.

### A. 주문창 좌표 재보정 (전용 노트북 해상도 기준)
`kairos_coords.json` 의 좌표(tab_buy/tab_sell/field_symbol/field_qty/field_price/btn_buy/btn_sell)를
이 노트북 화면에 맞게 재보정:
```
python tools/kairos_macro.py     # '한 칸 테스트' 버튼으로 각 칸에 커서가 정확히 가는지 확인 → kairos_coords.json 수정
```

### B. 거래비밀번호 = '카이로스에 저장'(드라이버는 절대 자동입력 안 함)
- 카이로스 [0611] 주문창에서 **거래비밀번호 저장**을 켜 둔다(주문 시 비번 프롬프트가 안 뜨게).
- 드라이버는 주문 후 '거래비밀번호' 프롬프트가 뜨면 **자동입력하지 않고 즉시 중단+감사로그**.

### C. DRY-RUN 으로 폼 채우기 검증 (안전)
- `config.toml [trading] live_enabled = false` (기본).
- 웹/앱 주문폼에 값 넣고 '주문 전송' → 서버가 **폼만 채움**(버튼 안 누름) → **스트림으로 종목·수량·단가가 맞게 들어갔는지 눈으로 확인**.
- 값이 정확히 들어갈 때까지 좌표·스텝지연(`order_step_gap_sec`) 조정.

### D. 읽기검증(OCR) 설정 — LIVE 주문버튼의 안전조건
LIVE 에서 주문버튼을 누르려면 **화면의 종목·수량·단가가 요청과 일치**해야 한다(불일치/불가면 안 누름):
1. `kairos_coords.json` 에 각 칸의 화면영역 추가: `"verify_symbol": [left,top,w,h]`, `"verify_qty": [...]`, `"verify_price": [...]` (그 칸 텍스트가 보이는 사각형; `python cowork/capture.py --region ...` 로 확인).
2. Tesseract 설치: `pip install pytesseract mss pillow` + Tesseract-OCR 바이너리 설치.
3. (선택) 주문 확인팝업의 '확인' 버튼 좌표를 `"btn_confirm": [x,y]` 로 넣으면 Enter 대신 그걸 클릭.

### E. LIVE 켜기 (소액부터)
- C·D 를 충분히 검증한 뒤 `live_enabled = true`.
- **반드시 1주 등 소액으로 먼저** 실제 주문 → 체결/주문내역 확인 → 점진적으로.
- 언제든 웹의 **긴급정지/킬스위치**로 중단(자동 주문경로 차단 + 미체결 취소 시도).

## 🔒 안전 (항상)
- 인터넷 공개(Funnel) 시 **강한 access_token(+선택 OTP)** 필수. 가능하면 tailnet 내부(`tailscale serve`)만.
- 한도: `max_order_qty`·`max_notional_krw`·`price_band_pct`(app.py 가 주문 전 검사). **현금계좌만**(미수/신용/공매도 차단, account.py).
- 감사로그: 모든 주문/인증/킬스위치가 `logs/audit.log` 에 append.
- **완전 자동매매 루프 없음** — 매 주문 사람이 UI 에서 값 확인 후 전송. 거래비밀번호/공동인증서 자동입력 안 함.
- 원격 '수동조작'(control.py, pyautogui)은 **카이로스엔 안 통함**(보안 차단) — 구조화 주문폼(피코) 경로를 쓸 것.
