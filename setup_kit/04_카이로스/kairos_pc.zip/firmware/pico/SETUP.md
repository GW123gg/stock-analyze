# 라즈베리파이 피코 HID 키보드 — 세팅 가이드

목표: 피코를 **실물 USB 키보드**로 만들어, 우리 서버가 시리얼로 "타이핑해" 하면 피코가 카이로스에
숫자(종목/수량/단가)를 입력하게 한다. 실물 키보드라 **안랩 키보드보안을 통과**한다.

> ⚠️ 피코로는 **숫자(종목/수량/단가)만** 입력. **거래비밀번호·공동인증서 비번은 절대 자동입력 금지.**

---

## 0. 준비물
- [ ] 라즈베리파이 **피코 W** 또는 **피코 2 W** (보드에 인쇄된 이름 확인)
- [ ] **데이터용** USB 케이블  ← ★ 흔한 함정: "충전 전용" 케이블이면 PC가 인식 못 함
- [ ] 이 PC (Windows)

**내 보드가 뭔지 확인**: 보드 위 인쇄 글자를 보세요.
- `Pico W` → CircuitPython "Raspberry Pi Pico W" 용 UF2
- `Pico 2 W` → "Raspberry Pi Pico 2 W" 용 UF2
- (그냥 `Pico`도 USB 키보드는 되지만, WiFi/BT는 없음 — 우리는 USB만 쓰니 상관없음)

---

## 1. CircuitPython 설치 (1회, Thonny 아님)
1. 피코의 **BOOTSEL 버튼을 누른 채** USB를 PC에 연결 → 버튼에서 손 떼기
2. 탐색기에 **`RPI-RP2`** 라는 USB 드라이브가 뜸
   - 안 뜨면 → **케이블이 충전 전용**이거나 BOOTSEL을 안 누른 것. 다른 케이블로 재시도.
3. [circuitpython.org/downloads](https://circuitpython.org/downloads) 에서 **내 보드에 정확히 맞는** `.uf2` 다운로드
4. 그 `.uf2` 파일을 `RPI-RP2` 드라이브에 **복사(드래그)**
5. 자동 재부팅 → 드라이브 이름이 **`CIRCUITPY`** 로 바뀌면 성공 ✅
   - 계속 `RPI-RP2`면 → UF2가 안 맞은 것(보드 종류 다시 확인)

---

## 2. adafruit_hid 라이브러리 넣기
1. [circuitpython.org/libraries](https://circuitpython.org/libraries) 에서 **CircuitPython 버전과 같은 대version의 Bundle** 다운로드
   - 예: CircuitPython 9.x 설치했으면 → Bundle 9.x
2. 압축을 풀고 그 안 `lib/` 폴더에서 **`adafruit_hid` 폴더**를 찾음
3. 그 **`adafruit_hid` 폴더 전체**를 `CIRCUITPY/lib/` 안에 복사
   - 결과: `CIRCUITPY/lib/adafruit_hid/` 가 있어야 함 (안에 keyboard.mpy 등)
   - ★ 이게 없으면 code.py가 import 에러로 **아무 동작 안 함**

---

## 3. 펌웨어(code.py) 넣기
1. 이 저장소의 [firmware/pico/code.py](code.py) 를
2. `CIRCUITPY` 드라이브 **최상위**에 **`code.py`** 로 복사(덮어쓰기)
3. CircuitPython은 저장 즉시 자동 실행 → 이제 피코는 "키보드 + 명령수신기"

---

## 4. (선택) Thonny로 상태 확인
디버깅용으로만. 없어도 됩니다.
1. Thonny 설치 후 열기
2. 우측 하단(또는 Run → Configure interpreter) → **"CircuitPython (generic)"** + 피코 COM 포트 선택
3. **Shell** 창에 에러/출력이 뜸 → code.py에 문제가 있으면 여기서 보임
4. ★★ **테스트 전에는 Thonny 연결을 반드시 끊으세요(Stop/Disconnect).**
   Thonny가 COM 포트를 붙잡고 있으면 `test_pico.py`가 포트를 못 엽니다. (가장 흔한 실패 원인)

---

## 5. PC 쪽 테스트
```powershell
pip install pyserial
python tools/test_pico.py
```
1. 실행하면 5초 카운트다운 → 그 안에 **메모장**을 클릭해 커서를 두세요
2. 피코가 `005930`을 타이핑 → **메모장에 005930이 찍히면 성공** 🎉
   - 카이로스 종목칸에서도 동일하게 통합니다(안랩 통과)
3. 포트 자동탐색 실패 시: 장치관리자 → **포트(COM & LPT)** 에서 번호 확인 후,
   `test_pico.py` 안의 `PicoHID(port)` 를 `PicoHID("COM5")` 처럼 직접 지정

---

## 6. 문제 해결 (Troubleshooting)

| 증상 | 원인 / 해결 |
|---|---|
| `RPI-RP2` 드라이브가 안 뜸 | **충전 전용 케이블** → 데이터 케이블로. BOOTSEL 누른 채 연결했는지 확인 |
| UF2 넣어도 `CIRCUITPY`로 안 바뀜 | 보드에 안 맞는 UF2 → Pico W / Pico 2 W 구분해 재다운로드 |
| 메모장에 아무것도 안 찍힘 | ① `lib/adafruit_hid` 없음 → 복사 ② Thonny가 포트 점유 → Thonny 끊기 ③ Thonny Shell에서 code.py 에러 확인 |
| `test_pico.py`가 포트를 못 엶 | **Thonny/다른 프로그램이 COM 포트 사용 중** → 닫고 재시도 |
| 포트를 못 찾음(자동탐색) | 장치관리자에서 COM 번호 확인 → `PicoHID("COMx")` 직접 지정 |
| 장치관리자 "키보드"에 HID가 안 뜸 | CircuitPython 미설치 or boot.py가 usb_hid 비활성 → 1단계부터 다시 |
| 숫자가 이상하게 찍힘 | 거의 없음(숫자는 레이아웃 무관). 한/영 상태와 무관하게 숫자는 정상 |

**에러를 볼 곳**: Thonny의 **Shell** 창, 또는 `CIRCUITPY/boot_out.txt`. CircuitPython은 code.py가
죽으면 에러 메시지를 여기에 남깁니다.

---

## 7. 되고 나면
`test_pico.py`가 메모장에 잘 찍히면 → **마우스(pyautogui) + 피코(타이핑) 조합의 KairosDriver**를
만들 준비 완료. 알려주시면 바로 구현 + 좌표 캘리브레이션으로 넘어갑니다.
