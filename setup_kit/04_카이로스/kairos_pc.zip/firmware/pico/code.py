# Pico(W) USB HID 키보드 + 마우스 클릭 브리지 (CircuitPython)
# USB 시리얼로 받은 명령을 '실물 USB 키보드/마우스' 입력으로 전송한다.
# 카이로스 키보드보안(안랩/nProtect) 환경에서도 '진짜 입력'이라 통과한다.
#
# 커서 이동은 PC의 pyautogui가 하고(이동은 통과됨), 피코는 그 자리에서 '클릭'만 한다.
# → 복잡한 절대좌표 HID(boot.py) 불필요. CircuitPython 기본 HID에 마우스가 이미 포함됨.
#
# ⚠️ 거래비밀번호/공동인증서 비번은 절대 이 보드로 자동 입력하지 말 것.
#
# 명령(한 줄씩, \n 종료):
#   T:005930   → '005930' 타이핑
#   ENTER / TAB / ESC
#   CLEAR      → Ctrl+A 후 Backspace (필드 비우기)
#   SELALL     → Ctrl+A (전체선택; 붙여넣기 전 기존값 덮어쓰기용)
#   PASTE      → Ctrl+V (붙여넣기; 보안 비번칸에 클립보드 값 넣기)
#   CLICK      → 좌클릭(현재 커서 위치)
#   RCLICK     → 우클릭
#   DCLICK     → 더블클릭

import sys
import time

import supervisor
import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.mouse import Mouse

kbd = Keyboard(usb_hid.devices)
layout = KeyboardLayoutUS(kbd)
mouse = Mouse(usb_hid.devices)     # 기본 HID에 마우스 포함 → boot.py 불필요


def handle(line):
    line = line.strip()
    if not line:
        return
    if line.startswith("T:"):
        layout.write(line[2:])              # 텍스트(숫자) 타이핑
    elif line == "ENTER":
        kbd.send(Keycode.ENTER)
    elif line == "TAB":
        kbd.send(Keycode.TAB)
    elif line == "ESC":
        kbd.send(Keycode.ESCAPE)
    elif line == "CLEAR":
        kbd.send(Keycode.CONTROL, Keycode.A)
        time.sleep(0.02)
        kbd.send(Keycode.BACKSPACE)
    elif line == "SELALL":
        kbd.send(Keycode.CONTROL, Keycode.A)
    elif line == "PASTE":
        kbd.send(Keycode.CONTROL, Keycode.V)
    elif line.startswith("M:"):
        # 상대 이동(nudge). 예: "M:3,0" → 오른쪽 3px.
        try:
            dx, dy = line[2:].split(",")
            mouse.move(int(dx), int(dy))
        except Exception:
            pass
    elif line.startswith("A:"):
        # 절대 이동: 좌상단(0,0)으로 홈 후 (x,y)만큼 상대이동 → 마우스가속 OFF면 정확히 화면 (x,y)
        try:
            xs, ys = line[2:].split(",")
            mouse.move(-3000, -3000)   # 좌상단으로 클램프
            time.sleep(0.02)
            mouse.move(-3000, -3000)   # 안전 마진
            time.sleep(0.02)
            mouse.move(int(xs), int(ys))
        except Exception:
            pass
    elif line == "CLICK":
        mouse.click(Mouse.LEFT_BUTTON)      # 현재 커서 위치에서 좌클릭
    elif line == "RCLICK":
        mouse.click(Mouse.RIGHT_BUTTON)
    elif line == "DCLICK":
        mouse.click(Mouse.LEFT_BUTTON)
        time.sleep(0.05)
        mouse.click(Mouse.LEFT_BUTTON)


buf = ""
while True:
    if supervisor.runtime.serial_bytes_available:
        ch = sys.stdin.read(1)
        if ch in ("\n", "\r"):
            handle(buf)
            buf = ""
        else:
            buf += ch
    else:
        time.sleep(0.005)
