import Foundation

// MARK: - 응답 모델 (server/app.py 와 대응)

struct StatusResp: Decodable {
    let mode: String              // "DRYRUN" | "LIVE"
    let capture_mode: String
    let killswitch: Bool
    let emergency_stop: Bool
    let manual_mode: Bool?
    let manual_allowed: Bool?
}

struct SafetyResp: Decodable {
    let killswitch: Bool?
    let emergency_stop: Bool?
    let manual_mode: Bool?
}

struct LimitsResp: Decodable {
    let symbol: String
    let price: Int
    let buyable: Int
    let sellable: Int
    let cash: Int
}

struct OrderResp: Decodable {
    let ok: Bool
    let order_id: String?
    let message: String?
    let mode: String?
}

// MARK: - 오류

enum APIError: LocalizedError {
    case badURL
    case badResponse
    case http(Int, String)

    var errorDescription: String? {
        switch self {
        case .badURL:
            return "서버 URL이 올바르지 않습니다. [설정]에서 다시 등록하세요."
        case .badResponse:
            return "서버 응답 형식 오류"
        case .http(let code, let msg):
            switch code {
            case 401: return "인증 실패 — 보안키(access_token)를 확인하세요."
            case 423: return "차단됨 — 긴급정지/킬스위치 상태입니다."
            case 422: return "안전장치 거부: \(msg)"
            case 503: return "화면 준비 중 — 잠시 후 다시 시도하세요."
            default:  return "오류 \(code): \(msg)"
            }
        }
    }
}

// MARK: - 클라이언트 (Bearer 토큰 인증)

struct API {
    let base: URL          // 예: https://host.ts.net  (끝에 / 없음)
    let token: String

    private func makeRequest(_ path: String, method: String = "GET",
                             json: [String: Any]? = nil) throws -> URLRequest {
        // 상대 URL 대신 절대 문자열로 조립(가장 예측 가능)
        guard let url = URL(string: base.absoluteString + path) else { throw APIError.badURL }
        var r = URLRequest(url: url)
        r.httpMethod = method
        r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        r.timeoutInterval = 15
        r.cachePolicy = .reloadIgnoringLocalCacheData
        if let json = json {
            r.setValue("application/json", forHTTPHeaderField: "Content-Type")
            r.httpBody = try JSONSerialization.data(withJSONObject: json)
        }
        return r
    }

    private static func check(_ resp: URLResponse, _ data: Data) throws {
        guard let http = resp as? HTTPURLResponse else { throw APIError.badResponse }
        guard (200..<300).contains(http.statusCode) else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw APIError.http(http.statusCode, body)
        }
    }

    func get<T: Decodable>(_ path: String) async throws -> T {
        let (data, resp) = try await URLSession.shared.data(for: try makeRequest(path))
        try Self.check(resp, data)
        return try JSONDecoder().decode(T.self, from: data)
    }

    @discardableResult
    func post<T: Decodable>(_ path: String, _ body: [String: Any]) async throws -> T {
        let req = try makeRequest(path, method: "POST", json: body)
        let (data, resp) = try await URLSession.shared.data(for: req)
        try Self.check(resp, data)
        return try JSONDecoder().decode(T.self, from: data)
    }

    /// 호가창 스냅샷(JPEG). MJPEG 스트림 대신 폴링 — iOS 에서 단순하고 안정적.
    func snapshot() async throws -> Data {
        let (data, resp) = try await URLSession.shared.data(for: try makeRequest("/snapshot.jpg"))
        try Self.check(resp, data)
        return data
    }
}
