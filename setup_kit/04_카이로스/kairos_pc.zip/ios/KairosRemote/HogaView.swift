import SwiftUI

/// 호가창 실시간 보기(스냅샷 폴링) + 상태 + 긴급정지.
struct HogaView: View {
    @EnvironmentObject var store: ServerStore

    @State private var image: UIImage?
    @State private var status: StatusResp?
    @State private var errText: String?
    @State private var pollTask: Task<Void, Never>?
    @State private var confirmStop = false
    @State private var big = false

    var body: some View {
        VStack(spacing: 10) {
            statusBar

            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: big ? .infinity : 320)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .onTapGesture { big.toggle() }
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "chart.bar.doc.horizontal")
                        .font(.largeTitle)
                        .foregroundStyle(.secondary)
                    Text(errText ?? "화면을 받아오는 중…")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                    if !store.isConfigured {
                        Text("[설정] 탭에서 서버 URL과 보안키를 등록하세요.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(maxWidth: .infinity, minHeight: 220)
            }

            Spacer(minLength: 0)

            Button(role: .destructive) {
                confirmStop = true
            } label: {
                Label("긴급정지", systemImage: "exclamationmark.octagon.fill")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)
            .tint(.red)
            .confirmationDialog("긴급정지 하시겠습니까?", isPresented: $confirmStop,
                                titleVisibility: .visible) {
                Button("긴급정지 실행", role: .destructive) {
                    Task { await emergencyStop() }
                }
                Button("취소", role: .cancel) { }
            } message: {
                Text("자동 주문 경로가 차단되고 미체결 취소를 시도합니다.")
            }
        }
        .padding()
        .navigationTitle("호가")
        .onAppear { startPolling() }
        .onDisappear {
            pollTask?.cancel()
            pollTask = nil
        }
    }

    private var statusBar: some View {
        HStack(spacing: 8) {
            if let s = status {
                Text(s.mode)
                    .font(.caption).bold()
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(s.mode == "LIVE" ? Color.red.opacity(0.2) : Color.green.opacity(0.2))
                    .clipShape(Capsule())
                if s.killswitch {
                    Text("KILL").font(.caption).bold().foregroundStyle(.red)
                }
                if s.emergency_stop {
                    Text("긴급정지").font(.caption).bold().foregroundStyle(.red)
                }
            } else {
                Text("연결 대기").font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
    }

    // @MainActor: 여기서 만든 Task 가 메인액터를 물려받아 @State 변경이 항상 메인에서 일어난다.
    @MainActor
    private func startPolling() {
        pollTask?.cancel()
        pollTask = Task {
            while !Task.isCancelled {
                guard let api = store.api else {
                    errText = "서버 URL/보안키가 등록되지 않았습니다."
                    try? await Task.sleep(nanoseconds: 1_500_000_000)
                    continue
                }
                do {
                    let data = try await api.snapshot()
                    if let ui = UIImage(data: data) { image = ui }
                    let s: StatusResp = try await api.get("/status")
                    status = s
                    errText = nil
                } catch {
                    errText = error.localizedDescription
                }
                try? await Task.sleep(nanoseconds: 500_000_000)   // 약 2fps
            }
        }
    }

    @MainActor
    private func emergencyStop() async {
        guard let api = store.api else { return }
        do {
            let _: SafetyResp = try await api.post("/emergency_stop", [:])
        } catch {
            errText = error.localizedDescription
        }
    }
}
