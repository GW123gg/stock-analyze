import SwiftUI

@main
struct KairosRemoteApp: App {
    @StateObject private var store = ServerStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: ServerStore

    var body: some View {
        TabView {
            NavigationStack { HogaView() }
                .tabItem { Label("호가", systemImage: "chart.bar.xaxis") }

            NavigationStack { OrderView() }
                .tabItem { Label("주문", systemImage: "cart") }

            NavigationStack { SettingsView() }
                .tabItem { Label("설정", systemImage: "gear") }
                .badge(store.isConfigured ? 0 : 1)   // 미등록이면 설정 탭에 빨간 점
        }
    }
}
