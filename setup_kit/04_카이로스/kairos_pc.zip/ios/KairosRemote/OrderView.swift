import SwiftUI

/// 구조화 주문폼 → 확인 다이얼로그 → 서버(/order) → 서버가 피코로 [0611] 주문창 구동.
/// 서버가 DRY-RUN 이면 폼만 채우고 주문버튼은 누르지 않는다.
struct OrderView: View {
    @EnvironmentObject var store: ServerStore

    @State private var side = "buy"
    @State private var symbol = ""
    @State private var qtyText = ""
    @State private var priceText = ""
    @State private var limits: LimitsResp?
    @State private var confirming = false
    @State private var sending = false
    @State private var resultText: String?
    @State private var resultOK = false

    private var qty: Int { Int(qtyText) ?? 0 }
    private var price: Int { Int(priceText) ?? 0 }

    /// 총액. `qty * price` 는 오버플로 시 트랩(앱 크래시)이므로 non-trapping 곱셈을 쓴다.
    /// 넘치면 nil → 주문 버튼도 비활성.
    private var total: Int? {
        let (t, overflow) = qty.multipliedReportingOverflow(by: price)
        return overflow ? nil : t
    }

    private var isValid: Bool {
        symbol.count == 6 && Int(symbol) != nil && qty > 0 && price > 0 && total != nil
    }
    private var sideLabel: String { side == "buy" ? "매수" : "매도" }
    private var confirmText: String {
        let totalStr = total.map { "\($0)원" } ?? "계산 불가(값이 너무 큼)"
        return "\(sideLabel) · \(symbol) · \(qty)주 · \(price)원  (총 \(totalStr))"
    }

    var body: some View {
        Form {
            Section("주문") {
                Picker("구분", selection: $side) {
                    Text("매수").tag("buy")
                    Text("매도").tag("sell")
                }
                .pickerStyle(.segmented)

                // 숫자만 + 자릿수 제한(오버플로/오입력 방지). 붙여넣기로도 못 넘게 onChange 에서 자른다.
                TextField("종목코드 6자리 (예: 005930)", text: $symbol)
                    .keyboardType(.numberPad)
                    .onChange(of: symbol) { v in
                        let f = String(v.filter { $0.isNumber }.prefix(6))
                        if f != v { symbol = f }
                    }
                TextField("수량(주)", text: $qtyText)
                    .keyboardType(.numberPad)
                    .onChange(of: qtyText) { v in
                        let f = String(v.filter { $0.isNumber }.prefix(9))
                        if f != v { qtyText = f }
                    }
                TextField("단가(원)", text: $priceText)
                    .keyboardType(.numberPad)
                    .onChange(of: priceText) { v in
                        let f = String(v.filter { $0.isNumber }.prefix(9))
                        if f != v { priceText = f }
                    }

                Button("가능수량 조회") {
                    Task { await loadLimits() }
                }
                .disabled(symbol.count != 6 || !store.isConfigured)

                if let l = limits {
                    Text("매수가능 \(l.buyable)주 · 매도가능 \(l.sellable)주 · 예수금 \(l.cash)원")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Section {
                Button {
                    confirming = true
                } label: {
                    HStack {
                        Text("\(sideLabel) 주문 전송").bold()
                        if sending {
                            Spacer()
                            ProgressView()
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 4)
                }
                .buttonStyle(.borderedProminent)
                .tint(side == "buy" ? .red : .blue)
                .disabled(!isValid || sending || !store.isConfigured)
            } footer: {
                Text("서버가 DRY-RUN 이면 폼만 채우고 주문버튼은 누르지 않습니다. "
                     + "전송 후 [호가] 탭에서 값이 맞게 들어갔는지 반드시 확인하세요.")
            }

            if let resultText = resultText {
                Section("결과") {
                    Label(resultText,
                          systemImage: resultOK ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                        .foregroundStyle(resultOK ? .green : .orange)
                        .font(.callout)
                }
            }
        }
        .navigationTitle("주문")
        .confirmationDialog("이 주문을 전송할까요?", isPresented: $confirming,
                            titleVisibility: .visible) {
            Button("\(sideLabel) 전송", role: .destructive) {
                Task { await send() }
            }
            Button("취소", role: .cancel) { }
        } message: {
            Text(confirmText)
        }
    }

    @MainActor
    private func loadLimits() async {
        guard let api = store.api else { return }
        limits = try? await api.get("/account/limits?symbol=\(symbol)&price=\(price)")
    }

    @MainActor
    private func send() async {
        guard let api = store.api else { return }
        sending = true
        defer { sending = false }
        do {
            let r: OrderResp = try await api.post("/order", [
                "symbol": symbol,
                "side": side,
                "qty": qty,
                "price": price,
            ])
            resultOK = r.ok
            resultText = "[\(r.mode ?? "?")] \(r.message ?? "")"
        } catch {
            resultOK = false
            resultText = error.localizedDescription
        }
    }
}
