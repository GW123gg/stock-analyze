import Foundation
import Security

// MARK: - Keychain (보안키는 UserDefaults 금지, Keychain 에만)

enum Keychain {
    static func save(_ key: String, _ value: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
        ]
        SecItemDelete(query as CFDictionary)
        guard !value.isEmpty else { return }
        var add = query
        add[kSecValueData as String] = Data(value.utf8)
        add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(add as CFDictionary, nil)
    }

    static func load(_ key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var out: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

// MARK: - 서버 설정 (URL 등록 + 보안키)

/// URL 은 UserDefaults, 보안키는 Keychain 에 저장.
/// (@MainActor 를 붙이지 않는다 — @StateObject 초기화 시 actor 격리 오류를 피하기 위해.
///  @Published 변경은 항상 메인액터인 View 의 Task 안에서만 일어난다.)
final class ServerStore: ObservableObject {
    @Published var urlString: String {
        didSet { UserDefaults.standard.set(urlString, forKey: "serverURL") }
    }
    @Published var token: String {
        didSet { Keychain.save("kairosToken", token) }
    }

    init() {
        urlString = UserDefaults.standard.string(forKey: "serverURL") ?? ""
        token = Keychain.load("kairosToken") ?? ""
    }

    /// 끝의 "/" 를 떼고 http(s) URL 로. 예: https://내기기.tailnet.ts.net
    var baseURL: URL? {
        var s = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty else { return nil }
        while s.hasSuffix("/") { s.removeLast() }
        guard let u = URL(string: s),
              let scheme = u.scheme?.lowercased(),
              scheme == "http" || scheme == "https",
              u.host != nil else { return nil }
        return u
    }

    var isConfigured: Bool { baseURL != nil && !token.isEmpty }

    var api: API? {
        guard let base = baseURL, !token.isEmpty else { return nil }
        return API(base: base, token: token)
    }
}
