import SwiftUI

/// 서버 URL 등록 + 보안키 저장 + 연결 테스트.
struct SettingsView: View {
    @EnvironmentObject var store: ServerStore

    @State private var urlDraft = ""
    @State private var tokenDraft = ""
    @State private var testing = false
    @State private var resultText: String?
    @State private var resultOK = false
    @State private var didSeed = false      // 탭 전환마다 onAppear 가 다시 불려 입력이 지워지는 것 방지

    var body: some View {
        Form {
            Section {
                TextField("https://내기기.tailnet.ts.net", text: $urlDraft)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
            } header: {
                Text("서버 URL 등록")
            } footer: {
                Text("전용 노트북에서 `tailscale funnel 8443` 실행 시 나오는 주소. "
                     + "같은 tailnet 안이면 http://<기기>:8443 도 가능(그때는 Info.plist 에 ATS 예외 필요).")
            }

            Section {
                SecureField("서버 config.toml 의 access_token", text: $tokenDraft)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            } header: {
                Text("보안키 (access_token)")
            } footer: {
                Text("이 기기의 Keychain 에만 저장됩니다.")
            }

            Section {
                Button {
                    store.urlString = urlDraft.trimmingCharacters(in: .whitespacesAndNewlines)
                    store.token = tokenDraft
                    Task { await testConnection() }
                } label: {
                    HStack {
                        Text("저장하고 연결 테스트")
                        if testing {
                            Spacer()
                            ProgressView()
                        }
                    }
                }
                .disabled(urlDraft.isEmpty || tokenDraft.isEmpty || testing)

                if let resultText = resultText {
                    Label(resultText,
                          systemImage: resultOK ? "checkmark.circle.fill" : "xmark.octagon.fill")
                        .foregroundStyle(resultOK ? .green : .red)
                        .font(.callout)
                }
            }

            Section("안전") {
                Text("• 서버가 DRY-RUN 이면 주문버튼을 누르지 않고 폼만 채웁니다.\n"
                     + "• 주문 전 반드시 [호가] 탭에서 값이 맞게 들어갔는지 확인하세요.\n"
                     + "• 이상하면 [호가] 탭의 긴급정지를 누르세요.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("설정")
        .onAppear {
            // TabView 자식은 탭을 옮길 때마다 onAppear 가 재실행된다.
            // 무조건 다시 채우면 '저장 안 한 입력'이 조용히 사라지므로 최초 1회만 채운다.
            guard !didSeed else { return }
            didSeed = true
            urlDraft = store.urlString
            tokenDraft = store.token
        }
    }

    @MainActor
    private func testConnection() async {
        testing = true
        defer { testing = false }
        guard let api = store.api else {
            resultOK = false
            resultText = "URL 또는 보안키가 비어있거나 형식이 잘못됐습니다."
            return
        }
        do {
            let s: StatusResp = try await api.get("/status")
            resultOK = true
            resultText = "연결 성공 — 모드 \(s.mode), 캡쳐 \(s.capture_mode)"
        } catch {
            resultOK = false
            resultText = error.localizedDescription
        }
    }
}
