# KairosRemote — Xcode 세팅 가이드 (아이폰 앱)

전용 노트북의 서버에 접속해 **호가창을 보고 주문**하는 iOS 앱(SwiftUI).
**서버 URL 등록** 화면 포함 — Tailscale Funnel 주소를 앱에서 직접 넣습니다.

## 준비물
- **Mac** + **Xcode 15 이상** (App Store 에서 무료)
- **아이폰** + USB 케이블(또는 같은 Wi-Fi 로 무선 설치)
- **Apple ID** (무료 계정 가능 — 단 7일마다 재설치. 유료 개발자 계정이면 1년)
- 이 폴더(`xcode_app`)를 **Mac 으로 복사** (USB/에어드롭/클라우드)

---

## 1단계 — 프로젝트 만들기
1. Xcode 실행 → **File ▸ New ▸ Project…**
2. 상단 **iOS** 탭 → **App** 선택 → **Next**
3. 아래처럼 입력:
   | 항목 | 값 |
   |---|---|
   | Product Name | **KairosRemote** |
   | Team | 본인 Apple ID (없으면 *Add an Account…* 로 로그인) |
   | Organization Identifier | `com.본인아이디` (예: `com.namgunwoo`) |
   | Interface | **SwiftUI** |
   | Language | **Swift** |
   | Storage | None (체크 해제) |
   | Include Tests | 해제 |
4. **Next** → 저장 위치 선택 → **Create**

## 2단계 — 자동 생성된 파일 지우기 ★중요
왼쪽 파일목록(Project Navigator)에서:
- **`KairosRemoteApp.swift`** → 우클릭 ▸ **Delete** ▸ **Move to Trash**
  - ⚠️ 이걸 안 지우면 `@main` 이 두 개가 되어 **컴파일 오류**가 납니다.
- **`ContentView.swift`** → 같은 방식으로 삭제 (안 지워도 되지만 깔끔하게)

## 3단계 — Swift 파일 6개 넣기
1. Finder 에서 이 폴더의 **`KairosRemote/`** 안에 있는 **`.swift` 6개**를 전부 선택:
   ```
   KairosRemoteApp.swift   ServerStore.swift   API.swift
   HogaView.swift          OrderView.swift     SettingsView.swift
   ```
2. Xcode 왼쪽 파일목록의 **KairosRemote 폴더(노란 폴더)** 위로 **드래그**
3. 뜨는 창에서:
   - ✅ **Copy items if needed** 체크
   - ✅ **Add to targets: KairosRemote** 체크
   - **Finish**

## 4단계 — 최소 iOS 버전 확인
1. 왼쪽 맨 위 **파란 프로젝트 아이콘** 클릭
2. **TARGETS ▸ KairosRemote ▸ General**
3. **Minimum Deployments ▸ iOS** 를 **16.0** 이상으로
   (`NavigationStack` 이 iOS 16+ 입니다)

## 5단계 — 서명(Signing)
1. **TARGETS ▸ KairosRemote ▸ Signing & Capabilities**
2. ✅ **Automatically manage signing** 체크
3. **Team** 에 본인 Apple ID 선택
4. 빨간 오류가 뜨면 **Bundle Identifier** 를 유일한 값으로 바꾸기
   (예: `com.namgunwoo.KairosRemote2`)

## 6단계 — (HTTP 로 접속할 때만) ATS 예외
Tailscale **Funnel(https)** 을 쓰면 **이 단계 건너뛰세요.**
`http://100.x.x.x:8443`(tailnet 직접)으로 붙을 거면 iOS 가 평문 HTTP 를 막으므로:
1. **TARGETS ▸ KairosRemote ▸ Info** 탭
2. 아무 줄에서 **＋** → 키 이름에 `App Transport Security Settings` 입력 (Dictionary)
3. 그 아래 **＋** → `Allow Local Networking` → **YES**

## 7단계 — 아이폰에 설치
1. 아이폰을 USB 로 Mac 에 연결 → 아이폰에서 **"이 컴퓨터를 신뢰"** 탭
2. Xcode 상단 가운데 기기 선택 드롭다운에서 **본인 아이폰** 선택
3. **⌘R** (또는 ▶ 버튼) → 빌드 & 설치
4. 첫 실행 시 아이폰에서 "신뢰할 수 없는 개발자" 가 뜨면:
   **설정 ▸ 일반 ▸ VPN 및 기기 관리 ▸ (본인 Apple ID) ▸ 신뢰**
5. 다시 앱 실행

---

## 8단계 — 사용법
1. 앱 실행 → **[설정] 탭** (미등록이면 빨간 점 표시)
   - **서버 URL**: 전용 노트북에서 `tailscale funnel 8443` 실행 시 나온
     `https://<기기>.<tailnet>.ts.net` 를 그대로 입력
   - **보안키**: 서버 `config.toml` 의 `access_token` 값
   - **저장하고 연결 테스트** → **"연결 성공 — 모드 DRYRUN"** 이면 완료
2. **[호가] 탭** — 카이로스 화면 실시간(약 2fps). **탭하면 확대/축소**. 이상하면 **긴급정지**.
3. **[주문] 탭** — 매수/매도 · 종목 · 수량 · 단가 → **주문 전송** → 확인 다이얼로그 → 전송

## 화면 구성
| 파일 | 역할 |
|---|---|
| `KairosRemoteApp.swift` | 앱 진입점 + 탭(호가/주문/설정) |
| `ServerStore.swift` | **URL 등록**(UserDefaults) + 보안키(**Keychain**) |
| `API.swift` | 서버 통신(Bearer 토큰): status/snapshot/limits/order/emergency_stop |
| `HogaView.swift` | 호가창 폴링 + 상태뱃지 + 긴급정지 |
| `OrderView.swift` | 주문폼 + 확인 다이얼로그 |
| `SettingsView.swift` | URL/보안키 등록 + 연결 테스트 |

---

## 🔒 안전
- 서버가 **DRY-RUN** 이면 폼만 채우고 **주문버튼을 누르지 않습니다**. 실제 주문은 서버
  `config.toml [trading] live_enabled = true` + 화면 읽기검증 통과 시에만.
- 주문 전 **확인 다이얼로그**가 종목·수량·단가·총액을 다시 보여줍니다.
- 보안키는 **Keychain** 에만 저장. URL/보안키 미등록이면 주문 버튼 비활성.
- 전송 후 **[호가] 탭에서 값이 맞게 들어갔는지 눈으로 확인**하세요.
- 서버의 안전장치(한도·현금계좌·가격밴드·킬스위치·감사로그)가 항상 먼저 적용됩니다.

## 문제 해결
| 증상 | 해결 |
|---|---|
| `Invalid redeclaration of 'KairosRemoteApp'` | 2단계에서 자동생성 `KairosRemoteApp.swift` 를 안 지움 → 삭제 |
| `Cannot find 'ServerStore' in scope` | 3단계에서 파일이 **target 에 추가** 안 됨 → 파일 선택 후 오른쪽 **Target Membership** 체크 |
| `'NavigationStack' is only available in iOS 16.0+` | 4단계 최소 iOS 를 16.0 으로 |
| 앱은 뜨는데 "연결 실패/인증 실패" | URL 오타(끝 `/` 는 자동 제거됨) 또는 보안키 불일치. 사파리로 같은 URL 접속해 확인 |
| http 주소에서 연결 안 됨 | 6단계 ATS 예외 추가 |
| 7일 뒤 앱이 안 열림 | 무료 Apple ID 제한 — Xcode 로 **⌘R** 재설치 |

## 대안 (Mac 이 없다면)
앱 없이도 됩니다: 아이폰 **사파리**로 `https://….ts.net` 접속 → **공유 ▸ 홈 화면에 추가** →
전체화면 PWA 로 거의 같은 기능(호가창·주문·긴급정지)을 씁니다.
