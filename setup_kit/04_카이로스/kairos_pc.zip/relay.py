"""pc21 → 카이로스 전용 노트북 TCP 중계기.

왜 필요한가:
  Tailscale funnel 은 **localhost 에서 도는 서비스만** 중계한다(원격 테일넷 IP 를 넣으면 502).
  그래서 funnel 이 가리킬 로컬 포트를 이 스크립트가 하나 만들고, 그걸 노트북으로 넘긴다.

    인터넷 ──https──▶ pc21.ts.net (funnel) ──▶ 127.0.0.1:9000 (이 스크립트) ──▶ 노트북:8443
                                              └ localhost 라 funnel 이 받아줌 ┘

  HTTP 를 해석하지 않는 **raw TCP 프록시**라 MJPEG 스트림·쿠키·헤더·Authorization 이 전부 그대로 통과한다.

실행:
  python relay.py                                              # 기본값(아래 상수)
  python relay.py --target 100.64.0.1:8443 --listen 127.0.0.1:9000
  python relay.py --quiet                                      # 연결 로그 끄기

  그다음 다른 창에서:
      tailscale funnel --bg --yes --https=443 9000
  끄기:
      tailscale funnel --https=443 off

주의:
  - 이 스크립트가 떠 있는 동안만 중계된다(끄면 외부 접속도 끊김).
  - funnel 은 **인터넷 공개**다. 서버의 access_token 이 유일한 방어선이니 강해야 한다.
  - 같은 테일넷 기기(이 PC 포함)는 중계 없이 http://<노트북IP>:8443 로 바로 접속하면 된다.
"""
from __future__ import annotations

import argparse
import asyncio
import time

TARGET_HOST, TARGET_PORT = "100.64.0.1", 8443   # 카이로스 전용 노트북 (테일넷 IP)
LISTEN_HOST, LISTEN_PORT = "127.0.0.1", 9000       # funnel 이 가리킬 로컬 포트

QUIET = False


def log(msg: str) -> None:
    if not QUIET:
        print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


async def pipe(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    """한 방향으로 바이트를 그대로 흘린다(내용 해석 없음)."""
    try:
        while True:
            data = await reader.read(65536)
            if not data:
                break
            writer.write(data)
            await writer.drain()
    except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError):
        pass
    except Exception as e:  # noqa: BLE001
        log(f"  파이프 오류: {e}")
    finally:
        # 반쪽 닫기: 이쪽이 끝나도 반대 방향은 남은 응답을 마저 보낼 수 있게 한다.
        try:
            if writer.can_write_eof():
                writer.write_eof()
        except Exception:
            pass


async def handle(local_r, local_w, host: str, port: int, seq: list[int]) -> None:
    seq[0] += 1
    n = seq[0]
    try:
        remote_r, remote_w = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=10
        )
    except Exception as e:  # noqa: BLE001
        log(f"#{n} 대상({host}:{port}) 연결 실패: {e}")
        try:
            local_w.close()
        except Exception:
            pass
        return

    log(f"#{n} 연결됨 → {host}:{port}")
    try:
        await asyncio.gather(pipe(local_r, remote_w), pipe(remote_r, local_w))
    finally:
        for w in (local_w, remote_w):
            try:
                w.close()
            except Exception:
                pass
        log(f"#{n} 종료")


def _split_hostport(s: str, default_host: str, default_port: int):
    if ":" in s:
        h, p = s.rsplit(":", 1)
        return (h or default_host), int(p)
    return default_host, int(s)


async def main() -> None:
    global QUIET
    ap = argparse.ArgumentParser(description="pc21 -> 카이로스 노트북 TCP 중계기")
    ap.add_argument("--target", default=f"{TARGET_HOST}:{TARGET_PORT}",
                    help="중계 대상(노트북). 예: 100.64.0.1:8443")
    ap.add_argument("--listen", default=f"{LISTEN_HOST}:{LISTEN_PORT}",
                    help="이 PC 에서 들을 주소. 예: 127.0.0.1:9000")
    ap.add_argument("--quiet", action="store_true", help="연결 로그 끄기")
    args = ap.parse_args()
    QUIET = args.quiet

    thost, tport = _split_hostport(args.target, TARGET_HOST, TARGET_PORT)
    lhost, lport = _split_hostport(args.listen, LISTEN_HOST, LISTEN_PORT)

    # 시작 전에 대상이 살아있는지 한 번 확인(오타/노트북 꺼짐을 바로 잡아준다)
    try:
        r, w = await asyncio.wait_for(asyncio.open_connection(thost, tport), timeout=5)
        w.close()
        print(f"대상 확인 OK: {thost}:{tport}")
    except Exception as e:  # noqa: BLE001
        print(f"⚠ 대상({thost}:{tport}) 에 지금 연결이 안 됩니다: {e}")
        print("  (노트북 서버가 꺼졌거나 테일넷 IP 가 바뀌었을 수 있음 — 그래도 중계기는 계속 띄웁니다)")

    server = await asyncio.start_server(
        lambda r, w: handle(r, w, thost, tport, seq), lhost, lport
    )
    print(f"중계 시작: {lhost}:{lport}  →  {thost}:{tport}")
    print(f"  다음 단계 : tailscale funnel --bg --yes --https=443 {lport}")
    print("  끄기      : Ctrl+C   /   tailscale funnel --https=443 off")
    async with server:
        await server.serve_forever()


seq = [0]

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n중계 종료")
