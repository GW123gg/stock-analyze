"""계좌 상태(예수금·보유종목) + 매매 절대 안전장치.

절대 규칙(설정으로도 못 풀도록 코드에 고정):
  1) 미수/융자/신용 매수 금지 → 매수는 '주문가능현금(신용 제외)' 한도 내에서만. 초과 시 거부 + 알림.
  2) 공매도/대주 금지, 초과매도 금지 → 매도는 '매도가능수량' 한도 내에서만.
  3) 보유하지 않은 종목 매도 금지.

지금은 수동 입력(positions_file) 소스만 구현한다. 추후 DDE/엑셀/UIA 프로바이더로 교체 가능하도록
AccountState 를 소스와 분리해 둔다. (안전 판단의 '진실 소스'로 OCR/화면인식은 쓰지 않는다.)
"""
from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path


class AccountBlocked(Exception):
    """계좌 안전장치 위반 — 주문을 절대 실행하지 않는다."""

    def __init__(self, message: str, alert: bool = False):
        super().__init__(message)
        self.alert = alert


@dataclass
class Holding:
    symbol: str
    qty: int = 0
    sellable: int = 0     # 매도가능수량(미결제/출고예정 제외분)
    avg_price: int = 0


class AccountState:
    def __init__(self, cfg: dict, root: Path):
        self.source = cfg.get("source", "manual")
        self.buy_fee_rate = float(cfg.get("buy_fee_rate", 0.00015))
        self.cash = 0                          # 주문가능현금(신용/미수 제외)
        self.holdings: dict[str, Holding] = {}
        self.updated = ""
        self._file = root / cfg.get("positions_file", "positions.json")
        self._lock = threading.Lock()
        self._load()

    # ---------- 소스: 수동(positions.json) ----------
    def _load(self) -> None:
        if self._file.exists():
            try:
                data = json.loads(self._file.read_text(encoding="utf-8"))
                self.set_manual(data.get("cash", 0), data.get("holdings", []), save=False)
            except Exception:
                pass

    def _save(self) -> None:
        try:
            self._file.write_text(
                json.dumps(self.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception:
            pass

    def set_manual(self, cash, holdings_list, save: bool = True) -> None:
        with self._lock:
            self.cash = max(0, int(cash))
            self.holdings = {}
            for h in holdings_list or []:
                sym = str(h["symbol"]).strip()
                if not sym:
                    continue
                qty = int(h.get("qty", 0))
                self.holdings[sym] = Holding(
                    symbol=sym,
                    qty=qty,
                    sellable=int(h.get("sellable", qty)),
                    avg_price=int(h.get("avg_price", 0)),
                )
            self.updated = time.strftime("%Y-%m-%dT%H:%M:%S")
        if save:
            self._save()

    # ---------- 계산 ----------
    def buyable_qty(self, price: int) -> int:
        if price <= 0:
            return 0
        unit = price * (1 + self.buy_fee_rate)
        with self._lock:
            return int(self.cash // unit)

    def sellable_qty(self, symbol: str) -> int:
        with self._lock:
            h = self.holdings.get(str(symbol).strip())
            return h.sellable if h else 0

    def to_dict(self) -> dict:
        with self._lock:
            return {
                "cash": self.cash,
                "source": self.source,
                "buy_fee_rate": self.buy_fee_rate,
                "updated": self.updated,
                "holdings": [asdict(h) for h in self.holdings.values()],
            }


def enforce_cash_enabled(cfg: dict) -> bool:
    """[account] enforce_cash 스위치. 1(기본)=예수금·매도가능 감시함, 0=감시 안 함(테스트용).

    0 으로 꺼도 아래는 그대로 살아있다:
      - cash_only 정책(미수/융자 금지)          - 수량/금액/가격밴드 한도(apply_guardrails)
      - 킬스위치/긴급정지                        - DRY-RUN(live_enabled=false)
      - 그리고 최종적으로 '증권사'가 예수금 부족/과매도 주문을 거부한다.
    """
    v = cfg.get("enforce_cash", 1)
    if isinstance(v, bool):
        return v
    try:
        return int(v) != 0
    except (TypeError, ValueError):
        return True          # 값이 이상하면 안전한 쪽(감시함)으로


def check_account(req, account: AccountState, cfg: dict) -> None:
    """주문 직전 계좌 기반 안전장치. 위반 시 AccountBlocked 예외."""
    # 절대 정책: 항상 현금거래. 미수/융자/신용/공매도 금지. (스위치로 못 품)
    if not cfg.get("cash_only", True):
        raise AccountBlocked("cash_only=false 는 허용되지 않습니다(미수/융자 금지 정책).")

    # 예수금·매도가능 감시 스위치가 0 이면 여기서 통과(테스트 모드).
    if not enforce_cash_enabled(cfg):
        return

    if req.side == "buy":
        if req.price <= 0:
            raise AccountBlocked("매수는 지정가가 필요합니다(현금 한도 계산).", alert=True)
        need = req.qty * req.price * (1 + account.buy_fee_rate)
        if need > account.cash:
            raise AccountBlocked(
                f"현금 부족: 필요 약 {int(need):,}원 > 주문가능현금 {account.cash:,}원.\n"
                f"미수/융자는 하지 않습니다. 매수가능 수량은 {account.buyable_qty(req.price)}주 입니다.",
                alert=True,
            )
    elif req.side == "sell":
        sellable = account.sellable_qty(req.symbol)
        if sellable <= 0:
            raise AccountBlocked(
                f"{req.symbol} 매도가능 수량 0 — 미보유 종목/공매도는 금지되어 매도할 수 없습니다.",
                alert=True,
            )
        if req.qty > sellable:
            raise AccountBlocked(
                f"매도가능 수량 초과: 요청 {req.qty}주 > 매도가능 {sellable}주 "
                f"(초과매도·공매도 금지).",
                alert=True,
            )
