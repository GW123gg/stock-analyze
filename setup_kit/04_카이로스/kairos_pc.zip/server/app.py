"""로컬 서버: 호가창/카이로스창 실시간 스트림 · 주문 중계(기본 DRY-RUN, 사람이 확인) ·
긴급정지 · 수동 원격조작 · kill-switch · 인증 · 웹UI 서빙.

실행:  uvicorn server.app:app --host 0.0.0.0 --port 8443
Tailscale 로 노출한 뒤 아이폰/웹에서 접속한다.

방침: 완전 자동매매 루프는 제공하지 않는다 — 모든 주문은 사람이 UI 에서 확인해야 나간다.
"""
import secrets
import time
from pathlib import Path

from fastapi import FastAPI, Form, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse

from server import control
from server.capture import Capturer, Source
from server.config import load
from server.account import (
    AccountBlocked,
    AccountState,
    check_account,
    enforce_cash_enabled,
)
from server.dde_quotes import DDEQuoteClient
from server.otp import OTPManager
from server.driver import (
    DryRunDriver,
    GuardrailError,
    KairosDriver,
    OrderRequest,
    apply_guardrails,
    audit,
)
from server.safety import Aborted, Safety

CFG = load()
WEB_DIR = Path(__file__).resolve().parent.parent / "web"

app = FastAPI(title="Mirae Kairos Bridge")

safety = Safety()
source = Source(CFG["capture"])
capturer = Capturer(
    source.rect,
    fps=CFG["capture"].get("fps", 4),
    jpeg_quality=CFG["capture"].get("jpeg_quality", 70),
)

# 드라이버: 피코로 [0611] 주문창 구동. 내부에서 live_enabled 판단(기본 DRY-RUN=폼만 채움).
# 좌표파일 등 초기화 문제 시 안전하게 DryRun 으로 폴백(서버는 계속 뜸).
try:
    from server.pico_kairos_driver import PicoKairosDriver
    driver = PicoKairosDriver(CFG, safety)
except Exception as exc:  # noqa: BLE001
    print(f"[경고] PicoKairosDriver 초기화 실패 → DRY-RUN 폴백: {exc}")
    driver = DryRunDriver(safety)

dde_client = DDEQuoteClient(CFG.get("dde", {}))
account = AccountState(CFG.get("account", {}), Path(__file__).resolve().parent.parent)
otp_mgr = OTPManager(CFG.get("otp", {}))

SESSIONS: dict[str, float] = {}


@app.on_event("startup")
def _startup() -> None:
    capturer.start()
    dde_client.start()


# ---------- 인증 ----------
def _new_session() -> str:
    sid = secrets.token_urlsafe(32)
    SESSIONS[sid] = time.time() + CFG["auth"].get("session_ttl_seconds", 3600)
    return sid


def _valid_session(sid: str) -> bool:
    exp = SESSIONS.get(sid)
    if not exp:
        return False
    if time.time() > exp:
        SESSIONS.pop(sid, None)
        return False
    return True


def require_auth(request: Request) -> None:
    header = request.headers.get("authorization", "")
    if header.startswith("Bearer ") and secrets.compare_digest(
        header[7:], CFG["auth"]["access_token"]
    ):
        return
    sid = request.cookies.get("sid", "")
    if sid and _valid_session(sid):
        return
    raise HTTPException(401, "인증 필요")


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (WEB_DIR / "index.html").read_text(encoding="utf-8")


@app.post("/otp/request")
def otp_request(request: Request, token: str = Form(...)) -> dict:
    """보안키 확인 후, 이메일로 일회용 인증코드를 발송(Apps Script)."""
    if not secrets.compare_digest(token, CFG["auth"]["access_token"]):
        raise HTTPException(401, "보안키가 올바르지 않습니다.")
    ok, msg = otp_mgr.request_code()
    audit({"kind": "otp_request", "ok": ok, "ip": request.client.host})
    if not ok:
        raise HTTPException(429, msg)
    return {"ok": True, "message": msg}


@app.post("/login")
def login(request: Request, token: str = Form(...), otp: str = Form("")) -> Response:
    if not secrets.compare_digest(token, CFG["auth"]["access_token"]):
        audit({"kind": "login", "ok": False, "reason": "token", "ip": request.client.host})
        raise HTTPException(401, "보안키가 올바르지 않습니다.")
    if not otp_mgr.verify(otp):
        audit({"kind": "login", "ok": False, "reason": "otp", "ip": request.client.host})
        raise HTTPException(401, "인증코드가 올바르지 않거나 만료되었습니다.")
    sid = _new_session()
    audit({"kind": "login", "ok": True, "ip": request.client.host})
    resp = JSONResponse({"ok": True})
    resp.set_cookie(
        "sid", sid,
        httponly=True,
        secure=CFG["auth"].get("cookie_secure", True),
        samesite="strict",
        max_age=CFG["auth"].get("session_ttl_seconds", 3600),
    )
    return resp


# ---------- 스트림 ----------
def _mjpeg():
    fps = max(1, CFG["capture"].get("fps", 4))
    while True:
        frame = capturer.latest_jpeg()
        if frame:
            yield (
                b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                + str(len(frame)).encode() + b"\r\n\r\n" + frame + b"\r\n"
            )
        time.sleep(1.0 / fps)


@app.get("/stream.mjpg")
def stream(request: Request) -> StreamingResponse:
    require_auth(request)
    return StreamingResponse(
        _mjpeg(), media_type="multipart/x-mixed-replace; boundary=frame"
    )


@app.get("/snapshot.jpg")
def snapshot(request: Request) -> Response:
    require_auth(request)
    frame = capturer.latest_jpeg()
    if not frame:
        raise HTTPException(503, "아직 캡쳐 프레임이 없습니다.")
    return Response(frame, media_type="image/jpeg")


@app.post("/capture/mode")
async def capture_mode(request: Request) -> dict:
    require_auth(request)
    data = await request.json()
    try:
        source.set_mode(str(data.get("mode", "")))
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    audit({"kind": "capture_mode", "mode": source.mode})
    return {"mode": source.mode}


@app.post("/capture/live")
async def capture_live(request: Request) -> dict:
    """화면 공유 스위치. off 면 이 PC 의 캡쳐 스레드 자체를 멈춘다
    (= 화면이 더 이상 나가지 않고, 이 PC 의 CPU 도 아낀다)."""
    require_auth(request)
    data = await request.json()
    on = bool(data.get("on", True))
    if on:
        capturer.start()
    else:
        capturer.stop()
    audit({"kind": "capture_live", "on": capturer.live})
    return {"live": capturer.live}


# ---------- 실시간 호가 (DDE) ----------
@app.get("/quotes")
def quotes(request: Request) -> dict:
    require_auth(request)
    return dde_client.snapshot()


@app.post("/quotes/symbol")
async def quotes_symbol(request: Request) -> dict:
    """DDE 트리거(관찰 종목) 변경."""
    require_auth(request)
    data = await request.json()
    sym = str(data.get("symbol", "")).strip()
    if not sym:
        raise HTTPException(400, "symbol(종목코드)이 필요합니다.")
    dde_client.set_symbol(sym)
    audit({"kind": "dde_symbol", "symbol": sym})
    return {"ok": True, "symbol": sym}


# ---------- 계좌 (예수금·보유·매수/매도 가능) ----------
@app.get("/account")
def account_get(request: Request) -> dict:
    require_auth(request)
    return account.to_dict()


@app.post("/account/manual")
async def account_manual(request: Request) -> dict:
    require_auth(request)
    data = await request.json()
    account.set_manual(data.get("cash", 0), data.get("holdings", []))
    audit({"kind": "account_manual", "cash": account.cash, "n": len(account.holdings)})
    return account.to_dict()


@app.get("/account/limits")
def account_limits(request: Request, symbol: str = "", price: int = 0) -> dict:
    require_auth(request)
    return {
        "symbol": symbol,
        "price": price,
        "buyable": account.buyable_qty(price),
        "sellable": account.sellable_qty(symbol),
        "cash": account.cash,
    }


# ---------- 주문 (사람이 UI 에서 확인해야만 호출됨) ----------
@app.post("/order")
async def order(request: Request) -> dict:
    require_auth(request)
    if safety.killswitch:
        raise HTTPException(423, "KILL-SWITCH 작동 중 — 주문이 차단됩니다.")
    if not safety.automation_allowed():
        raise HTTPException(423, "긴급정지/수동모드 — 자동 주문 경로가 차단되었습니다.")
    data = await request.json()
    try:
        req = OrderRequest(
            symbol=str(data["symbol"]).strip(),
            side=str(data["side"]).lower(),
            qty=int(data["qty"]),
            price=int(data.get("price", 0)),
        )
    except Exception as exc:
        raise HTTPException(400, f"주문 형식 오류: {exc}")
    if req.side not in ("buy", "sell"):
        raise HTTPException(400, "side 는 buy 또는 sell")
    try:
        apply_guardrails(req, CFG, last_price=data.get("last_price"))
    except GuardrailError as exc:
        audit({"kind": "order_rejected", "reason": str(exc), "symbol": req.symbol})
        raise HTTPException(422, f"안전장치 거부: {exc}")
    # 계좌 안전장치: 미수/융자/공매도/초과매도 금지.
    # (enforce_cash=0 이면 예수금·매도가능 감시는 건너뜀 — 반드시 로그로 남긴다)
    acct_cfg = CFG.get("account", {})
    if not enforce_cash_enabled(acct_cfg):
        audit({
            "kind": "cash_check_skipped", "symbol": req.symbol, "side": req.side,
            "qty": req.qty, "price": req.price,
            "note": "enforce_cash=0 — 예수금/매도가능 감시 꺼짐(테스트 모드)",
        })
    try:
        check_account(req, account, acct_cfg)
    except AccountBlocked as exc:
        audit({"kind": "order_blocked_account", "reason": str(exc), "symbol": req.symbol})
        raise HTTPException(422, str(exc))
    try:
        result = driver.place_order(req)
    except Aborted as exc:
        raise HTTPException(423, str(exc))
    return {
        "ok": result.ok,
        "order_id": result.order_id,
        "message": result.message,
        "mode": "LIVE" if CFG["trading"].get("live_enabled") else "DRYRUN",
    }


# ---------- 2단계 주문: 준비(종목·수량) → 발사(가격만) ----------
# 준비한 티켓(종목/매수매도/수량)을 서버가 기억하고, [0611] 창에도 미리 채워둔다.
# 이후 가격만 넣고 발사하면 종목·수량을 다시 입력할 필요가 없다.
ARMED: dict = {}


def _order_gate() -> None:
    if safety.killswitch:
        raise HTTPException(423, "KILL-SWITCH 작동 중 — 주문이 차단됩니다.")
    if not safety.automation_allowed():
        raise HTTPException(423, "긴급정지/수동모드 — 자동 주문 경로가 차단되었습니다.")


@app.post("/order/arm")
async def order_arm(request: Request) -> dict:
    """종목·매수매도·수량을 준비하고 [0611] 창에 미리 채운다(가격은 비움, 주문버튼 안 누름)."""
    require_auth(request)
    _order_gate()
    data = await request.json()
    symbol = str(data.get("symbol", "")).strip()
    side = str(data.get("side", "")).lower()
    try:
        qty = int(data.get("qty", 0))
    except Exception:
        raise HTTPException(400, "수량이 숫자가 아닙니다.")
    if side not in ("buy", "sell"):
        raise HTTPException(400, "side 는 buy 또는 sell")
    if not (symbol.isdigit() and len(symbol) == 6):
        raise HTTPException(400, "종목코드는 숫자 6자리여야 합니다.")
    # 수량 한도(가격 무관) 검사
    try:
        apply_guardrails(OrderRequest(symbol=symbol, side=side, qty=qty, price=0), CFG)
    except GuardrailError as exc:
        raise HTTPException(422, f"안전장치 거부: {exc}")
    try:
        result = driver.prefill(symbol, side, qty)
    except Aborted as exc:
        raise HTTPException(423, str(exc))
    except Exception as exc:  # noqa: BLE001  (피코 미연결 등)
        audit({"kind": "arm_failed", "symbol": symbol, "reason": str(exc)})
        raise HTTPException(503, f"준비 실패(피코/드라이버): {exc}")
    ARMED.clear()
    ARMED.update({"symbol": symbol, "side": side, "qty": qty})
    return {"ok": result.ok, "armed": dict(ARMED), "message": result.message}


@app.get("/order/armed")
def order_armed(request: Request) -> dict:
    require_auth(request)
    return {"armed": dict(ARMED) if ARMED else None}


@app.post("/order/disarm")
def order_disarm(request: Request) -> dict:
    require_auth(request)
    ARMED.clear()
    return {"armed": None}


@app.post("/order/fire")
async def order_fire(request: Request) -> dict:
    """준비된 티켓에 '가격만' 넣고 발사. 종목·수량은 준비값을 그대로 쓴다."""
    require_auth(request)
    _order_gate()
    if not ARMED:
        raise HTTPException(409, "준비된 주문이 없습니다. 먼저 종목·수량으로 '준비'하세요.")
    data = await request.json()
    try:
        price = int(data["price"])
    except Exception:
        raise HTTPException(400, "가격(price)이 필요합니다.")
    req = OrderRequest(symbol=ARMED["symbol"], side=ARMED["side"], qty=ARMED["qty"], price=price)
    try:
        apply_guardrails(req, CFG, last_price=data.get("last_price"))
    except GuardrailError as exc:
        audit({"kind": "order_rejected", "reason": str(exc), "symbol": req.symbol})
        raise HTTPException(422, f"안전장치 거부: {exc}")
    acct_cfg = CFG.get("account", {})
    if not enforce_cash_enabled(acct_cfg):
        audit({"kind": "cash_check_skipped", "note": "enforce_cash=0", "symbol": req.symbol,
               "side": req.side, "qty": req.qty, "price": req.price})
    try:
        check_account(req, account, acct_cfg)
    except AccountBlocked as exc:
        audit({"kind": "order_blocked_account", "reason": str(exc), "symbol": req.symbol})
        raise HTTPException(422, str(exc))
    try:
        result = driver.submit_price(req)
    except Aborted as exc:
        raise HTTPException(423, str(exc))
    except Exception as exc:  # noqa: BLE001  (피코 미연결/읽기검증 실패 등)
        audit({"kind": "fire_failed", "symbol": req.symbol, "reason": str(exc)})
        raise HTTPException(503, f"발사 실패: {exc}")
    return {
        "ok": result.ok,
        "order_id": result.order_id,
        "message": result.message,
        "mode": "LIVE" if CFG["trading"].get("live_enabled") else "DRYRUN",
        "armed": dict(ARMED),
    }


# ---------- 긴급정지 / 수동모드 ----------
@app.post("/emergency_stop")
async def emergency_stop(request: Request) -> dict:
    """긴급정지: 자동화 즉시 중단 + 수동 원격조작 활성화 (+미체결 취소 시도)."""
    require_auth(request)
    safety.emergency_stop = True
    safety.manual_mode = True
    try:
        driver.cancel_all()
    except Exception:
        pass
    source.set_mode("window")   # 사람이 카이로스 전체를 보며 조작하도록 전체창으로 전환
    audit({"kind": "emergency_stop", **safety.snapshot()})
    return safety.snapshot()


@app.post("/resume")
async def resume(request: Request) -> dict:
    """긴급정지/수동모드 해제 (주의: 자동화 경로 재개)."""
    require_auth(request)
    safety.emergency_stop = False
    safety.manual_mode = False
    audit({"kind": "resume", **safety.snapshot()})
    return safety.snapshot()


@app.post("/manual")
async def manual(request: Request) -> dict:
    """수동 원격조작 모드 토글(긴급정지 없이)."""
    require_auth(request)
    data = await request.json()
    safety.manual_mode = bool(data.get("on", True))
    audit({"kind": "manual_mode", "on": safety.manual_mode})
    return safety.snapshot()


@app.post("/killswitch")
async def killswitch(request: Request) -> dict:
    require_auth(request)
    data = await request.json()
    safety.killswitch = bool(data.get("engage", True))
    if safety.killswitch:
        try:
            driver.cancel_all()
        except Exception:
            pass
    audit({"kind": "killswitch", "engaged": safety.killswitch})
    return safety.snapshot()


# ---------- 수동 원격조작 입력 전달 ----------
def _require_manual(request: Request) -> None:
    require_auth(request)
    if not control.AVAILABLE:
        raise HTTPException(501, f"pyautogui 미설치/불가: {control.IMPORT_ERROR}")
    if not safety.manual_allowed():
        raise HTTPException(423, "수동 원격조작은 긴급정지/수동모드에서만 허용됩니다.")


def _rect_or_503() -> dict:
    rect = capturer.current_rect()
    if not rect:
        raise HTTPException(503, "현재 캡쳐 영역을 알 수 없습니다(스트림 대기 중).")
    return rect


@app.post("/control/click")
async def control_click(request: Request) -> dict:
    _require_manual(request)
    data = await request.json()
    rect = _rect_or_503()
    res = control.click(
        rect, data.get("x", 0), data.get("y", 0),
        button=str(data.get("button", "left")), double=bool(data.get("double", False)),
    )
    audit({"kind": "manual_click", **res})
    return {"ok": True, **res}


@app.post("/control/move")
async def control_move(request: Request) -> dict:
    _require_manual(request)
    data = await request.json()
    rect = _rect_or_503()
    return {"ok": True, **control.move(rect, data.get("x", 0), data.get("y", 0))}


@app.post("/control/scroll")
async def control_scroll(request: Request) -> dict:
    _require_manual(request)
    data = await request.json()
    control.scroll(int(data.get("clicks", 0)))
    return {"ok": True}


@app.post("/control/key")
async def control_key(request: Request) -> dict:
    _require_manual(request)
    data = await request.json()
    if "text" in data and data["text"]:
        control.send_text(str(data["text"]))
        audit({"kind": "manual_text"})
    elif "key" in data and data["key"]:
        control.send_key(str(data["key"]))
        audit({"kind": "manual_key", "key": data["key"]})
    else:
        raise HTTPException(400, "text 또는 key 를 보내세요.")
    return {"ok": True}


# ---------- 상태 ----------
@app.get("/status")
def status(request: Request) -> dict:
    require_auth(request)
    d = dde_client.snapshot()
    return {
        "mode": "LIVE" if CFG["trading"].get("live_enabled") else "DRYRUN",
        "capture_mode": source.mode,
        "capture_live": capturer.live,      # 화면 공유 on/off (서버 캡쳐 스레드 상태)
        "fps": CFG["capture"].get("fps", 4),
        "control_available": control.AVAILABLE,
        "dde": {k: d[k] for k in ("enabled", "available", "connected", "symbol", "error")},
        "account": {
            "cash": account.cash,
            "cash_only": CFG.get("account", {}).get("cash_only", True),
            "source": account.source,
            # 예수금·매도가능 감시 스위치 상태 — 꺼져 있으면 UI 가 경고를 띄운다.
            "enforce_cash": enforce_cash_enabled(CFG.get("account", {})),
        },
        "otp_enabled": otp_mgr.enabled,
        **safety.snapshot(),
    }
