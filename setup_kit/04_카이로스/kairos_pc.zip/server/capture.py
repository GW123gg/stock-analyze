"""캡쳐 소스(호가창 영역 / 카이로스 창 전체) + 백그라운드 캡쳐 스레드.

Capturer 는 rect_provider() 가 매 프레임 돌려주는 화면 영역을 캡쳐해 최신 JPEG 로 보관하고,
그 프레임에 실제 사용된 화면 좌표(current_rect)를 함께 보관한다(수동 원격조작 좌표 매핑용).
"""
from __future__ import annotations

import io
import threading
import time

import mss
from PIL import Image

try:
    import pygetwindow as gw
except Exception:  # pragma: no cover
    gw = None


class Source:
    """캡쳐 대상 선택: 'region'(설정된 호가창 좌표) 또는 'window'(카이로스 창 전체)."""

    def __init__(self, cap_cfg: dict):
        self.region = {k: int(cap_cfg[k]) for k in ("left", "top", "width", "height")}
        self.window_title = cap_cfg.get("window_title", "카이로스")
        self.mode = cap_cfg.get("mode", "region")

    def set_mode(self, mode: str) -> None:
        if mode not in ("region", "window"):
            raise ValueError("mode 는 'region' 또는 'window'")
        self.mode = mode

    def rect(self) -> dict | None:
        if self.mode == "window":
            if gw is None:
                return None
            try:
                wins = [
                    w for w in gw.getWindowsWithTitle(self.window_title)
                    if w.width > 0 and w.height > 0 and w.left > -10000
                ]
                if not wins:
                    return None
                w = wins[0]
                return {"left": w.left, "top": w.top, "width": w.width, "height": w.height}
            except Exception:
                return None
        return dict(self.region)


class Capturer:
    def __init__(self, rect_provider, fps: int = 4, jpeg_quality: int = 70):
        self.rect_provider = rect_provider
        self.interval = 1.0 / max(1, int(fps))
        self.jpeg_quality = int(jpeg_quality)
        self._latest: bytes | None = None
        self._last_rect: dict | None = None
        self._lock = threading.Lock()
        self._running = False
        self._thread: threading.Thread | None = None

    @property
    def live(self) -> bool:
        """화면 공유(캡쳐 스레드)가 돌고 있는지."""
        return self._running

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """캡쳐 스레드 중단 + 마지막 프레임 폐기.

        프레임을 지우는 게 중요하다 — 안 지우면 공유를 끈 뒤에도 마지막 화면이
        계속 서빙되어 '꺼진 줄 알았는데 화면이 남아있는' 상황이 된다.
        """
        self._running = False
        with self._lock:
            self._latest = None
            self._last_rect = None

    def _loop(self) -> None:
        with mss.mss() as sct:
            while self._running:
                t0 = time.time()
                try:
                    rect = self.rect_provider()
                    if rect and rect["width"] > 0 and rect["height"] > 0:
                        grab = {
                            "left": int(rect["left"]), "top": int(rect["top"]),
                            "width": int(rect["width"]), "height": int(rect["height"]),
                        }
                        shot = sct.grab(grab)
                        img = Image.frombytes("RGB", shot.size, shot.rgb)
                        buf = io.BytesIO()
                        img.save(buf, format="JPEG", quality=self.jpeg_quality)
                        with self._lock:
                            self._latest = buf.getvalue()
                            self._last_rect = grab
                except Exception:
                    pass
                time.sleep(max(0.0, self.interval - (time.time() - t0)))

    def latest_jpeg(self) -> bytes | None:
        with self._lock:
            return self._latest

    def current_rect(self) -> dict | None:
        with self._lock:
            return dict(self._last_rect) if self._last_rect else None
