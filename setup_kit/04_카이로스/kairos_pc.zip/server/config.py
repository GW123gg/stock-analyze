"""설정 로더 — 프로젝트 루트의 config.toml 을 읽습니다."""
from pathlib import Path

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.toml"


def load() -> dict:
    if not CONFIG_PATH.exists():
        raise SystemExit(
            f"[설정 없음] {CONFIG_PATH} 이 없습니다.\n"
            f"  config.example.toml 을 config.toml 로 복사한 뒤 값을 채우세요."
        )
    with open(CONFIG_PATH, "rb") as f:
        return tomllib.load(f)
