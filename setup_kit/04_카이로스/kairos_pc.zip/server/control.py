"""수동 원격조작(크롬 리모트 데스크탑식) — 스트림 화면의 클릭/키입력을 실제 PC에 전달.

스트림 이미지 위의 정규화 좌표(0..1)를 현재 캡쳐 영역(current_rect)에 매핑해 실제 화면 좌표로 클릭한다.
pyautogui.FAILSAFE 를 켜서, 마우스를 화면 좌상단 모서리로 밀면 즉시 중단되는 물리적 비상장치를 둔다.

⚠️ 다중 모니터에서 보조 모니터(음수 좌표)는 pyautogui 매핑이 부정확할 수 있음 → 주 모니터에서 사용 권장.
"""
from __future__ import annotations

try:
    import pyautogui

    pyautogui.FAILSAFE = True   # 마우스를 (0,0) 모서리로 밀면 즉시 예외 → 비상 탈출
    pyautogui.PAUSE = 0.0
    AVAILABLE = True
    IMPORT_ERROR = ""
except Exception as exc:  # pragma: no cover
    AVAILABLE = False
    IMPORT_ERROR = str(exc)


def _to_screen(rect: dict, xn: float, yn: float) -> tuple[int, int]:
    xn = min(max(float(xn), 0.0), 1.0)
    yn = min(max(float(yn), 0.0), 1.0)
    return (
        int(rect["left"] + xn * rect["width"]),
        int(rect["top"] + yn * rect["height"]),
    )


def click(rect: dict, xn: float, yn: float, button: str = "left", double: bool = False) -> dict:
    x, y = _to_screen(rect, xn, yn)
    pyautogui.moveTo(x, y)
    if double:
        pyautogui.doubleClick()
    else:
        pyautogui.click(button="right" if button == "right" else "left")
    return {"x": x, "y": y, "button": button, "double": double}


def move(rect: dict, xn: float, yn: float) -> dict:
    x, y = _to_screen(rect, xn, yn)
    pyautogui.moveTo(x, y)
    return {"x": x, "y": y}


def scroll(clicks: int) -> None:
    pyautogui.scroll(int(clicks))


def send_text(text: str) -> None:
    pyautogui.typewrite(str(text), interval=0.01)


def send_key(key: str) -> None:
    # 예: "enter", "esc", "tab", "backspace", "delete", "up", "down"
    pyautogui.press(str(key))
