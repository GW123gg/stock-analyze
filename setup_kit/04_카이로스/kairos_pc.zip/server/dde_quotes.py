"""카이로스 DDE 실시간 호가 수신 클라이언트.

카이로스: 도구 > 시세 엑셀 연동(DDE) 실행 후, '실시간 데이터 연결' 화면에서 종목을 등록해야
DDE Request 가 값을 돌려주는 경우가 많다(HTS별 상이). service/topic/item 포맷은
카이로스 DDE 도움말에서 확인해 config [dde] 에 채운다.

DDE(win32ui) 객체는 반드시 한 스레드에서 생성·사용하고 메시지 펌프를 돌려야 하므로,
전용 스레드에서만 동작하며 최신 값을 스레드-세이프하게 보관한다(캡쳐 스레드와 동일 패턴).

트리거(종목) 변경: 대부분의 HTS DDE 는 아이템 문자열에 종목코드가 들어가므로
  item 템플릿의 {symbol} 만 바꿔 Request 하면 됨(별도 트리거 불필요).
  만약 '트리거 셀을 Poke 하는' 방식이면 config 의 trigger_item 을 지정한다.
"""
from __future__ import annotations

import threading
import time

try:
    import win32ui
    import dde

    AVAILABLE = True
    IMPORT_ERROR = ""
except Exception as exc:  # pragma: no cover
    AVAILABLE = False
    IMPORT_ERROR = str(exc)


class DDEQuoteClient:
    def __init__(self, cfg: dict):
        self.enabled = bool(cfg.get("enabled", False))
        self.service = cfg.get("service", "")
        self.topic = cfg.get("topic", "")
        self.items = dict(cfg.get("items", {}))            # {논리이름: "아이템템플릿({symbol})"}
        self.trigger_item = cfg.get("trigger_item", "")     # 있으면 종목변경 시 Poke
        self.symbol = str(cfg.get("default_symbol", ""))
        self.poll_hz = max(1, int(cfg.get("poll_hz", 4)))
        self._latest: dict = {}
        self._error = ""
        self._connected = False
        self._pending_symbol: str | None = None
        self._lock = threading.Lock()
        self._running = False
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._running or not self.enabled:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False

    def set_symbol(self, symbol: str) -> None:
        with self._lock:
            self._pending_symbol = str(symbol).strip()

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "enabled": self.enabled,
                "available": AVAILABLE,
                "connected": self._connected,
                "symbol": self.symbol,
                "values": dict(self._latest),
                "error": self._error,
            }

    def _loop(self) -> None:
        if not AVAILABLE:
            with self._lock:
                self._error = f"pywin32 미설치: {IMPORT_ERROR}"
            return
        try:
            server = dde.CreateServer()
            server.Create("KairosBridge")
            conv = dde.CreateConversation(server)
            conv.ConnectTo(self.service, self.topic)
            with self._lock:
                self._connected = bool(conv.Connected())
                if not self._connected:
                    self._error = (
                        f"DDE 연결 안됨(service={self.service!r}, topic={self.topic!r}). "
                        "카이로스 DDE 서비스가 켜져 있는지, 값이 맞는지 확인."
                    )
        except Exception as exc:  # noqa: BLE001
            with self._lock:
                self._error = f"DDE 연결 실패(service={self.service!r}, topic={self.topic!r}): {exc}"
                self._connected = False
            return

        interval = 1.0 / self.poll_hz
        while self._running:
            t0 = time.time()
            with self._lock:
                pend = self._pending_symbol
                self._pending_symbol = None
            if pend:
                self.symbol = pend
                if self.trigger_item:
                    try:
                        conv.Poke(self.trigger_item, self.symbol)
                    except Exception as exc:  # noqa: BLE001
                        with self._lock:
                            self._error = f"트리거 Poke 실패: {exc}"

            out: dict = {}
            last_err = ""
            for name, template in self.items.items():
                item = str(template).replace("{symbol}", self.symbol)
                try:
                    out[name] = conv.Request(item)
                except Exception as exc:  # noqa: BLE001
                    out[name] = None
                    last_err = f"Request 실패(item={item!r}): {exc}"
            with self._lock:
                self._latest = out
                self._error = last_err if last_err else ("" if self._connected else self._error)

            try:
                win32ui.PumpWaitingMessages(0, -1)
            except Exception:
                pass
            time.sleep(max(0.0, interval - (time.time() - t0)))
