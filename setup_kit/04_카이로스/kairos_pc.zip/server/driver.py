"""주문 드라이버 + 안전장치 + 감사로그.

- DryRunDriver : 실제 주문 없이 로그만 남김(기본값)
- KairosDriver : 미래에셋 카이로스 HTS 를 pywinauto 로 구동하는 실거래 드라이버(미완성 스텁)

모든 드라이버는 각 동작 직전에 safety.guard() 를 호출해, 긴급정지/수동모드면 즉시 중단한다.
※ 완전 자동매매 루프는 이 프로젝트에 없다 — place_order 는 사람이 UI 에서 확인했을 때만 호출된다.
"""
from __future__ import annotations

import json
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from pathlib import Path

from server.safety import Safety

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)
AUDIT_FILE = LOG_DIR / "audit.log"
_audit_lock = threading.Lock()


def audit(event: dict) -> dict:
    """추가전용(append-only) 감사로그. 모든 주문/인증/killswitch/긴급정지를 기록한다."""
    event = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), **event}
    with _audit_lock:
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
    return event


@dataclass
class OrderRequest:
    symbol: str      # 종목코드 (예: "005930")
    side: str        # "buy" | "sell"
    qty: int         # 수량
    price: int       # 지정가(원). 이 스캐폴드는 지정가만 지원.
    order_type: str = "limit"


@dataclass
class OrderResult:
    ok: bool
    order_id: str = ""
    message: str = ""


class GuardrailError(Exception):
    """안전장치 위반 — 주문을 실행하지 않는다."""


def apply_guardrails(req: OrderRequest, cfg: dict, last_price: int | None = None) -> None:
    t = cfg["trading"]
    if req.qty <= 0 or req.qty > t["max_order_qty"]:
        raise GuardrailError(f"수량 {req.qty} 이 허용범위(1~{t['max_order_qty']}) 밖")
    if req.price < 0:
        raise GuardrailError("가격이 음수")
    notional = req.qty * req.price
    if req.price > 0 and notional > t["max_notional_krw"]:
        raise GuardrailError(
            f"주문금액 {notional:,}원 이 한도 {t['max_notional_krw']:,}원 초과"
        )
    if last_price and req.price > 0:
        band = t["price_band_pct"] / 100.0
        if abs(req.price - last_price) / last_price > band:
            raise GuardrailError(
                f"지정가 {req.price:,} 가 최근가 {last_price:,} 대비 "
                f"±{t['price_band_pct']}% 밴드를 벗어남"
            )


class OrderDriver(ABC):
    def __init__(self, safety: Safety):
        self.safety = safety

    @abstractmethod
    def place_order(self, req: OrderRequest) -> OrderResult: ...

    def cancel_all(self) -> None:  # 선택 구현
        pass


class DryRunDriver(OrderDriver):
    """실제 주문을 내지 않고 감사로그만 남기는 안전 기본 드라이버."""

    def __init__(self, safety: Safety):
        super().__init__(safety)
        self._n = 0

    def place_order(self, req: OrderRequest) -> OrderResult:
        self.safety.guard()
        self._n += 1
        oid = f"DRYRUN-{self._n:05d}"
        audit({"kind": "order", "mode": "DRYRUN", "order_id": oid, **asdict(req)})
        return OrderResult(True, oid, "DRY-RUN: 실제 주문이 나가지 않았습니다.")

    def prefill(self, symbol: str, side: str, qty: int) -> OrderResult:
        self.safety.guard()
        audit({"kind": "prefill", "mode": "DRYRUN", "symbol": symbol, "side": side, "qty": qty})
        return OrderResult(True, "ARMED", "DRY-RUN: 준비(폼 채움 없음). 피코 드라이버가 아니라 실제 입력은 안 됩니다.")

    def submit_price(self, req: OrderRequest) -> OrderResult:
        self.safety.guard()
        self._n += 1
        oid = f"DRYRUN-{self._n:05d}"
        audit({"kind": "order", "mode": "DRYRUN", "note": "fired_from_armed", "order_id": oid, **asdict(req)})
        return OrderResult(True, oid, "DRY-RUN: 실제 주문이 나가지 않았습니다.")

    def cancel_all(self) -> None:
        audit({"kind": "cancel_all", "mode": "DRYRUN"})


class KairosDriver(OrderDriver):
    """미래에셋 카이로스 [0611] 주식주문 창 자동화 드라이버 (미구현 스텁).

    관찰한 [0611] 주식주문 창 구조(2026-07):
      - 탭:      매수 | 매도 | 정정 | 취소 | 주문내역 | 일지
      - 종목:    [통] 종목코드 입력 + 돋보기/드롭다운
      - 계좌유형: ⦿일반  ○신용   ← ★ 반드시 '일반'(현금). '신용'=미수/융자 → 절대 금지
      - 주문유형: ⦿보통(지정가) ○시장가 ○최유리 , 그리고 ⦿SOR ○KRX ○NXT
      - 수량:    입력칸(+주/최/현), 단가: 입력칸(+원/상)
      - 실행:    매수 탭=빨간 '매 수' / 매도 탭=파란 '매 도' 버튼
      - 참고:    창이 '미수없는금액/미수없는수량'을 직접 표시(=현금 한도 매수가능) → 읽어서 교차검증 가능
      - 주문 시 확인 팝업 + 거래비밀번호(계좌칸 ****) 처리 필요할 수 있음

    ⚠️ 구현 전 trading.live_enabled=false. 각 단계 사이 self.safety.guard().
       좌표보다 pywinauto 컨트롤 기반 우선(창 이동/DPI에 강함). 컨트롤 식별은
       `python tools/inspect_kairos.py` 출력으로 확정.
    """

    def __init__(self, cfg: dict, safety: Safety):
        super().__init__(safety)
        self.cfg = cfg
        # TODO(1): pywinauto 로 [0611] 주식주문 창 연결
        #   from pywinauto import Application
        #   self.app = Application(backend="uia").connect(
        #       path=r"C:\미래에셋증권\카이로스\kairosrun.exe", timeout=10)
        #   self.win = self.app.window(title_re=".*0611.*주식주문.*")  # 실제값은 inspect 로 확정
        raise NotImplementedError(
            "KairosDriver 미구현. tools/inspect_kairos.py 출력을 반영해 채운 뒤 소액 검증. "
            "그 전까지 live_enabled=false."
        )

    def place_order(self, req: OrderRequest) -> OrderResult:
        # 절차(각 단계 사이 self.safety.guard()):
        #   1) 매수/매도 탭 선택(req.side)
        #   2) 종목 입력(req.symbol) → 종목명 로드 확인
        #   3) ★ 계좌유형 '일반' 선택 확인/강제 (신용이면 즉시 중단 — 미수/융자 금지)
        #   4) 주문유형 '보통'(지정가) 선택 확인/강제
        #   5) 수량(req.qty)·단가(req.price) 입력
        #   6) ★ 입력값 read-back → req 와 일치 확인. 불일치면 절대 클릭 말고 중단
        #   7) '매 수'/'매 도' 클릭 → 확인 팝업/거래비번 처리
        #   8) 접수/거부/주문번호 읽어 OrderResult 반환 (+ audit)
        raise NotImplementedError

    def cancel_all(self) -> None:
        # TODO: '취소' 탭에서 전체 미체결 취소 (kill-switch/긴급정지에서 호출)
        raise NotImplementedError
