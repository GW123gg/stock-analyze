"""카이로스 검증/재시도 UI 드라이버.

원리:
  - 이동 = SetCursorPos(y에 +CLICK_Y_OFFSET 보정), 클릭·타이핑 = 피코(HID)
  - 필드 입력 후 그 칸을 '화면 캡처 + OCR'로 되읽어 값이 맞는지 확인 → 틀리면 재시도
  - 매도 탭은 주문버튼 색(빨강=매수 / 파랑=매도)으로 확인 → 아니면 재시도

전제: 카이로스가 '포커스를 가진 맨 앞 창'이어야 함(전용 데스크톱 권장).
OCR: pytesseract + Tesseract 바이너리 필요. 없으면 검증은 건너뛰고 입력만 함(경고).
"""
from __future__ import annotations

import ctypes
import time

import mss
from PIL import Image

try:
    import pytesseract
    OCR_OK = True
    OCR_ERR = ""
except Exception as exc:  # pragma: no cover
    OCR_OK = False
    OCR_ERR = str(exc)

_user32 = ctypes.windll.user32


def _set_cursor(x, y):
    _user32.SetCursorPos(int(x), int(y))


def _grab(left, top, width, height) -> Image.Image:
    with mss.mss() as sct:
        shot = sct.grab({"left": int(left), "top": int(top),
                         "width": int(width), "height": int(height)})
        return Image.frombytes("RGB", shot.size, shot.rgb)


class KairosUI:
    def __init__(self, coords: dict, pico, click_y_offset: int = 49,
                 tesseract_cmd: str | None = None):
        self.coords = coords
        self.pico = pico
        self.offset = click_y_offset
        # 필드 값 캡처 영역(클릭점 기준). 필요시 조정.
        self.region_left = 120   # 클릭점에서 왼쪽으로
        self.region_right = 40   # 클릭점에서 오른쪽으로
        self.region_h = 24
        if tesseract_cmd and OCR_OK:
            pytesseract.pytesseract.tesseract_cmd = tesseract_cmd

    # ---------- 포커스 ----------
    def focus(self) -> bool:
        try:
            import pygetwindow as gw
            wins = [w for w in gw.getWindowsWithTitle("미래에셋증권")
                    if w.width > 500 and w.height > 400]
            if not wins:
                return False
            hwnd = wins[0]._hWnd
            k = ctypes.windll.kernel32
            _user32.ShowWindow(hwnd, 9)   # SW_RESTORE
            fg = _user32.GetForegroundWindow()
            fgt = _user32.GetWindowThreadProcessId(fg, 0)
            cur = k.GetCurrentThreadId()
            _user32.AttachThreadInput(fgt, cur, True)
            _user32.BringWindowToTop(hwnd)
            _user32.SetForegroundWindow(hwnd)
            _user32.AttachThreadInput(fgt, cur, False)
            time.sleep(0.5)
            return True
        except Exception:
            return False

    # ---------- 클릭(오프셋 보정) ----------
    def click(self, key: str):
        x, y = self.coords[key]
        _set_cursor(x, y + self.offset)
        time.sleep(0.4)
        self.pico.click()
        time.sleep(0.6)

    # ---------- 필드 값 OCR ----------
    def read_field(self, key: str):
        if not OCR_OK:
            return None
        x, y = self.coords[key]
        img = _grab(x - self.region_left, y - self.region_h // 2,
                    self.region_left + self.region_right, self.region_h)
        img = img.resize((img.width * 3, img.height * 3))
        txt = pytesseract.image_to_string(
            img, config="--psm 7 -c tessedit_char_whitelist=0123456789")
        return "".join(c for c in txt if c.isdigit())

    def set_field(self, key: str, value, retries: int = 3) -> bool:
        want = str(value).replace(",", "")
        for att in range(1, retries + 1):
            self.click(key)
            self.pico.clear_and_type(str(value))
            time.sleep(0.6)
            got = self.read_field(key)
            if got is None:
                print(f"  [{key}] OCR 미설치 — 검증 생략(값 {value} 입력함)")
                return True
            if got == want:
                print(f"  [{key}] OK = {got}")
                return True
            print(f"  [{key}] 불일치 got={got!r} want={want!r} → 재시도 {att}/{retries}")
        print(f"  [{key}] {retries}회 실패 — 중단 권장")
        return False

    # ---------- 매도 탭(주문버튼 색으로 확인) ----------
    def _order_btn_is_sell(self):
        if "btn_sell" not in self.coords:
            return None
        x, y = self.coords["btn_sell"]
        img = _grab(x - 25, y - 10, 50, 20)
        r, g, b = img.resize((1, 1)).getpixel((0, 0))
        # 파랑(매도) 이면 b 가 r 보다 확실히 큼 / 빨강(매수) 이면 r 이 큼
        return b > r + 20

    def select_sell_tab(self, retries: int = 3) -> bool:
        for att in range(1, retries + 1):
            self.click("tab_sell")
            time.sleep(0.5)
            state = self._order_btn_is_sell()
            if state is None:
                print("  [매도탭] 색 확인 불가(btn_sell 좌표 없음) — 클릭만 함")
                return True
            if state:
                print("  [매도탭] OK (파랑 매도)")
                return True
            print(f"  [매도탭] 아직 매수 → 재시도 {att}/{retries}")
        print("  [매도탭] 전환 실패")
        return False
