"""이메일 OTP: 서버가 코드 생성/해시저장/검증하고, 발송만 Apps Script(MailApp)에 위임.

보안 원칙(이전 설계 그대로):
- 코드 원문은 저장하지 않는다. salted HMAC 해시 + 만료시각 + 시도횟수만 보관.
- 코드 생성은 CSPRNG(secrets). Apps Script 에는 거래 보안키를 두지 않고, 공유 시크릿으로
  '발송 요청'만 인증한다.
- 1회용 + 짧은 TTL + 시도횟수 제한 + 재발송 쿨다운으로 무차별/스팸을 막는다.
- 한계: 같은 Gmail 이 뚫리면 OTP 도 함께 노출 → 진짜 2FA 아님(확인 단계 + 감사기록).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import threading
import time
import urllib.request


class OTPManager:
    def __init__(self, cfg: dict):
        self.enabled = bool(cfg.get("enabled", False))
        self.url = cfg.get("apps_script_url", "")
        self.shared_secret = cfg.get("shared_secret", "")
        self.code_length = int(cfg.get("code_length", 6))
        self.ttl = int(cfg.get("ttl_seconds", 180))
        self.max_attempts = int(cfg.get("max_attempts", 5))
        self.resend_cooldown = int(cfg.get("resend_cooldown_seconds", 30))
        self._salt = secrets.token_bytes(16)
        self._hash: str | None = None
        self._exp = 0.0
        self._attempts = 0
        self._last_sent = 0.0
        self._lock = threading.Lock()

    def _hash_code(self, code: str) -> str:
        return hmac.new(self._salt, code.encode(), hashlib.sha256).hexdigest()

    def request_code(self) -> tuple[bool, str]:
        """새 코드 생성 후 Apps Script 로 발송. 발송 성공 시에만 상태를 커밋한다."""
        if not self.enabled:
            return False, "OTP 비활성 상태입니다."
        now = time.time()
        with self._lock:
            elapsed = now - self._last_sent
            if elapsed < self.resend_cooldown:
                return False, f"{int(self.resend_cooldown - elapsed)}초 후 재발송할 수 있습니다."
        code = "".join(secrets.choice("0123456789") for _ in range(self.code_length))
        ok, msg = self._send(code)
        if not ok:
            return False, msg
        with self._lock:
            self._hash = self._hash_code(code)
            self._exp = now + self.ttl
            self._attempts = 0
            self._last_sent = now
        return True, msg

    def _send(self, code: str) -> tuple[bool, str]:
        if not self.url or not self.shared_secret:
            return False, "OTP 설정(apps_script_url/shared_secret)이 비어 있습니다."
        body = json.dumps({"secret": self.shared_secret, "code": code}).encode()
        req = urllib.request.Request(
            self.url, data=body,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                resp.read()
            return True, "인증코드를 이메일로 보냈습니다."
        except Exception as exc:  # noqa: BLE001
            return False, f"발송 실패: {exc}"

    def verify(self, code: str) -> bool:
        if not self.enabled:
            return True   # 비활성이면 토큰만으로 로그인 허용
        now = time.time()
        with self._lock:
            if not self._hash or now > self._exp:
                return False
            if self._attempts >= self.max_attempts:
                self._hash = None
                return False
            self._attempts += 1
            ok = hmac.compare_digest(self._hash, self._hash_code(str(code)))
            if ok:
                self._hash = None   # 1회용
            return ok
