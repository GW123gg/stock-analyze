"""PicoKairosDriver — 서버에서 [0611] 주식주문 창을 '피코 HID'로 구동하는 주문 드라이버.

왜 피코인가: 카이로스 보안모듈(AhnLab/nProtect)이 pyautogui 등 소프트웨어 합성입력을 막는다.
            → 실물 USB HID(피코)만 통과. (kairos_macro.py 에서 검증된 방식.)

★★ 안전 설계 (실제 주식 주문이라 매우 보수적) ★★
  - 기본 DRY-RUN: 폼(탭·종목·수량·단가)만 채우고 '주문버튼을 누르지 않는다'. 사용자가 스트림으로
    값을 확인한 뒤 원격조작/직접 눌러 실행. (kairos_macro 와 동일한 안전 기본값)
  - LIVE(cfg.trading.live_enabled=true) 여도: 화면에서 종목·수량·단가를 '읽어(OCR)' 요청과
    일치할 때만 주문버튼을 누른다. 읽기검증이 불가/불일치면 절대 안 누른다.
  - 거래비밀번호/공동인증서는 이 드라이버가 '절대' 자동입력하지 않는다.
    → 카이로스에서 '거래비밀번호 저장'을 켜 둘 것. 주문 시 거래비번 프롬프트가 뜨면 즉시 중단+알림.
  - 매 단계 self.safety.guard() (긴급정지/킬스위치면 즉시 중단).
  - 상위(app.py)에서 이미 한도/현금계좌/가격밴드 검사를 통과한 요청만 여기로 온다.

좌표: kairos_coords.json (tab_buy/tab_sell/field_symbol/field_qty/field_price/btn_buy/btn_sell).
      전용 노트북의 해상도/배율에 맞게 재보정 필요(tools/kairos_macro.py 의 '한 칸 테스트'로).
"""
from __future__ import annotations

import ctypes
import json
import re
import threading
import time
from pathlib import Path

from server.driver import OrderDriver, OrderRequest, OrderResult, audit
from server.hid_serial import PicoHID, find_pico_port
from server.safety import Safety

BASE = Path(__file__).resolve().parent.parent
COORDS_FILE = BASE / "kairos_coords.json"


class OrderVerifyError(Exception):
    """화면 읽기검증 실패 — 주문버튼을 누르지 않는다."""


# ---- 마우스 가속 제어(절대이동 정확도) ----
_u = ctypes.windll.user32
_SPI_SETMOUSE, _SPI_GETMOUSE = 0x0004, 0x0003
_SPI_SETMOUSESPEED, _SPI_GETMOUSESPEED = 0x0071, 0x0070


def _accel_off_save():
    a = (ctypes.c_int * 3)()
    _u.SystemParametersInfoW(_SPI_GETMOUSE, 0, a, 0)
    s = ctypes.c_int()
    _u.SystemParametersInfoW(_SPI_GETMOUSESPEED, 0, ctypes.byref(s), 0)
    _u.SystemParametersInfoW(_SPI_SETMOUSE, 0, (ctypes.c_int * 3)(0, 0, 0), 0)
    _u.SystemParametersInfoW(_SPI_SETMOUSESPEED, 0, ctypes.c_void_p(10), 0)
    return a, s


def _accel_restore(saved):
    a, s = saved
    _u.SystemParametersInfoW(_SPI_SETMOUSE, 0, a, 0)
    _u.SystemParametersInfoW(_SPI_SETMOUSESPEED, 0, ctypes.c_void_p(s.value), 0)


def _digits(s: str) -> str:
    return re.sub(r"[^0-9]", "", s or "")


class PicoKairosDriver(OrderDriver):
    def __init__(self, cfg: dict, safety: Safety):
        super().__init__(safety)
        self.cfg = cfg
        self.live = bool(cfg.get("trading", {}).get("live_enabled", False))
        self.coords = json.loads(COORDS_FILE.read_text(encoding="utf-8"))
        # 읽기검증 영역(선택): kairos_coords.json 에 verify_symbol/verify_qty/verify_price =
        #   [left, top, width, height] 가 있으면 그 영역을 OCR 해서 값 비교.
        self.step_gap = float(cfg.get("trading", {}).get("order_step_gap_sec", 0.6))
        self._lock = threading.Lock()
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass

    # ---------- 저수준(피코) ----------
    def _click(self, pico: PicoHID, key: str) -> None:
        x, y = self.coords[key]
        pico.move_abs(int(x), int(y))
        time.sleep(0.35)
        pico.click()
        time.sleep(0.4)

    def _type_field(self, pico: PicoHID, key: str, value) -> None:
        self._click(pico, key)
        pico.clear_and_type(str(value))   # CLEAR(Ctrl+A+Backspace) 후 타이핑
        time.sleep(0.4)

    # ---------- 읽기검증(OCR, best-effort) ----------
    def _ocr_region(self, key: str):
        """kairos_coords.json 의 verify_<key>=[l,t,w,h] 를 OCR. 설정/의존성 없으면 None."""
        box = self.coords.get(f"verify_{key}")
        if not box:
            return None
        try:
            import mss
            import pytesseract
            from PIL import Image
        except Exception:
            return None
        l, t, w, h = box
        with mss.mss() as sct:
            img = sct.grab({"left": l, "top": t, "width": w, "height": h})
            pil = Image.frombytes("RGB", img.size, img.rgb)
        txt = pytesseract.image_to_string(pil, config="--psm 7 -c tessedit_char_whitelist=0123456789")
        return _digits(txt)

    def _verify(self, req: OrderRequest) -> None:
        """화면의 종목/수량/단가가 요청과 일치하는지 확인. 하나라도 불일치/불가면 예외."""
        checks = {"symbol": req.symbol, "qty": str(req.qty), "price": str(req.price)}
        for key, want in checks.items():
            got = self._ocr_region(key)
            if got is None:
                raise OrderVerifyError(
                    f"읽기검증 불가(verify_{key} 미설정 또는 OCR 미설치) — 주문버튼 누르지 않음")
            if _digits(got) != _digits(want):
                raise OrderVerifyError(f"{key} 불일치: 화면 '{got}' ≠ 요청 '{want}' — 주문 중단")

    def _transaction_pw_prompt_open(self) -> bool:
        """주문 후 '거래비밀번호' 입력 프롬프트가 떴는지(제목/크기로 추정). 뜨면 자동입력 금지 → 중단."""
        try:
            import pygetwindow as gw
            for w in gw.getAllWindows():
                t = (w.title or "")
                if any(k in t for k in ("거래비밀번호", "주문비밀번호")) and getattr(w, "visible", True):
                    return True
        except Exception:
            pass
        return False

    # ---------- 주문 ----------
    def place_order(self, req: OrderRequest) -> OrderResult:
        with self._lock:
            self.safety.guard()
            tab_key = "tab_sell" if req.side == "sell" else "tab_buy"
            btn_key = "btn_sell" if req.side == "sell" else "btn_buy"
            saved = _accel_off_save()
            pico = PicoHID(find_pico_port())
            try:
                pico.connect()
                # 1) 폼 채우기 (탭 → 종목 → 수량 → 단가)
                for label, fn in (
                    (tab_key, lambda: self._click(pico, tab_key)),
                    ("symbol", lambda: self._type_field(pico, "field_symbol", req.symbol)),
                    ("qty", lambda: self._type_field(pico, "field_qty", req.qty)),
                    ("price", lambda: self._type_field(pico, "field_price", req.price)),
                ):
                    self.safety.guard()
                    fn()
                    time.sleep(self.step_gap)

                # 2) DRY-RUN: 여기서 멈춤(주문버튼 안 누름).
                if not self.live:
                    audit({"kind": "order", "mode": "DRYRUN", "note": "form_filled_not_submitted",
                           "symbol": req.symbol, "side": req.side, "qty": req.qty, "price": req.price})
                    return OrderResult(
                        True, "DRYRUN",
                        "DRY-RUN: 폼만 채웠습니다(주문버튼 안 누름). 스트림으로 값 확인 후 직접/원격조작으로 실행하세요.")

                # 3) LIVE: 화면 읽기검증 통과해야만 주문버튼.
                self._verify(req)
                self.safety.guard()
                self._click(pico, btn_key)          # 주문버튼 클릭
                time.sleep(0.8)

                # 4) 거래비밀번호 프롬프트가 뜨면 → 자동입력 금지 → 중단(카이로스에 비번저장 필요).
                if self._transaction_pw_prompt_open():
                    audit({"kind": "order_blocked_txpw", "symbol": req.symbol})
                    raise OrderVerifyError(
                        "거래비밀번호 프롬프트가 떴습니다 — 자동입력 안 함. 카이로스에서 '거래비밀번호 저장'을 켜세요.")

                # 5) 주문 확인 팝업 → Enter(확인). (확인버튼 좌표를 쓰려면 coords에 btn_confirm 추가)
                if "btn_confirm" in self.coords:
                    self._click(pico, "btn_confirm")
                else:
                    pico.key("ENTER")
                time.sleep(0.8)

                audit({"kind": "order", "mode": "LIVE", "symbol": req.symbol,
                       "side": req.side, "qty": req.qty, "price": req.price})
                return OrderResult(
                    True, "SUBMITTED",
                    "LIVE 주문을 제출했습니다. 카이로스 주문내역/체결을 반드시 확인하세요.")
            finally:
                try:
                    pico.close()
                except Exception:
                    pass
                _accel_restore(saved)

    # ---------- 2단계 주문: 준비(종목·수량 미리 채움) → 발사(가격만) ----------
    def prefill(self, symbol: str, side: str, qty: int) -> OrderResult:
        """[0611] 창에 탭·종목·수량만 미리 채운다(가격은 비워두고, 주문버튼 안 누름).
        이후 submit_price(price) 로 가격만 넣고 발사한다."""
        with self._lock:
            self.safety.guard()
            tab_key = "tab_sell" if side == "sell" else "tab_buy"
            saved = _accel_off_save()
            pico = PicoHID(find_pico_port())
            try:
                pico.connect()
                for fn in (
                    lambda: self._click(pico, tab_key),
                    lambda: self._type_field(pico, "field_symbol", symbol),
                    lambda: self._type_field(pico, "field_qty", qty),
                ):
                    self.safety.guard()
                    fn()
                    time.sleep(self.step_gap)
                audit({"kind": "prefill", "symbol": symbol, "side": side, "qty": qty})
                return OrderResult(
                    True, "ARMED",
                    f"준비 완료: {('매도' if side == 'sell' else '매수')} {symbol} {qty}주. 이제 가격만 넣고 발사하세요.")
            finally:
                try:
                    pico.close()
                except Exception:
                    pass
                _accel_restore(saved)

    def submit_price(self, req: OrderRequest) -> OrderResult:
        """준비된 티켓에 '가격만' 채우고 발사. LIVE 는 화면(종목·수량·가격) 읽기검증 통과 시에만 주문버튼.
        DRY-RUN 은 가격만 채우고 멈춘다."""
        with self._lock:
            self.safety.guard()
            btn_key = "btn_sell" if req.side == "sell" else "btn_buy"
            saved = _accel_off_save()
            pico = PicoHID(find_pico_port())
            try:
                pico.connect()
                # 가격만 입력(종목·수량은 prefill 로 이미 들어가 있음)
                self._type_field(pico, "field_price", req.price)
                time.sleep(self.step_gap)

                if not self.live:
                    audit({"kind": "order", "mode": "DRYRUN", "note": "price_filled_not_submitted",
                           "symbol": req.symbol, "side": req.side, "qty": req.qty, "price": req.price})
                    return OrderResult(
                        True, "DRYRUN",
                        f"DRY-RUN: 가격 {req.price:,} 을 채웠습니다(주문버튼 안 누름). 스트림으로 확인하세요.")

                # LIVE: 종목·수량(준비값)·가격이 화면과 일치할 때만 발사.
                self._verify(req)
                self.safety.guard()
                self._click(pico, btn_key)
                time.sleep(0.8)
                if self._transaction_pw_prompt_open():
                    audit({"kind": "order_blocked_txpw", "symbol": req.symbol})
                    raise OrderVerifyError(
                        "거래비밀번호 프롬프트가 떴습니다 — 자동입력 안 함. 카이로스 '거래비밀번호 저장'을 켜세요.")
                if "btn_confirm" in self.coords:
                    self._click(pico, "btn_confirm")
                else:
                    pico.key("ENTER")
                time.sleep(0.8)
                audit({"kind": "order", "mode": "LIVE", "note": "fired_from_armed",
                       "symbol": req.symbol, "side": req.side, "qty": req.qty, "price": req.price})
                return OrderResult(
                    True, "SUBMITTED",
                    "LIVE 주문 발사. 카이로스 주문내역/체결을 반드시 확인하세요.")
            finally:
                try:
                    pico.close()
                except Exception:
                    pass
                _accel_restore(saved)

    def cancel_all(self) -> None:
        # 미체결 전체취소는 [0611] '취소' 탭 구동이 필요 — 좌표 확정 후 구현.
        # 킬스위치/긴급정지에서 호출되므로, 미구현이면 로그만 남기고 사람이 직접 취소.
        audit({"kind": "cancel_all", "note": "PicoKairosDriver.cancel_all 미구현 — 사람이 직접 취소"})
