"""안전 상태 머신.

- emergency_stop : 긴급정지. 자동화를 즉시 중단하고 수동 원격조작을 허용.
- manual_mode    : 수동 원격조작 모드(사람이 화면을 직접 클릭/타이핑). 켜지면 자동화 차단.
- killswitch     : 주문 차단(+미체결 취소).

핵심 규칙: 자동화와 사람의 조작이 마우스를 동시에 다투지 않도록,
manual_mode 또는 emergency_stop 중 하나라도 켜지면 자동화(주문 드라이버)는 동작하지 않는다.
"""


class Aborted(Exception):
    """긴급정지/수동모드로 자동화가 중단됨."""


class Safety:
    def __init__(self) -> None:
        self.emergency_stop = False
        self.manual_mode = False
        self.killswitch = False

    def automation_allowed(self) -> bool:
        return not (self.emergency_stop or self.manual_mode)

    def manual_allowed(self) -> bool:
        return self.emergency_stop or self.manual_mode

    def guard(self) -> None:
        """자동화 드라이버가 매 동작(클릭/입력) 직전에 호출한다.

        긴급정지/수동모드면 즉시 예외를 던져 진행 중인 자동 시퀀스를 끊는다.
        (단일 블로킹 호출 자체를 선점하진 못하므로, 드라이버는 동작을 잘게 쪼개
         각 단계 사이에서 이 함수를 호출해야 한다.)
        """
        if self.emergency_stop:
            raise Aborted("긴급정지(EMERGENCY STOP) — 자동화 중단됨")
        if self.manual_mode:
            raise Aborted("수동 원격조작 모드 — 자동화 중단됨")

    def snapshot(self) -> dict:
        return {
            "emergency_stop": self.emergency_stop,
            "manual_mode": self.manual_mode,
            "killswitch": self.killswitch,
            "automation_allowed": self.automation_allowed(),
            "manual_allowed": self.manual_allowed(),
        }
