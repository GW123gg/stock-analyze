@echo off
rem ============================================================
rem  Kairos Bridge - Tailscale Funnel + server (FastAPI/uvicorn)
rem
rem  Usage:
rem    start_server.cmd                 local 8443, funnel public 443
rem    start_server.cmd 8443 443        explicit (local, public)
rem    start_server.cmd 8443 nofunnel   local only, no funnel
rem
rem  Funnel public port must be one of: 443 / 8443 / 10000
rem  Stop server : Ctrl+C   |  Stop funnel : tailscale funnel --https=443 off
rem  Check       : tailscale funnel status
rem ============================================================
setlocal
set "PROJ=C:\Users\USER\Desktop\mirae asset securities auto"

set "PORT=%~1"
if not defined PORT set "PORT=8443"
set "PUBPORT=%~2"
if not defined PUBPORT set "PUBPORT=443"

rem -- resolve python full path (PATH alias 'python' fails in non-interactive shells) --
set "PY="
for /d %%D in ("C:\Users\USER\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.*") do set "PY=%%D\python.exe"
if not defined PY for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do set "PY=%%D\python.exe"
if not defined PY set "PY=python"

rem -- resolve tailscale full path --
set "TS=C:\Program Files\Tailscale\tailscale.exe"
if not exist "%TS%" set "TS=C:\Program Files (x86)\Tailscale IPN\tailscale.exe"
if not exist "%TS%" set "TS=tailscale"

cd /d "%PROJ%"
if not exist "config.toml" (
  echo [ERROR] config.toml not found in "%PROJ%".
  echo         Copy config.example.toml to config.toml and set auth.access_token.
  exit /b 1
)

rem ---- 1) Tailscale Funnel: public %PUBPORT% -> local %PORT% -------------------
rem  --bg  : keep serving after this command returns (persists in tailscaled)
rem  --yes : no interactive prompt (required for Task Scheduler)
rem  Using an explicit --https port so we ADD a mapping instead of clobbering
rem  any other funnel/serve entry already configured on this machine.
if /i "%PUBPORT%"=="nofunnel" (
  echo [funnel] skipped - local/tailnet only
) else (
  echo [funnel] public %PUBPORT% -^> local %PORT% ...
  "%TS%" funnel --bg --yes --https=%PUBPORT% %PORT%
  if errorlevel 1 (
    echo [funnel] WARNING: could not enable Funnel. The server still runs
    echo          locally and on the tailnet. Common causes:
    echo            - Tailscale not logged in        ^(tailscale status^)
    echo            - Funnel not enabled for tailnet ^(admin console / follow the printed link^)
    echo            - public port not 443/8443/10000
  ) else (
    "%TS%" funnel status
  )
)

rem ---- 2) Server ---------------------------------------------------------------
echo.
echo Starting Kairos bridge server on local port %PORT% ...
echo   local : http://127.0.0.1:%PORT%
echo   stop  : Ctrl+C
echo.
"%PY%" -m uvicorn server.app:app --host 0.0.0.0 --port %PORT%
