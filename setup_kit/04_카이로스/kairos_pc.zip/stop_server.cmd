@echo off
rem ============================================================
rem  Kairos Bridge - STOP server + remove OUR Tailscale Funnel
rem
rem  Usage:
rem    stop_server.cmd              stop server(8443) + funnel public 443
rem    stop_server.cmd 8443 443     explicit (local port, funnel public port)
rem    stop_server.cmd 8443 keep    stop server only, leave funnel alone
rem
rem  SAFETY: only the funnel entry for THIS public port is removed.
rem          Other serve/funnel entries on this machine are untouched.
rem  Check:  tailscale funnel status
rem ============================================================
setlocal
set "PORT=%~1"
if not defined PORT set "PORT=8443"
set "PUBPORT=%~2"
if not defined PUBPORT set "PUBPORT=443"

set "TS=C:\Program Files\Tailscale\tailscale.exe"
if not exist "%TS%" set "TS=C:\Program Files (x86)\Tailscale IPN\tailscale.exe"
if not exist "%TS%" set "TS=tailscale"

rem ---- 1) remove our funnel entry (public %PUBPORT%) ---------------------------
if /i "%PUBPORT%"=="keep" (
  echo [funnel] left as-is
) else (
  echo [funnel] removing public %PUBPORT% mapping ...
  "%TS%" funnel --https=%PUBPORT% off
  if errorlevel 1 (
    echo [funnel] WARNING: could not turn off. Check: "%TS%" funnel status
  ) else (
    echo [funnel] removed. Remaining config:
    "%TS%" funnel status
  )
)

rem ---- 2) stop the server listening on local %PORT% ----------------------------
echo.
echo [server] stopping python listening on port %PORT% ...
powershell -NoProfile -Command ^
  "$n=0; Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue | ForEach-Object { $p = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue; if ($p -and $p.ProcessName -match '^python') { Stop-Process -Id $p.Id -Force; Write-Host ('  stopped PID ' + $p.Id); $n++ } }; if ($n -eq 0) { Write-Host '  (no python server was listening)' }"

echo.
echo Done. To also stop the scheduled task:  schtasks /End /TN KairosServer
