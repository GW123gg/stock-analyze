"""카이로스 [0611] 주문창 좌표 캘리브레이션.

★ 캡처(GetCursorPos)와 이동(SetCursorPos)을 '같은 Windows API + DPI-aware'로 통일 →
  pyautogui 의 고DPI 이동 부정확 문제를 회피. (pyautogui 안 씀)

전용 데스크톱(고정 레이아웃)에서 한 번 실행. 캘리브레이션 중 카이로스 창을 움직이지 마세요.
실행: python tools/calibrate_kairos.py  → kairos_coords.json 생성 + 확인 순회
"""
import ctypes
import json
import time
from ctypes import wintypes
from pathlib import Path

# 고DPI(125/150%)에서 좌표가 물리 픽셀로 일관되도록 DPI-aware 로.
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)   # PER_MONITOR_DPI_AWARE
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

_user32 = ctypes.windll.user32


def get_cursor():
    p = wintypes.POINT()
    _user32.GetCursorPos(ctypes.byref(p))
    return p.x, p.y


def set_cursor(x, y):
    _user32.SetCursorPos(int(x), int(y))


TARGETS = [
    ("tab_buy",      "매수 탭"),
    ("tab_sell",     "매도 탭"),
    ("field_symbol", "종목 입력칸"),
    ("field_qty",    "수량 입력칸"),
    ("field_price",  "단가(노란칸)"),
    ("btn_buy",      "매수 버튼  (좌표만 저장, 누르지 않음)"),
    ("btn_sell",     "매도 버튼  (좌표만 저장, 누르지 않음)"),
]

print("카이로스 [0611] 주식주문 창을 화면에 띄워두세요.")
print("※ 이 터미널에 포커스를 둔 채, '마우스만' 해당 위치로 옮기고 Enter (클릭하지 마세요)\n")

coords = {}
for key, label in TARGETS:
    input(f"  ▶ '{label}' 위에 마우스를 올리고 Enter...")
    x, y = get_cursor()
    coords[key] = [x, y]
    print(f"     저장: {key} = ({x}, {y})")

out = Path(__file__).resolve().parent.parent / "kairos_coords.json"
out.write_text(json.dumps(coords, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\n저장 완료 → {out}")

input("\n확인 순회를 시작합니다(같은 SetCursorPos 로 이동). 카이로스를 보며 확인. Enter...")
for key, label in TARGETS:
    x, y = coords[key]
    set_cursor(x, y)
    print(f"  → 지금 커서가 '{label}' 위에 정확히 있나요?  ({x}, {y})")
    time.sleep(1.3)

print("\n모두 정확하면 성공. 어긋난 항목만 다시 잡으세요(재실행).")
