"""사전 점검(pre-flight). 서버 실행 전에 환경/의존성/설정 문제를 미리 잡는다.

실행: python tools/doctor.py
"""
import importlib
import platform
import socket
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))   # 'server' 패키지를 import 하기 위해 프로젝트 루트를 경로에 추가

# 한글 윈도우 콘솔(cp949)에서도 깨지거나 죽지 않도록 stdout 을 utf-8 로 재설정
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def check(mod: str):
    try:
        importlib.import_module(mod)
        return True, ""
    except Exception as exc:  # noqa: BLE001
        msg = str(exc).splitlines()[0] if str(exc) else type(exc).__name__
        return False, msg


print("=" * 52)
print(f"Python : {sys.version.split()[0]}   ({platform.system()} {platform.release()})")
print(f"root   : {ROOT}")
print("=" * 52)

print("[의존성 패키지]")
missing = []
for m in ["fastapi", "uvicorn", "mss", "PIL", "pygetwindow", "pyautogui", "win32ui", "dde"]:
    ok, err = check(m)
    print(f"  {'OK ' if ok else 'X  '} {m}" + ("" if ok else f"   -> {err}"))
    if not ok:
        missing.append(m)
ok_toml = check("tomllib")[0] or check("tomli")[0]
print(f"  {'OK ' if ok_toml else 'X  '} tomllib/tomli" + ("" if ok_toml else "   -> pip install tomli"))

print("\n[프로젝트 모듈]")
for m in ["server.safety", "server.control", "server.capture", "server.driver",
          "server.dde_quotes", "server.account", "server.otp", "server.config"]:
    ok, err = check(m)
    print(f"  {'OK ' if ok else 'X  '} {m}" + ("" if ok else f"   -> {err}"))

print("\n[수동조작(pyautogui) 사용 가능 여부]")
try:
    from server import control
    if control.AVAILABLE:
        print("  OK  pyautogui 로 원격 마우스/키보드 전달 가능")
    else:
        print(f"  !!  수동조작 불가: {control.IMPORT_ERROR}")
except Exception as exc:  # noqa: BLE001
    print(f"  ?   control 모듈 로드 실패: {exc}")

print("\n[설정 파일]")
cfg = ROOT / "config.toml"
if cfg.exists():
    print("  OK  config.toml 존재")
    try:
        import tomllib as T  # type: ignore
    except ModuleNotFoundError:
        import tomli as T  # type: ignore
    with open(cfg, "rb") as f:
        c = T.load(f)
    tok = c.get("auth", {}).get("access_token", "")
    if "CHANGE_ME" in tok or len(tok) < 16:
        print("  !!  access_token 이 기본값/너무 짧음 - 긴 무작위 문자열로 교체하세요")
    else:
        print("  OK  access_token 설정됨")
    a, cap = c.get("auth", {}), c.get("capture", {})
    print(f"      cookie_secure = {a.get('cookie_secure')}  (로컬 http 테스트면 false 권장)")
    print(f"      capture.mode  = {cap.get('mode')} / window_title = {cap.get('window_title')!r}")
    print(f"      live_enabled  = {c.get('trading', {}).get('live_enabled')}  (검증 전 false)")
else:
    print("  X   config.toml 없음 - 'copy config.example.toml config.toml' 후 값 입력")

print("\n[포트 8443]")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(0.5)
free = s.connect_ex(("127.0.0.1", 8443)) != 0
s.close()
print("  OK  8443 사용 가능" if free else "  !!  8443 이 이미 사용 중(다른 프로세스 종료 또는 포트 변경)")

print("\n" + "=" * 52)
if missing:
    print(f"조치: pip install -r requirements.txt   (누락: {', '.join(missing)})")
elif not cfg.exists():
    print("조치: config.toml 생성 후 다시 실행")
else:
    print("환경 OK — uvicorn server.app:app --host 0.0.0.0 --port 8443")
print("=" * 52)
