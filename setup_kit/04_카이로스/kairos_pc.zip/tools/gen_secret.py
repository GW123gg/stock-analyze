"""공유 시크릿 생성기.

출력된 '한 줄'을 아래 두 곳에 '똑같이' 붙여넣으세요(이 값이 일치할 때만 메일이 발송됨):
  - cowork/code.gs      의  SHARED_SECRET
  - cowork/notify.json  의  shared_secret

실행: python tools/gen_secret.py

※ 이 스크립트는 로컬에서 직접 실행하세요. 값을 화면 캡쳐/채팅에 붙여넣지 마세요.
"""
import secrets

s = secrets.token_urlsafe(32)
print("=== 공유 시크릿 (아래 한 줄을 두 곳에 붙여넣기) ===")
print(s)
print("--------------------------------------------------")
print("  → cowork/code.gs      SHARED_SECRET = '위 값'")
print("  → cowork/notify.json  \"shared_secret\": \"위 값\"")
