"""서버 접속용 access_token 생성기.

이 토큰이 있어야 웹/앱에서 서버(호가창·주문)에 접속할 수 있다.
Tailscale Funnel 로 인터넷에 공개되므로 **반드시 길고 무작위**여야 한다.

사용:
  python tools/gen_token.py           # 새 토큰을 만들어 화면에만 출력(파일 안 건드림)
  python tools/gen_token.py --write   # config.toml 의 access_token 을 새 값으로 교체(.bak 백업)
  python tools/gen_token.py --show    # 지금 config.toml 에 들어있는 토큰 보기

※ 로컬에서 직접 실행하세요. 값을 채팅/스크린샷에 붙여넣지 마세요.
※ --write 로 바꾸면 이미 접속 중인 웹/앱은 로그아웃되고, 저장해둔 보안키도 새 값으로 다시 넣어야 합니다.
"""
from __future__ import annotations

import re
import secrets
import shutil
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(errors="replace")
except Exception:
    pass

BASE = Path(__file__).resolve().parent.parent
CFG = BASE / "config.toml"
EXAMPLE = BASE / "config.example.toml"
BAK = BASE / "config.toml.bak"

# [auth] 아래의  access_token = "...."  줄
PAT = re.compile(r'^(\s*access_token\s*=\s*)"([^"]*)"(.*)$', re.M)


def generate() -> str:
    """URL-safe 32바이트(=43자) 무작위. secrets 모듈(암호학적 안전)."""
    return secrets.token_urlsafe(32)


def current_token() -> str | None:
    if not CFG.exists():
        return None
    m = PAT.search(CFG.read_text(encoding="utf-8"))
    return m.group(2) if m else None


def write_token(tok: str) -> None:
    if not CFG.exists():
        if not EXAMPLE.exists():
            raise SystemExit("⛔ config.toml 도 config.example.toml 도 없습니다.")
        shutil.copy(EXAMPLE, CFG)
        print("config.example.toml → config.toml 새로 만듦")

    txt = CFG.read_text(encoding="utf-8")
    if not PAT.search(txt):
        raise SystemExit('⛔ config.toml 에서  access_token = "..."  줄을 못 찾음. 직접 확인하세요.')

    shutil.copy(CFG, BAK)                       # 되돌릴 수 있게 백업
    new = PAT.sub(lambda m: f'{m.group(1)}"{tok}"{m.group(3)}', txt, count=1)
    CFG.write_text(new, encoding="utf-8")

    # 쓰고 나서 TOML 이 여전히 유효한지 확인(깨졌으면 즉시 되돌림)
    try:
        import tomllib
        with open(CFG, "rb") as f:
            got = tomllib.load(f)["auth"]["access_token"]
        if got != tok:
            raise ValueError("기록된 값이 다름")
    except Exception as e:  # noqa: BLE001
        shutil.copy(BAK, CFG)
        raise SystemExit(f"⛔ config.toml 이 깨져서 백업으로 되돌림: {e}")


def main() -> int:
    args = sys.argv[1:]

    if "--show" in args:
        tok = current_token()
        if not tok:
            print("config.toml 이 없거나 access_token 줄이 없습니다. --write 로 만드세요.")
            return 1
        print("=== 현재 access_token (웹/앱 '보안키' 칸에 넣는 값) ===")
        print(tok)
        return 0

    tok = generate()

    if "--write" in args:
        old = current_token()
        write_token(tok)
        print("=== config.toml 의 access_token 을 새로 교체했습니다 ===")
        print(tok)
        print("-" * 55)
        print(f"  파일   : {CFG}")
        print(f"  백업   : {BAK}  (되돌리려면 이 파일을 config.toml 로 복사)")
        if old:
            print("  ⚠ 예전 토큰은 이제 안 통합니다 → 웹/앱의 보안키를 위 값으로 다시 넣으세요.")
        print("  ⚠ 서버가 켜져 있으면 재시작해야 새 토큰이 적용됩니다.")
        print("      (예: schtasks /End /TN KairosServer  후  schtasks /Run /TN KairosServer)")
        return 0

    print("=== 새 access_token (아직 파일에 안 씀) ===")
    print(tok)
    print("-" * 55)
    print("  config.toml 에 바로 넣으려면 :  python tools/gen_token.py --write")
    print("  직접 넣으려면 config.toml 의 [auth] 아래:")
    print(f'      access_token = "{tok}"')
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
