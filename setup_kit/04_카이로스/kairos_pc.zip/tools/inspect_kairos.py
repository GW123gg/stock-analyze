"""카이로스 주문창 구조 덤프 — 자동클릭 드라이버 작성을 위한 컨트롤 식별.

카이로스가 실행되고 주식 주문창이 열린 상태에서 실행:
    python tools/inspect_kairos.py           # '주문' 포함 창을 덤프
    python tools/inspect_kairos.py 카이로스   # 특정 제목 포함 창을 덤프

출력의 컨트롤(자동화ID/클래스/좌표/텍스트)을 그대로 복사해 주시면 그에 맞춰 KairosDriver 를 작성합니다.
컨트롤이 거의 안 나오면(=커스텀 렌더링) 고정좌표+이미지/OCR 방식으로 가야 함을 뜻합니다.
"""
import sys

try:
    from pywinauto import Desktop
except Exception:
    print("pywinauto 가 필요합니다:  pip install pywinauto")
    sys.exit(1)


def list_windows(backend: str):
    print(f"\n=== 최상위 창 목록 (backend={backend}) ===")
    found = []
    try:
        for w in Desktop(backend=backend).windows():
            try:
                t = (w.window_text() or "").strip()
                if t:
                    print(f"  [{w.class_name():<24}] {t!r}")
                    found.append(w)
            except Exception:
                pass
    except Exception as ex:
        print("  (목록 실패)", ex)
    return found


def dump(backend: str, key: str):
    print(f"\n=== '{key}' 포함 창 컨트롤 트리 (backend={backend}) ===")
    try:
        for w in Desktop(backend=backend).windows():
            try:
                if key in (w.window_text() or ""):
                    print(f"\n----- {w.window_text()!r} -----")
                    w.print_control_identifiers(depth=5)
            except Exception as ex:
                print("  (덤프 실패)", ex)
    except Exception as ex:
        print("  (덤프 실패)", ex)


if __name__ == "__main__":
    key = sys.argv[1] if len(sys.argv) > 1 else "주문"
    # uia 백엔드가 보통 더 많은 정보를 준다. win32 도 같이 시도.
    list_windows("uia")
    dump("uia", key)
    list_windows("win32")
    dump("win32", key)
    print("\n완료. 위 출력을 복사해 주세요(계좌번호 등 민감정보는 가려도 됩니다).")
