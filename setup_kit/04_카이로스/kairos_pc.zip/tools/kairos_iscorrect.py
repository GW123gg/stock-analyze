"""카이로스 자동 로그인 (피코 HID + Windows 자격증명 관리자).

보안 원칙:
  - 비밀번호는 Windows 자격증명 관리자(keyring, DPAPI 암호화)에만 저장.
    파일/코드/명령인자 어디에도 평문으로 두지 않는다.
  - setup 에서 사용자가 직접 입력(getpass, 화면 미표시)해 저장한다.
  - login 은 keyring 에서 값을 읽어 '피코가' 타이핑한다. 값을 절대 출력/로그하지 않는다.
  - 거래비밀번호(주문 확정)와 실제 매수/매도는 이 스크립트가 다루지 않는다(사람 몫).

명령:
  python tools/kairos_iscorrect.py setup            # 최초 1회: 비번 저장
  python tools/kairos_iscorrect.py status           # 카이로스 창 상태(힌트) 출력
  python tools/kairos_iscorrect.py launch           # 카이로스 실행
  python tools/kairos_iscorrect.py kill             # 카이로스 프로세스 종료
  python tools/kairos_iscorrect.py restart          # 종료 후 재실행(켜져있으면)
  python tools/kairos_iscorrect.py check            # (설정 시) 픽셀로 로그인화면 여부 추정
  python tools/kairos_iscorrect.py login [--dry-run]  # 로그인 스텝 실행(--dry-run: 계획만)

전제: 화면 배율 100%, 카이로스가 맨 앞 창. 좌표는 kairos_login_coords.json 에 채운다.
"""
from __future__ import annotations

import ctypes
import json
import subprocess
import sys
import time
from pathlib import Path

# 콘솔 인코딩(cp949 등)에서 표현 불가한 문자가 있어도 크래시하지 않도록.
try:
    sys.stdout.reconfigure(errors="replace")
    sys.stderr.reconfigure(errors="replace")
except Exception:
    pass

BASE = Path(r"C:\Users\USER\Desktop\mirae asset securities auto")
sys.path.insert(0, str(BASE))

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

from server.hid_serial import PicoHID, find_pico_port  # noqa: E402

SERVICE = "mirae_kairos"
CFG = BASE / "kairos_login_coords.json"

# ---- 마우스 가속 제어(절대이동 정확도) ----
_u = ctypes.windll.user32
SPI_GETMOUSE, SPI_SETMOUSE = 0x0003, 0x0004
SPI_GETMOUSESPEED, SPI_SETMOUSESPEED = 0x0070, 0x0071


def _accel_off_save():
    a = (ctypes.c_int * 3)()
    _u.SystemParametersInfoW(SPI_GETMOUSE, 0, a, 0)
    s = ctypes.c_int()
    _u.SystemParametersInfoW(SPI_GETMOUSESPEED, 0, ctypes.byref(s), 0)
    _u.SystemParametersInfoW(SPI_SETMOUSE, 0, (ctypes.c_int * 3)(0, 0, 0), 0)
    _u.SystemParametersInfoW(SPI_SETMOUSESPEED, 0, ctypes.c_void_p(10), 0)
    return a, s


def _accel_restore(saved):
    a, s = saved
    _u.SystemParametersInfoW(SPI_SETMOUSE, 0, a, 0)
    _u.SystemParametersInfoW(SPI_SETMOUSESPEED, 0, ctypes.c_void_p(s.value), 0)


def _load_cfg() -> dict:
    if not CFG.exists():
        raise SystemExit(f"설정 없음: {CFG}\n먼저 좌표 템플릿을 채우세요.")
    return json.loads(CFG.read_text(encoding="utf-8"))


def _keyring():
    try:
        import keyring
        return keyring
    except Exception as e:  # noqa: BLE001
        raise SystemExit(f"keyring 미설치: {e}\n  pip install keyring")


def _set_clipboard(text: str) -> None:
    import pyperclip
    pyperclip.copy(text)


def _clear_clipboard() -> None:
    try:
        import pyperclip
        pyperclip.copy("")
    except Exception:
        pass


# ---------------- 명령들 ----------------
def cmd_setup() -> int:
    import getpass
    kr = _keyring()
    print("== 카이로스 로그인 비밀번호 저장 (Windows 자격증명 관리자) ==")
    print("아이디는 카이로스가 자동저장하므로 비번만 저장합니다.")
    print("입력값은 화면에 표시되지 않으며, 파일/코드에 저장되지 않습니다.\n")
    pw1 = getpass.getpass("로그인 비밀번호: ")
    pw2 = getpass.getpass("로그인 비밀번호 확인: ")
    if pw1 != pw2:
        print("⛔ 비밀번호 불일치 - 저장 취소")
        return 1
    if pw1:
        kr.set_password(SERVICE, "kairos_pw", pw1)
    cert = getpass.getpass("공동인증서 비번(없으면 그냥 엔터): ")
    if cert:
        kr.set_password(SERVICE, "kairos_cert_pw", cert)
    print("\n✅ 저장 완료. (값은 keyring 에만 있음)")
    print("   삭제하려면: python -c \"import keyring;[keyring.delete_password('%s',n) "
          "for n in ('kairos_id','kairos_pw','kairos_cert_pw')]\"" % SERVICE)
    return 0


def _kairos_windows():
    """카이로스 관련 (제목, w, h, left, top, visible) 목록."""
    import pygetwindow as gw
    hits = []
    for w in gw.getAllWindows():
        t = (w.title or "")
        if any(k in t for k in ("미래에셋", "카이로스", "Kairos", "KAIROS")):
            hits.append((t, w.width, w.height, w.left, w.top,
                         bool(getattr(w, "visible", True))))
    return hits


def cmd_status() -> int:
    try:
        hits = _kairos_windows()
    except Exception as e:  # noqa: BLE001
        print(f"pygetwindow missing: {e}")
        print("RESULT: UNKNOWN")
        return 1
    if not hits:
        print("STATE: no Kairos window")
    else:
        print(f"STATE: {len(hits)} Kairos window(s)")
        for t, wd, ht, l, tp, vis in hits:
            print(f"  - '{t}' {wd}x{ht} @({l},{tp}) visible={vis}")
    # 기계 판독용(ASCII). 코워크는 이 RESULT 줄로 판정(스크린샷 불필요).
    #  - 큰 창(메인 HTS)이 있으면 LOGGED_IN, 작은 창만 있으면 로그인/기동중, 없으면 NO_WINDOW.
    big = [h for h in hits if h[5] and h[1] >= 1000 and h[2] >= 700]
    if not hits:
        print("RESULT: NO_WINDOW")
    elif big:
        print("RESULT: LOGGED_IN")
    else:
        print("RESULT: LOGIN_OR_STARTING")
    return 0


def cmd_windows() -> int:
    """모든 보이는 최상위 창을 덤프(팝업/로그인창 구조 파악용). 캘리브레이션 도구."""
    try:
        import pygetwindow as gw
    except Exception as e:  # noqa: BLE001
        print(f"pygetwindow missing: {e}")
        return 1
    n = 0
    for w in gw.getAllWindows():
        t = (w.title or "").strip()
        if not t or not bool(getattr(w, "visible", True)):
            continue
        if w.width <= 0 or w.height <= 0:
            continue
        n += 1
        print(f"  [{n}] '{t}' {w.width}x{w.height} @({w.left},{w.top})")
    print(f"TOTAL_VISIBLE: {n}")
    return 0


def cmd_launch() -> int:
    cfg = _load_cfg()
    # kairos.exe 는 관리자권한 필요 → 예약작업(KairosLaunch)로 UAC 없이 실행.
    task = cfg.get("launch_task", "")
    if task:
        r = subprocess.run(["schtasks", "/Run", "/TN", task],
                           capture_output=True, text=True, errors="ignore")
        if r.returncode == 0:
            print(f"카이로스 실행 요청됨(예약작업 '{task}').")
            print("로그인창 뜰 때까지 대기(스크린샷으로 확인).")
            return 0
        print(f"⛔ 예약작업 실행 실패: {task}\n{(r.stdout or '')}{(r.stderr or '')}".strip())
        print("   → 관리자 PowerShell에서 cowork/setup_task.ps1 을 먼저 실행했는지 확인하세요.")
        return 1
    # 폴백: 관리자 권한이 필요 없을 때만 직접 실행(작업폴더 지정).
    path = cfg.get("launch_path", "")
    if not path or not Path(path).exists():
        print(f"⛔ launch_path 없음/잘못됨: {path!r}  (kairos_login_coords.json 에서 수정)")
        return 1
    subprocess.Popen([path], cwd=str(Path(path).parent))
    print(f"카이로스 실행: {path}")
    print("로그인창 뜰 때까지 대기(스크린샷으로 확인).")
    return 0


def _kairos_pids():
    """이미지명에 kairos/miraeasset 이 든 프로세스 (name, pid) 목록."""
    import csv
    import io
    out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"],
                         capture_output=True, text=True, errors="ignore").stdout
    hits = []
    for row in csv.reader(io.StringIO(out)):
        if len(row) < 2:
            continue
        name, pid = row[0], row[1]
        low = name.lower()
        if ("kairos" in low or "miraeasset" in low) and pid.isdigit():
            hits.append((name, pid))
    return hits


def _wait_gone(timeout: int = 15) -> int:
    """카이로스 프로세스가 사라질 때까지 대기. 남은 개수 반환."""
    for _ in range(timeout):
        if not _kairos_pids():
            return 0
        time.sleep(1)
    return len(_kairos_pids())


def cmd_kill() -> int:
    cfg = _load_cfg()
    if not _kairos_pids():
        print("종료 대상 없음 (카이로스 미실행)")
        return 0
    # 카이로스는 관리자 권한으로 실행됨 → 일반 권한 taskkill 불가.
    # 관리자 예약작업(KairosKill)으로 종료.
    task = cfg.get("kill_task", "")
    if task:
        r = subprocess.run(["schtasks", "/Run", "/TN", task],
                           capture_output=True, text=True, errors="ignore")
        if r.returncode != 0:
            print(f"⛔ 종료 작업 실행 실패: {task}\n{(r.stdout or '')}{(r.stderr or '')}".strip())
            print("   → 관리자 PowerShell에서 cowork/setup_task.ps1 을 실행했는지 확인.")
            return 1
        remain = _wait_gone()
        if remain:
            print(f"⚠️ 종료 요청했으나 {remain}개 남음 (작업 권한/이미지명 확인 필요)")
            return 1
        print(f"종료 완료(예약작업 '{task}').")
        return 0
    # 폴백: 직접 taskkill (관리자 권한이 아닐 때만 유효)
    for name, pid in _kairos_pids():
        subprocess.run(["taskkill", "/F", "/PID", pid],
                       capture_output=True, text=True, errors="ignore")
    remain = _wait_gone(3)
    if remain:
        print(f"⚠️ {remain}개 남음 - 관리자 권한 필요(kill_task 설정 권장).")
        return 1
    print("종료 완료(직접 taskkill).")
    return 0


def _run_steps_pico(steps) -> None:
    """Pico 연결해 스텝 실행(로그인/종료 공용)."""
    saved = _accel_off_save()
    pico = PicoHID(find_pico_port())
    try:
        pico.connect()
        print("피코 연결됨 - 스텝 실행")
        _run_steps(steps, pico, dry=False)
    finally:
        try:
            pico.close()
        except Exception:
            pass
        _accel_restore(saved)


def cmd_close() -> int:
    """UI 종료 버튼→확인 팝업(Pico)으로 카이로스 정상 종료. shutdown_steps 좌표 필요.
    ※ 로그인된 메인 HTS 상태에서만 좌표가 맞음(로그인창 상태에서 호출 금지)."""
    cfg = _load_cfg()
    if not _kairos_pids():
        print("이미 종료됨 (카이로스 미실행)")
        return 0
    steps = cfg.get("shutdown_steps", [])
    if not steps:
        print("⛔ shutdown_steps 미설정 (kairos_login_coords.json)")
        return 1
    _run_steps_pico(steps)   # [0,0] 미보정이면 _run_steps 가 SystemExit
    remain = _wait_gone(8)
    if remain:
        print(f"⚠️ 종료 스텝 실행했으나 {remain}개 남음 (좌표/팝업 확인 필요)")
        return 1
    print("✅ 정상 종료 완료")
    return 0


def cmd_restart() -> int:
    """상태 기반 재시작:
      - 로그인됨(큰 HTS 창) → 정상종료(UI, shutdown_steps) 후 재실행. 실패 시 KairosKill 폴백.
      - 로그인창/기동중(작은 창)     → 닫을 필요 없음(이미 로그인창). 그대로 둠.
      - 꺼짐(창 없음)               → 실행."""
    cfg = _load_cfg()
    try:
        hits = _kairos_windows()
    except Exception:
        hits = []
    big = [h for h in hits if h[5] and h[1] >= 1000 and h[2] >= 700]
    if big:
        # ★ 카이로스는 보안모듈(AhnLab/nProtect)이 taskkill(관리자 포함)을 차단 → 강제종료 불가.
        #   오직 UI 종료(shutdown_steps, Pico)로만 닫힘. 좌표 미보정이면 닫을 수 없으니 안내 후 중단.
        print("상태: 로그인됨(접속끊김 팝업 등)")
        steps = cfg.get("shutdown_steps", [])
        calibrated = bool(steps) and all(
            list(s.get("xy", [0, 0])) != [0, 0]
            for s in steps if s.get("action") in ("click", "move"))
        if not calibrated:
            print("⛔ 이미 실행 중인데 UI 종료좌표(shutdown_steps) 미보정입니다.")
            print("   카이로스는 강제종료(taskkill)가 보안모듈에 막혀 불가 → UI 종료 좌표 보정 필요.")
            print("   또는 밤에 카이로스를 직접 종료해두면 새벽엔 launch→login 만 하면 됩니다.")
            return 1
        try:
            if cmd_close() != 0:
                print("⛔ UI 종료 실패 - 수동 확인 필요")
                return 1
        except SystemExit as e:
            print(f"종료 스텝 문제: {e}")
            return 1
        if _wait_gone(10):
            print("⛔ 종료 확인 실패 - 재실행 중단")
            return 1
        time.sleep(1)
        return cmd_launch()
    if hits:
        print("상태: 로그인창/기동중 → 종료 불필요, 그대로 로그인 진행 가능")
        return 0
    print("상태: 꺼짐 → 실행")
    return cmd_launch()


def cmd_check() -> int:
    """설정된 픽셀 시그니처로 '로그인 화면' 여부 추정(코워크 눈이 없을 때 폴백)."""
    cfg = _load_cfg()
    sig = cfg.get("login_pixel")
    if not sig:
        print("UNKNOWN: login_pixel 미설정 - 스크린샷으로 판정하세요.")
        return 0
    import mss
    x, y = sig["xy"]
    want = tuple(sig["rgb"])
    tol = int(sig.get("tol", 30))
    with mss.mss() as sct:
        px = sct.grab({"left": x, "top": y, "width": 1, "height": 1}).pixel(0, 0)
    close = all(abs(a - b) <= tol for a, b in zip(px, want))
    print(f"pixel@({x},{y})={px} want={want} tol={tol} → "
          + ("LOGIN_SCREEN" if close else "NOT_LOGIN_SCREEN"))
    return 0


def _run_steps(steps, pico, dry: bool) -> None:
    kr = None
    # 미완성 좌표 가드
    for i, s in enumerate(steps):
        if s["action"] in ("click", "move") and list(s.get("xy", [0, 0])) == [0, 0]:
            raise SystemExit(f"⛔ 스텝 {i} 좌표가 [0,0] (미캘리브레이션). "
                             f"pico_ui.py 로 좌표 확인 후 kairos_login_coords.json 채우세요.")
    for i, s in enumerate(steps):
        act = s["action"]
        note = s.get("note", "")
        if act in ("click", "move"):
            x, y = s["xy"]
            print(f"[{i}] {act} ({x},{y}) {note}")
            if not dry:
                pico.move_abs(x, y)
                time.sleep(0.35)
                if act == "click":
                    pico.click()
                    time.sleep(0.4)
        elif act == "type":
            print(f"[{i}] type '{s['text']}' {note}")
            if not dry:
                pico.type_text(s["text"])
                time.sleep(0.3)
        elif act in ("type_secret", "cleartype_secret"):
            if kr is None:
                kr = _keyring()
            val = kr.get_password(SERVICE, s["name"])
            if val is None:
                raise SystemExit(f"⛔ keyring 에 '{s['name']}' 없음 - setup 먼저 실행")
            cmin = float(s.get("char_min", 0.3))
            cmax = float(s.get("char_max", 0.5))
            pre = float(s.get("pre_delay", 0.0))
            print(f"[{i}] {act} <{s['name']}> [값 숨김] "
                  f"글자당 {cmin}~{cmax}s, 선대기 {pre}s {note}")
            if not dry:
                if pre:
                    time.sleep(pre)
                if act == "cleartype_secret":
                    pico.key("CLEAR")
                    time.sleep(0.15)
                pico.type_slow(val, cmin, cmax)   # 한 글자씩 랜덤 딜레이
                del val
                time.sleep(0.3)
        elif act == "paste_secret":
            if kr is None:
                kr = _keyring()
            val = kr.get_password(SERVICE, s["name"])
            if val is None:
                raise SystemExit(f"⛔ keyring 에 '{s['name']}' 없음 - setup 먼저 실행")
            pre = float(s.get("pre_delay", 0.0))
            overwrite = bool(s.get("overwrite", True))
            print(f"[{i}] paste_secret <{s['name']}> [값 숨김] "
                  f"클립보드→Ctrl+V, overwrite={overwrite} {note}")
            if not dry:
                try:
                    if pre:
                        time.sleep(pre)
                    _set_clipboard(val)
                    time.sleep(0.2)
                    if overwrite:
                        pico.select_all()   # 기존값 있으면 선택 → 붙여넣기로 덮어씀
                        time.sleep(0.15)
                    pico.paste()
                    time.sleep(0.3)
                finally:
                    _clear_clipboard()      # 비번을 클립보드에서 즉시 제거
                    del val
        elif act == "key":
            print(f"[{i}] key {s['key']} {note}")
            if not dry:
                pico.key(s["key"])
                time.sleep(0.2)
        elif act == "wait":
            print(f"[{i}] wait {s['sec']}s {note}")
            if not dry:
                time.sleep(float(s["sec"]))
        else:
            raise SystemExit(f"⛔ 알 수 없는 action: {act}")


def cmd_login(dry: bool) -> int:
    cfg = _load_cfg()
    steps = cfg.get("steps", [])
    if not steps:
        print("⛔ steps 비어있음"); return 1
    if dry:
        print("== DRY-RUN (실제 입력 안 함) ==")
        _run_steps(steps, None, dry=True)
        print("== 계획 확인 완료 ==")
        return 0
    saved = _accel_off_save()
    pico = PicoHID(find_pico_port())
    try:
        pico.connect()
        print("피코 연결됨 - 로그인 스텝 실행")
        _run_steps(steps, pico, dry=False)
        print("✅ 로그인 스텝 완료 - 스크린샷으로 성공 확인 필요")
    finally:
        try:
            pico.close()
        except Exception:
            pass
        _accel_restore(saved)
    return 0


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 2
    cmd = args[0]
    if cmd == "setup":
        return cmd_setup()
    if cmd == "status":
        return cmd_status()
    if cmd == "launch":
        return cmd_launch()
    if cmd == "kill":
        return cmd_kill()
    if cmd == "restart":
        return cmd_restart()
    if cmd == "close":
        return cmd_close()
    if cmd == "windows":
        return cmd_windows()
    if cmd == "check":
        return cmd_check()
    if cmd == "login":
        return cmd_login(dry="--dry-run" in args)
    print(f"알 수 없는 명령: {cmd}")
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
