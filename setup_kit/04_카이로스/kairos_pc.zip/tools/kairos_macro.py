"""카이로스 주문입력 매크로 (피코 HID).

동작:
  ① 한 칸 테스트 — 매수탭/매도탭/종목/수량/단가 중 하나만 이동+클릭해서 좌표가 맞는지 확인
  ② 전체 실행   — 탭선택 → 종목 → 수량 → 단가 를 순서대로 입력하고 '멈춤'

안전 원칙(절대 안 바뀜):
  - 매크로는 '매수/매도 주문버튼'을 누르지 않는다. 값 확인 후 사람이 직접 누른다.
  - 예수금/보유수량을 입력하면: 매수금액 > 예수금(미수) 또는 매도수량 > 보유수량(과매도) 이면 실행을 '차단'한다.
  - 거래비밀번호/공동인증서는 이 도구로 절대 자동입력하지 않는다.

원리(pico_ui 와 동일, 검증됨):
  - 마우스 이동/클릭/키보드 모두 피코(실물 USB HID)가 수행 → 안랩/nProtect 통과.
  - 이동은 피코 절대이동(A:) → 정확도 위해 마우스 가속을 끔(창 닫을 때 원복).
  - 첫 클릭이 카이로스를 포커스시키므로 이후 타이핑이 카이로스로 들어감.

실행: python tools/kairos_macro.py
"""
import ctypes
import json
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

BASE = Path(r"C:\Users\USER\Desktop\mirae asset securities auto")
sys.path.insert(0, str(BASE))

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

from server.hid_serial import PicoHID, find_pico_port  # noqa: E402

COORDS = json.loads((BASE / "kairos_coords.json").read_text(encoding="utf-8"))

# 미수 방지 여유(수수료+슬리피지 버퍼). 매수필요금액 = 수량*단가*(1+BUFFER)
FEE_BUFFER = 0.001

# ---- 마우스 가속 제어(절대이동 정확도) ----
_u = ctypes.windll.user32
SPI_GETMOUSE, SPI_SETMOUSE = 0x0003, 0x0004
SPI_GETMOUSESPEED, SPI_SETMOUSESPEED = 0x0070, 0x0071
_orig_accel = (ctypes.c_int * 3)()
_u.SystemParametersInfoW(SPI_GETMOUSE, 0, _orig_accel, 0)
_orig_speed = ctypes.c_int()
_u.SystemParametersInfoW(SPI_GETMOUSESPEED, 0, ctypes.byref(_orig_speed), 0)


def accel_off():
    _u.SystemParametersInfoW(SPI_SETMOUSE, 0, (ctypes.c_int * 3)(0, 0, 0), 0)
    _u.SystemParametersInfoW(SPI_SETMOUSESPEED, 0, ctypes.c_void_p(10), 0)


def accel_restore():
    _u.SystemParametersInfoW(SPI_SETMOUSE, 0, _orig_accel, 0)
    _u.SystemParametersInfoW(SPI_SETMOUSESPEED, 0, ctypes.c_void_p(_orig_speed.value), 0)


# ---- 피코 연결 ----
pico = PicoHID(find_pico_port())
try:
    pico.connect()
    CONN = f"피코 연결됨 ({pico.port})"
    CONN_OK = True
except Exception as e:  # noqa: BLE001
    CONN = f"피코 연결 실패: {e}"
    CONN_OK = False

accel_off()

# ---------------- UI ----------------
root = tk.Tk()
root.title("카이로스 주문입력 매크로 (피코)")
root.attributes("-topmost", True)
root.geometry("380x640+40+40")

side_var = tk.StringVar(value="매수")
symbol_var = tk.StringVar()
qty_var = tk.StringVar()
price_var = tk.StringVar()
cash_var = tk.StringVar()      # 예수금(선택)
hold_var = tk.StringVar()      # 보유수량(선택)
delay_step = tk.StringVar(value="0.6")
offset_var = tk.StringVar(value="0")
delay_focus = tk.BooleanVar(value=True)
status_var = tk.StringVar(value=CONN)
busy = {"v": False}


def set_status(msg, color="#008800"):
    status_var.set(msg)
    status_lbl.config(fg=color)


# ---- 저수준: 이동+클릭 / 입력 (모두 피코) ----
def _click_field(key):
    x, y = COORDS[key]
    off = int(offset_var.get() or 0)
    pico.move_abs(x, y + off)
    time.sleep(0.35)
    pico.click()
    time.sleep(0.4)


def _type_field(key, value):
    _click_field(key)
    pico.clear_and_type(str(value))
    time.sleep(0.4)


def run_after_delay(fn, desc, remaining=None):
    """2초 카운트다운(포커스용) 후 별도 스레드에서 fn 실행."""
    if remaining is None:
        if busy["v"]:
            return
        busy["v"] = True
        remaining = 2 if delay_focus.get() else 0
    if remaining > 0:
        set_status(f"[{desc}] {remaining}초 후 실행 — 지금 카이로스를 클릭!", "#cc5500")
        root.after(1000, lambda: run_after_delay(fn, desc, remaining - 1))
        return

    def worker():
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            root.after(0, lambda: set_status(f"[{desc}] 오류: {e}", "#cc0000"))
        finally:
            busy["v"] = False

    threading.Thread(target=worker, daemon=True).start()


# ---- ① 한 칸 테스트 ----
def test_one(key, label):
    if not CONN_OK:
        set_status("피코 미연결", "#cc0000"); return

    def f():
        root.after(0, lambda: set_status(f"[테스트] {label} 클릭", "#0055cc"))
        _click_field(key)
        root.after(0, lambda: set_status(f"[테스트] {label} 클릭함 — 커서가 맞는 칸에 있나 확인", "#0055cc"))

    run_after_delay(f, f"테스트:{label}")


# ---- 입력값 검증 + 안전검사 ----
def _validate():
    sym = symbol_var.get().strip()
    if not (sym.isdigit() and len(sym) == 6):
        return None, "종목코드는 숫자 6자리"
    try:
        qty = int(qty_var.get().replace(",", ""))
        price = int(price_var.get().replace(",", ""))
    except ValueError:
        return None, "수량·단가는 숫자"
    if qty <= 0 or price <= 0:
        return None, "수량·단가는 0보다 커야 함"
    side = side_var.get()

    # 안전검사(입력 시에만)
    cash_s, hold_s = cash_var.get().strip(), hold_var.get().strip()
    if side == "매수" and cash_s:
        cash = int(cash_s.replace(",", ""))
        need = qty * price * (1 + FEE_BUFFER)
        if need > cash:
            return None, (f"⛔ 미수 위험: 필요 {need:,.0f}원 > 예수금 {cash:,}원\n"
                          f"매수가능 수량 ≈ {int(cash // (price * (1 + FEE_BUFFER))):,}주")
    if side == "매도" and hold_s:
        hold = int(hold_s.replace(",", ""))
        if qty > hold:
            return None, f"⛔ 과매도/공매도: 매도 {qty:,} > 보유 {hold:,}주"
    return (side, sym, qty, price), None


# ---- ② 전체 실행 ----
def run_all():
    if not CONN_OK:
        set_status("피코 미연결", "#cc0000"); return
    parsed, err = _validate()
    if err:
        messagebox.showwarning("확인/차단", err)
        set_status(err.split(chr(10))[0], "#cc0000")
        return
    side, sym, qty, price = parsed
    tab_key = "tab_sell" if side == "매도" else "tab_buy"

    def f():
        steps = [
            (f"{side}탭", lambda: _click_field(tab_key)),
            ("종목", lambda: _type_field("field_symbol", sym)),
            ("수량", lambda: _type_field("field_qty", qty)),
            ("단가", lambda: _type_field("field_price", price)),
        ]
        gap = float(delay_step.get() or 0.6)
        for label, act in steps:
            root.after(0, lambda l=label: set_status(f"입력 중… {l}", "#0055cc"))
            act()
            time.sleep(gap)
        root.after(0, lambda: set_status(
            f"✅ 입력 완료: {side} {sym} {qty}주 @ {price}\n"
            f"값 확인 후 '직접' 주문버튼을 누르세요 (매크로는 안 누름)", "#008800"))

    run_after_delay(f, f"{side} 주문입력")


# ---------------- 위젯 ----------------
pad = {"padx": 8, "pady": 3}

tk.Label(root, text="주문구분").pack(anchor="w", padx=8, pady=(8, 0))
fr_side = tk.Frame(root); fr_side.pack(anchor="w", padx=8)
tk.Radiobutton(fr_side, text="매수", variable=side_var, value="매수").grid(row=0, column=0)
tk.Radiobutton(fr_side, text="매도", variable=side_var, value="매도").grid(row=0, column=1)

fr = tk.Frame(root); fr.pack(anchor="w", **pad)
tk.Label(fr, text="종목코드").grid(row=0, column=0, sticky="w")
tk.Entry(fr, textvariable=symbol_var, width=12).grid(row=0, column=1, padx=4)
tk.Label(fr, text="수량").grid(row=1, column=0, sticky="w")
tk.Entry(fr, textvariable=qty_var, width=12).grid(row=1, column=1, padx=4)
tk.Label(fr, text="단가(호가)").grid(row=2, column=0, sticky="w")
tk.Entry(fr, textvariable=price_var, width=12).grid(row=2, column=1, padx=4)

tk.Label(root, text="── 안전검사(선택, 비우면 생략) ──", fg="#444").pack(pady=(6, 0))
fr_s = tk.Frame(root); fr_s.pack(anchor="w", padx=8)
tk.Label(fr_s, text="예수금").grid(row=0, column=0, sticky="w")
tk.Entry(fr_s, textvariable=cash_var, width=12).grid(row=0, column=1, padx=4)
tk.Label(fr_s, text="보유수량").grid(row=1, column=0, sticky="w")
tk.Entry(fr_s, textvariable=hold_var, width=12).grid(row=1, column=1, padx=4)

tk.Label(root, text="── ① 한 칸 테스트(좌표 확인) ──", fg="#444").pack(pady=(8, 0))
fr_t = tk.Frame(root); fr_t.pack(padx=8)
tk.Button(fr_t, text="매수탭", width=6, command=lambda: test_one("tab_buy", "매수탭")).grid(row=0, column=0, padx=2)
tk.Button(fr_t, text="매도탭", width=6, command=lambda: test_one("tab_sell", "매도탭")).grid(row=0, column=1, padx=2)
tk.Button(fr_t, text="종목", width=6, command=lambda: test_one("field_symbol", "종목")).grid(row=0, column=2, padx=2)
fr_t2 = tk.Frame(root); fr_t2.pack(padx=8, pady=2)
tk.Button(fr_t2, text="수량", width=6, command=lambda: test_one("field_qty", "수량")).grid(row=0, column=0, padx=2)
tk.Button(fr_t2, text="단가", width=6, command=lambda: test_one("field_price", "단가")).grid(row=0, column=1, padx=2)

fr_o = tk.Frame(root); fr_o.pack(pady=(6, 0))
tk.Label(fr_o, text="스텝지연(초)").grid(row=0, column=0)
tk.Entry(fr_o, textvariable=delay_step, width=5).grid(row=0, column=1, padx=3)
tk.Label(fr_o, text="Y보정px").grid(row=0, column=2)
tk.Entry(fr_o, textvariable=offset_var, width=5).grid(row=0, column=3, padx=3)
tk.Checkbutton(root, text="2초 지연 후 실행(누른 뒤 카이로스 클릭)", variable=delay_focus).pack()

tk.Label(root, text="── ② 전체 주문입력 실행 ──", fg="#444").pack(pady=(8, 0))
tk.Button(root, text="주문입력 실행 (버튼은 안 누름)", width=32,
          height=2, bg="#e8f0ff", command=run_all).pack(pady=4)

tk.Label(root, text="⚠ 실행 후 값 직접 확인 → 매수/매도 버튼은 사람이 누름",
         fg="#0055cc", wraplength=350).pack(pady=(6, 2))
status_lbl = tk.Label(root, textvariable=status_var, fg="#008800", wraplength=350, justify="left")
status_lbl.pack(pady=4)


def on_close():
    accel_restore()
    try:
        pico.close()
    except Exception:
        pass
    root.destroy()


root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()
