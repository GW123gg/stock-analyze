"""호가창 캡쳐 영역 좌표 찾기.

실행: python tools/pick_region.py
카이로스 호가창의 '좌상단'과 '우하단'에 마우스를 올려 좌표(x, y)를 읽고,
  width  = 우하단.x - 좌상단.x
  height = 우하단.y - 좌상단.y
로 계산해 config.toml 의 [capture] 에 채우세요.
"""
import time
from ctypes import windll, byref
from ctypes import wintypes


def cursor_pos() -> tuple[int, int]:
    pt = wintypes.POINT()
    windll.user32.GetCursorPos(byref(pt))
    return pt.x, pt.y


if __name__ == "__main__":
    print("15초간 커서 위치를 출력합니다. 호가창의 좌상단/우하단에 마우스를 올려보세요.")
    print("(Ctrl+C 로 중단)")
    try:
        for _ in range(150):
            x, y = cursor_pos()
            print(f"  x={x:>5}  y={y:>5}   ", end="\r", flush=True)
            time.sleep(0.1)
    except KeyboardInterrupt:
        pass
    print("\n완료.")
