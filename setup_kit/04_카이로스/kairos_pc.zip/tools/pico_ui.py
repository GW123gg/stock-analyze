"""피코 수동 컨트롤 UI (항상 위, 2초 지연).

마우스 이동·클릭·키보드 입력을 모두 라즈베리파이 피코(HID)로 실행한다.
버튼을 누르면 2초 카운트다운 → 그 사이 '카이로스 창을 클릭'해 포커스를 주면,
2초 뒤 피코가 신호를 적용(카이로스에 적용됨).

- 이동 = 피코 절대이동(A:) → 정확도 위해 마우스 가속을 끔(창 닫을 때 원복).
- 창은 항상 위(topmost). 작으니 구석에 두면 카이로스에 커서/클릭이 닿음.
- 좌표 찾기: 카이로스 필드에 마우스를 올리면 상단에 '현재 커서 (x,y)'가 뜸.

실행: python tools/pico_ui.py
"""
import ctypes
import sys
import threading
import time
import tkinter as tk
from ctypes import wintypes

sys.path.insert(0, r"C:\Users\USER\Desktop\mirae asset securities auto")

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

from server.hid_serial import PicoHID, find_pico_port

DELAY_SEC = 2
_u = ctypes.windll.user32
SPI_GETMOUSE, SPI_SETMOUSE = 0x0003, 0x0004
SPI_GETMOUSESPEED, SPI_SETMOUSESPEED = 0x0070, 0x0071

_orig_accel = (ctypes.c_int * 3)()
_u.SystemParametersInfoW(SPI_GETMOUSE, 0, _orig_accel, 0)
_orig_speed = ctypes.c_int()
_u.SystemParametersInfoW(SPI_GETMOUSESPEED, 0, ctypes.byref(_orig_speed), 0)


def accel_off():
    _u.SystemParametersInfoW(SPI_SETMOUSE, 0, (ctypes.c_int * 3)(0, 0, 0), 0)
    _u.SystemParametersInfoW(SPI_SETMOUSESPEED, 0, ctypes.c_void_p(10), 0)


def accel_restore():
    _u.SystemParametersInfoW(SPI_SETMOUSE, 0, _orig_accel, 0)
    _u.SystemParametersInfoW(SPI_SETMOUSESPEED, 0, ctypes.c_void_p(_orig_speed.value), 0)


def get_cursor():
    p = wintypes.POINT()
    _u.GetCursorPos(ctypes.byref(p))
    return p.x, p.y


pico = PicoHID(find_pico_port())
try:
    pico.connect()
    conn = f"피코 연결됨 ({pico.port})"
except Exception as e:  # noqa: BLE001
    conn = f"피코 연결 실패: {e}"

accel_off()

root = tk.Tk()
root.title("Pico 카이로스 컨트롤")
root.attributes("-topmost", True)
root.geometry("340x460+40+40")

pos_var = tk.StringVar(value="현재 커서: -")
status_var = tk.StringVar(value=conn)
x_var = tk.StringVar()
y_var = tk.StringVar()
text_var = tk.StringVar()
delay_on = tk.BooleanVar(value=True)
busy = {"v": False}


def run_after_delay(fn, desc, remaining=None):
    if remaining is None:
        if busy["v"]:
            return
        busy["v"] = True
        remaining = DELAY_SEC if delay_on.get() else 0
    if remaining > 0:
        status_var.set(f"[{desc}] {remaining}초 후 — 지금 카이로스 클릭!")
        root.after(1000, lambda: run_after_delay(fn, desc, remaining - 1))
        return
    status_var.set(f"[{desc}] 실행 중...")

    def worker():
        try:
            fn()
            root.after(0, lambda: status_var.set(f"[{desc}] 완료"))
        except Exception as e:  # noqa: BLE001
            root.after(0, lambda: status_var.set(f"[{desc}] 오류: {e}"))
        finally:
            busy["v"] = False

    threading.Thread(target=worker, daemon=True).start()


def _xy():
    return int(x_var.get()), int(y_var.get())


def act_move():
    try:
        x, y = _xy()
    except ValueError:
        status_var.set("X,Y 숫자 입력"); return
    run_after_delay(lambda: pico.move_abs(x, y), f"이동 {x},{y}")


def act_move_click():
    try:
        x, y = _xy()
    except ValueError:
        status_var.set("X,Y 숫자 입력"); return

    def f():
        pico.move_abs(x, y)
        time.sleep(0.3)
        pico.click()

    run_after_delay(f, f"이동+클릭 {x},{y}")


def act_click():
    run_after_delay(pico.click, "클릭")


def act_type():
    t = text_var.get()
    run_after_delay(lambda: pico.type_text(t), f"타이핑 '{t}'")


def act_key(name):
    run_after_delay(lambda: pico.key(name), name)


tk.Label(root, textvariable=pos_var, fg="#333").pack(pady=5)
tk.Checkbutton(root, text="2초 지연(누른 뒤 카이로스 클릭)", variable=delay_on).pack()

tk.Label(root, text="── 마우스 ──").pack(pady=(6, 0))
fr = tk.Frame(root); fr.pack(pady=2)
tk.Label(fr, text="X").grid(row=0, column=0)
tk.Entry(fr, textvariable=x_var, width=7).grid(row=0, column=1, padx=3)
tk.Label(fr, text="Y").grid(row=0, column=2)
tk.Entry(fr, textvariable=y_var, width=7).grid(row=0, column=3, padx=3)
fr2 = tk.Frame(root); fr2.pack(pady=3)
tk.Button(fr2, text="이동", width=8, command=act_move).grid(row=0, column=0, padx=3)
tk.Button(fr2, text="이동+클릭", width=10, command=act_move_click).grid(row=0, column=1, padx=3)
tk.Button(root, text="클릭 (현재 위치)", width=22, command=act_click).pack(pady=2)

tk.Label(root, text="── 키보드 ──").pack(pady=(8, 0))
tk.Entry(root, textvariable=text_var, width=30).pack(pady=2)
tk.Button(root, text="타이핑", width=22, command=act_type).pack(pady=2)
fr3 = tk.Frame(root); fr3.pack(pady=3)
tk.Button(fr3, text="Enter", width=7, command=lambda: act_key("ENTER")).grid(row=0, column=0, padx=2)
tk.Button(fr3, text="Tab", width=7, command=lambda: act_key("TAB")).grid(row=0, column=1, padx=2)
tk.Button(fr3, text="Clear", width=7, command=lambda: act_key("CLEAR")).grid(row=0, column=2, padx=2)

tk.Label(root, text="버튼 → 2초 안에 카이로스 창을 클릭(포커스) → 피코가 적용",
         fg="#0055cc", wraplength=320).pack(pady=(8, 2))
tk.Label(root, textvariable=status_var, fg="#008800", wraplength=320).pack(pady=4)


def update_pos():
    try:
        x, y = get_cursor()
        pos_var.set(f"현재 커서: ({x}, {y})   ← 카이로스 필드에 올려 좌표 확인")
    except Exception:
        pass
    root.after(200, update_pos)


def on_close():
    accel_restore()
    try:
        pico.close()
    except Exception:
        pass
    root.destroy()


root.protocol("WM_DELETE_WINDOW", on_close)
update_pos()
root.mainloop()
