"""자동 입력이 카이로스에서 먹히는지 '사용자가 직접' 확인하는 테스트.

우리가 실제로 쓸 라이브러리(pyautogui)로, 포커스는 사용자가 직접 준다 → 좌표/포커스 논란 제거.

사용법:
    pip install pyautogui        # (아직이면)
    python tools/test_input.py
    → 콘솔이 카운트다운하는 5초 안에 '카이로스 [0611] 종목칸'을 마우스로 클릭해 포커스를 주세요.
    → (1) 타이핑, (2) 클립보드 Ctrl+V 를 차례로 시도합니다. 종목칸 변화만 눈으로 보면 됩니다.
"""
import subprocess
import time

try:
    import pyautogui
except Exception:
    raise SystemExit("먼저:  pip install pyautogui")


def set_clipboard(text: str) -> None:
    # 윈도우 기본 clip.exe 로 클립보드 설정 (추가 패키지 불필요)
    subprocess.run("clip", input=text, text=True, shell=True)


print("=" * 56)
print(" 카이로스 [0611] '종목칸'을 클릭해 포커스를 주세요.")
for i in range(5, 0, -1):
    print(f"   {i}초...", end="\r", flush=True)
    time.sleep(1)
print("\n")

print("[1] 합성 타이핑 시도 → 005930")
pyautogui.typewrite("005930", interval=0.05)
time.sleep(2)
print("    종목칸이 005930/삼성전자로 바뀌었나요?  (눈으로 확인)\n")

print("[2] 합성 Ctrl+V 시도 → 000660 (클립보드 경유)")
set_clipboard("000660")
time.sleep(0.3)
pyautogui.hotkey("ctrl", "a")
time.sleep(0.2)
pyautogui.hotkey("ctrl", "v")
time.sleep(2)
print("    종목칸이 000660/SK하이닉스로 바뀌었나요?\n")

print("=" * 56)
print(" 판정:")
print("  - 둘 다 안 바뀜  → 합성 키입력이 안랩에 막힘 → 아두이노(실물 키보드) 필요")
print("  - [1]이 바뀜     → 타이핑 OK → pyautogui 타이핑으로 드라이버 구현 가능")
print("  - [2]만 바뀜     → 붙여넣기 OK → 클립보드+Ctrl+V 로 드라이버 구현 가능")
print("=" * 56)
