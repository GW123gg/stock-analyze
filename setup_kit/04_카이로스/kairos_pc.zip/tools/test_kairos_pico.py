"""카이로스 '매도' 흐름 테스트 — Tab 이동 방식.

핵심: 클릭은 '매도 탭'과 '종목칸' 딱 2번만. 그다음은 Tab 키로 종목→수량→단가 이동.
      (수량·단가는 클릭하지 않으므로 좌표 오차 영향이 없음)

★★ 주문(매수/매도) 버튼은 절대 누르지 않음.
    호가는 클릭 안 하고 단가(노란칸)에 직접 타이핑.

준비: firmware/pico/code.py(마우스 버전) 피코에, kairos_coords.json(재캘리브레이션),
      디스플레이 배율 100% 권장, 카이로스 [0611] 앞에.
실행: python tools/test_kairos_pico.py
"""
import ctypes
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, r"C:\Users\USER\Desktop\mirae asset securities auto")

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

from server.hid_serial import PicoHID, find_pico_port

_user32 = ctypes.windll.user32


def set_cursor(x, y):
    _user32.SetCursorPos(int(x), int(y))


def bring_kairos_front():
    """카이로스 창을 진짜 '포커스' 상태로(AttachThreadInput 트릭). 가려져 있으면 입력이 안 닿음."""
    try:
        import pygetwindow as gw
        wins = [w for w in gw.getWindowsWithTitle("미래에셋증권")
                if w.width > 500 and w.height > 400]
        if not wins:
            print("  (카이로스 창을 못 찾음 — 제목 확인 필요)")
            return False
        hwnd = wins[0]._hWnd
        kernel32 = ctypes.windll.kernel32
        _user32.ShowWindow(hwnd, 9)   # SW_RESTORE
        fg = _user32.GetForegroundWindow()
        fg_thread = _user32.GetWindowThreadProcessId(fg, 0)
        cur_thread = kernel32.GetCurrentThreadId()
        _user32.AttachThreadInput(fg_thread, cur_thread, True)
        _user32.BringWindowToTop(hwnd)
        _user32.SetForegroundWindow(hwnd)
        _user32.AttachThreadInput(fg_thread, cur_thread, False)
        time.sleep(0.6)
        print("  카이로스를 앞으로(포커스)")
        return True
    except Exception as e:  # noqa: BLE001
        print("  카이로스 활성화 실패:", e, "→ 직접 앞으로 클릭해두세요")
        return False


ROOT = Path(__file__).resolve().parent.parent
coords_path = ROOT / "kairos_coords.json"
if not coords_path.exists():
    raise SystemExit("kairos_coords.json 없음 → 먼저 python tools/calibrate_kairos.py 실행")
COORDS = json.loads(coords_path.read_text(encoding="utf-8"))

# --- 테스트 값 (제출 안 하므로 안전) ---
TEST_SYMBOL = "005930"   # 삼성전자
TEST_QTY = "1"
TEST_PRICE = "257000"

MOVE_DELAY = 1.0     # 이동 → 클릭 (커서 안착 대기)
CLICK_DELAY = 1.0    # 클릭 → 타이핑 (필드 포커스 안정화)
TAB_DELAY = 1.0      # Tab 이동 → 타이핑
# ★ 피코 클릭이 겨냥보다 ~49px '위'에 찍히는 현상 보정: y 를 아래로 밀어서 겨냥
CLICK_Y_OFFSET = 49

MANUAL_PORT = ""
pico = PicoHID(MANUAL_PORT or find_pico_port())
pico.connect()


def click_at(key):
    x, y = COORDS[key]
    set_cursor(x, y + CLICK_Y_OFFSET)   # 49px 아래로 겨냥 → 클릭이 필드 위치에 찍힘
    time.sleep(MOVE_DELAY)
    pico.click()
    time.sleep(CLICK_DELAY)


# --- 진단 ---
_sw, _sh = _user32.GetSystemMetrics(0), _user32.GetSystemMetrics(1)
print(f"[진단] 이 프로세스가 보는 화면: {_sw}x{_sh}  (배율 100%면 실해상도와 같아야 함)")

# --- 0) 클릭이 필요한 곳(매도탭·종목)만 커서로 미리 확인 ---
print("\n커서만 이동해 확인합니다(클릭/입력 없음). 카이로스를 보세요.")
for key in ("tab_sell", "field_symbol", "field_qty", "field_price"):
    x, y = COORDS[key]
    set_cursor(x, y)
    print(f"  커서 → {key} ({x}, {y}) : 이 위에 정확히 있나요?")
    time.sleep(1.6)

if input("\n네 곳(매도탭·종목·수량·단가) 모두 정확했나요? (y/n): ").strip().lower() != "y":
    raise SystemExit("어긋남 → 재캘리브레이션. 중단합니다.")

# --- 1) 실제 흐름: 각 필드 직접 클릭 (포커스는 사용자가 카이로스 클릭으로 확보) ---
print("\n★★ 지금 '카이로스 [0611] 창의 빈 곳(예: 종목명 글자 근처)'을 한 번 클릭해 포커스를 주세요.")
print("   그 뒤 마우스·키보드를 절대 건드리지 말고 그대로 두세요. (8초 뒤 시작)")
for i in range(8, 0, -1):
    print(f"   {i}...", end="\r", flush=True)
    time.sleep(1)
print("\n시작 (bring_front 안 함 — 사용자가 준 포커스 유지)")

print("① 매도 탭 클릭")
click_at("tab_sell")

print(f"② 종목칸 클릭 + 입력: {TEST_SYMBOL}")
click_at("field_symbol")
pico.clear_and_type(TEST_SYMBOL)
time.sleep(0.6)          # 종목 로딩 대기

print(f"③ 수량칸 클릭 + 입력: {TEST_QTY}")
click_at("field_qty")     # Tab 대신 직접 클릭(오프셋 보정됨)
pico.clear_and_type(TEST_QTY)

print(f"④ 단가칸(노란칸) 클릭 + 입력: {TEST_PRICE}")
click_at("field_price")   # 직접 클릭
pico.clear_and_type(TEST_PRICE)

print("\n입력 완료 — 주문 버튼은 누르지 않았습니다.")
print("확인: 종목·수량·단가가 제 칸에 들어갔나요?")
