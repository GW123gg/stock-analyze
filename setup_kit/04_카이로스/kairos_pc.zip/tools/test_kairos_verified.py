"""카이로스 매도 흐름 — 검증/재시도 드라이버 테스트.

각 단계마다 입력 후 화면 OCR로 확인 → 틀리면 자동 재시도.
★ 주문(매도) 버튼은 누르지 않음.

준비:
  1) 피코 연결(마우스+키보드 펌웨어)
  2) pip install pytesseract  +  Tesseract-OCR 설치 (아래 TESSERACT_CMD 경로 지정)
  3) python tools/calibrate_kairos.py 로 kairos_coords.json (100% 배율)
  4) ★ 전용 데스크톱에 '카이로스만' 최대화, 다른 창 최소화
실행: python tools/test_kairos_verified.py
"""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, r"C:\Users\USER\Desktop\mirae asset securities auto")

import ctypes
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

from server.hid_serial import PicoHID, find_pico_port
from server.kairos_ui import KairosUI, OCR_OK, OCR_ERR

ROOT = r"C:\Users\USER\Desktop\mirae asset securities auto"
COORDS = json.loads(Path(ROOT, "kairos_coords.json").read_text(encoding="utf-8"))

# --- 설정 ---
CLICK_Y_OFFSET = 49
# Tesseract 설치 경로(기본 설치 위치). 다르면 수정. 없으면 검증 생략됨.
TESSERACT_CMD = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
MANUAL_PORT = ""

TEST_SYMBOL = "005930"   # 삼성전자
TEST_QTY = "1"
TEST_PRICE = "257000"

print(f"[진단] OCR 사용 가능: {OCR_OK}" + ("" if OCR_OK else f"  ({OCR_ERR}) → 검증 생략됨"))

pico = PicoHID(MANUAL_PORT or find_pico_port())
pico.connect()
ui = KairosUI(COORDS, pico, click_y_offset=CLICK_Y_OFFSET, tesseract_cmd=TESSERACT_CMD)

print("\n★ 8초 안에 '카이로스 [0611] 창의 빈 곳'을 한 번 클릭해 포커스를 주고,")
print("  이후 마우스·키보드를 건드리지 마세요.")
for i in range(8, 0, -1):
    print(f"   {i}...", end="\r", flush=True)
    time.sleep(1)
print("\n시작\n")

ok = True
print("① 매도 탭")
ok &= ui.select_sell_tab()
print(f"② 종목 {TEST_SYMBOL}")
ok &= ui.set_field("field_symbol", TEST_SYMBOL)
print(f"③ 수량 {TEST_QTY}")
ok &= ui.set_field("field_qty", TEST_QTY)
print(f"④ 단가 {TEST_PRICE}")
ok &= ui.set_field("field_price", TEST_PRICE)

print("\n" + ("✅ 전 단계 성공 — 주문 버튼은 누르지 않음" if ok
              else "⚠️ 일부 단계 실패(위 로그 확인). 좌표/OCR 영역/포커스 점검"))
