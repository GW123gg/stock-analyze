"""가설 확인: '손 마우스로 직접 올려둔' 위치에서 피코 클릭이 카이로스에 먹히는지.

SetCursorPos(소프트 이동)를 안 쓰고, 사용자가 손 마우스로 매도 탭 위에 커서를 올려둔 뒤
피코가 그 자리를 클릭한다.
  - 매도 탭이 바뀌면  → 피코 클릭 자체는 OK. 문제는 'SetCursorPos + 클릭' 조합 → 피코가 이동도 하면 해결.
  - 안 바뀌면        → 피코 클릭이 카이로스에서 막힘(이동 방식 무관) → 다른 접근 필요.

준비: 카이로스 [0611] 앞, 피코 연결.
실행: python tools/test_manualpos_click.py
"""
import sys
import time

sys.path.insert(0, r"C:\Users\USER\Desktop\mirae asset securities auto")

from server.hid_serial import PicoHID, find_pico_port

MANUAL_PORT = ""
p = PicoHID(MANUAL_PORT or find_pico_port())
p.connect()

print("=" * 56)
print(" 6초 안에 '손 마우스'로 커서를 '매도 탭' 글자 위에 올려두고")
print(" 손을 떼지 말고 가만히 두세요. (클릭하지 마세요 — 위치만)")
print("=" * 56)
for i in range(6, 0, -1):
    print(f"   {i}...", end="\r", flush=True)
    time.sleep(1)

print("\n피코가 지금 그 자리를 클릭합니다!")
p.click()
time.sleep(0.5)
print("\n→ 매도 탭으로 바뀌었나요?")
print("   바뀜  = 피코 클릭 OK, 문제는 SetCursorPos → '피코가 이동도' 하면 해결")
print("   안바뀜 = 피코 클릭이 카이로스에서 막힘 → 다른 방법 필요")
