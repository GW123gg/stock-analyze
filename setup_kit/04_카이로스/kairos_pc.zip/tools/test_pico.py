"""Pico HID 브리지 동작 테스트.

준비: Pico 에 CircuitPython + adafruit_hid + firmware/pico/code.py 를 넣고 USB 연결.
실행: python tools/test_pico.py
      → 5초 안에 '메모장'(또는 아무 텍스트 입력칸)을 클릭해 포커스를 주세요.
      → Pico 가 실물 키보드로 005930 을 타이핑합니다. 메모장에 찍히면 성공.
        (카이로스 종목칸에서도 동일하게 동작 — 안랩을 통과합니다.)
"""
import sys
import time

sys.path.insert(0, r"C:\Users\USER\Desktop\mirae asset securities auto")

from serial.tools import list_ports

from server.hid_serial import PicoHID, find_pico_port

# ---- 연결된 COM 포트 전부 출력 (진단용) ----
print("=== 연결된 COM 포트 목록 ===")
ports = list(list_ports.comports())
if not ports:
    print("  (없음) → 피코가 인식 안 됨. CIRCUITPY 드라이브가 뜨는지 / 데이터 케이블인지 / USB 포트 바꿔 확인")
for x in ports:
    print(f"  {x.device} | {x.description} | {x.hwid}")
print()

# ---- 여기에 포트를 직접 적으면 자동탐색을 건너뜀 ----
MANUAL_PORT = ""              # 예: "COM5"  (위 목록에서 피코로 보이는 것)

port = MANUAL_PORT or find_pico_port()
if not port:
    print("피코 포트를 못 정했습니다.")
    print("→ 위 목록에서 피코로 보이는 COM(예: hwid에 VID:PID=2E8A 또는 239A, 또는 새로 생긴 'USB 직렬 장치')을")
    print("  찾아, 이 파일 위쪽의 MANUAL_PORT = \"COMx\" 에 적고 다시 실행하세요.")
    raise SystemExit(1)

print("사용할 포트:", port)
pico = PicoHID(port)
pico.connect()
print("연결 성공. 5초 안에 메모장 등 입력칸을 클릭해 포커스를 주세요...")
for i in range(5, 0, -1):
    print(f"  {i}...", end="\r", flush=True)
    time.sleep(1)

print("\n타이핑: 005930 + Enter")
pico.clear_and_type("005930")
pico.key("ENTER")
print("메모장에 '005930' 이 찍혔으면 성공! 실패면 code.py/lib(adafruit_hid) 설치를 확인하세요.")
