"""Pico 마우스 클릭 테스트: pyautogui가 커서를 옮기고(이동은 통과), Pico가 클릭(실물 HID → 통과).

준비:
  1) 새 firmware/pico/code.py 를 피코에 복사(마우스 클릭 추가된 버전)
  2) pip install pyautogui   (아직이면)
  3) '그림판'을 하나 띄워두기

실행: python tools/test_pico_click.py
  → 5초 뒤 커서가 화면 중앙으로 이동 → Pico가 좌클릭.
  → 그림판에 점이 찍히면 성공(합성 이동 + 실물 클릭 통과).
  → 그다음 카이로스 '매도' 탭 위로 커서를 옮기고 Pico 클릭 → 탭이 바뀌면 완성.
"""
import sys
import time

sys.path.insert(0, r"C:\Users\USER\Desktop\mirae asset securities auto")

import pyautogui

from server.hid_serial import PicoHID, find_pico_port

MANUAL_PORT = ""   # 자동탐색 실패 시 "COM5" 처럼 지정

pico = PicoHID(MANUAL_PORT or find_pico_port())
pico.connect()

print("5초 안에 '그림판'을 화면에 보이게 띄워두세요...")
for i in range(5, 0, -1):
    print(f"  {i}...", end="\r", flush=True)
    time.sleep(1)

w, h = pyautogui.size()
x, y = w // 2, h // 2
print(f"\n커서를 화면 중앙({x},{y})으로 이동(pyautogui) → Pico 좌클릭")
pyautogui.moveTo(x, y, duration=0.3)
time.sleep(0.3)
pico.click()

print("그림판에 점이 찍혔으면 성공! (이동=pyautogui, 클릭=Pico HID → 안랩 통과)")
print("다음: 카이로스 '매도' 탭 좌표로 pyautogui.moveTo → pico.click() 하면 탭 전환되는지 확인")
